#!/usr/bin/env python
# coding: utf-8

# ## Classes and Objects

# ## Object oriented programming (OOP)
# - Object oriented programming is a common and powerful concept in computer programming
# - In simple terms, the programs written with the OOP concept rely on objects to operate
# - There are various object oriented programming languages, Python and Java are among the top 5 in the [StackOverflow developer survery 2020](https://insights.stackoverflow.com/survey/2020#technology-programming-scripting-and-markup-languages)
# 
# ### Here is an glimpse of OOP by Steve Jobs in 1994
# **Jeff Goodell**: Would you explain, in simple terms, exactly what object-oriented software is?
# 
# **Steve Jobs**: Objects are like people. They’re living, breathing things that have knowledge inside them about how to do things and have memory inside them so they can remember things. And rather than interacting with them at a very low level, you interact with them at a very high level of abstraction, like we’re doing right here.
# 
# Here’s an example: If I’m your laundry object, you can give me your dirty clothes and send me a message that says, “Can you get my clothes laundered, please.” I happen to know where the best laundry place in San Francisco is. And I speak English, and I have dollars in my pockets. So I go out and get a taxicab and tell the driver to take me to this place in San Francisco. I go get your clothes laundered, I jump back in the cab, I get back here. I give you your clean clothes and say, “Here are your clean clothes.”
# 
# You have no idea how I did that. You have no knowledge of the laundry place. Maybe you speak French, and you can’t even get a taxi. You can’t pay for one, you don’t have dollars in your pocket. Yet I knew how to do all of that. And you didn’t have to know any of it. All that complexity was hidden inside of me, and we were able to interact at a very high level of abstraction. That’s what objects are. They encapsulate(or hide) complexity, and the interfaces to that complexity are high level.
# 
# **This was just a high level explanation, now let's get depper into it!**

# ### To understand the concept better, let's take a look at classes. What are classes?
# - Classes are templates that define the objects
# - An Object is be created using a class
# - You can create multiple objects using just one class
# - A class in python can be defined using the `class` keyword
# - By convention, the name of the class always starts with a capital letter (not mandatory!)

# In[1]:


class Example:
    x = 10


# ### Now let's take a look at objects
# - As we already know, objects are created using classes
# - One object can be created using one class
# - An object has attributes(how it is), and behaviour(what it does)
# 
# Here's an example of an object: Car
# 
# A car has its own attributes and behaviours.
# 
# Attributes:
# - Color (Red, Black, Silver, Grey)
# - Manual/Automatic
# - Number of passangers
# - Electric/Petrol/Diesel
# 
# Behaviors:
# - Accelerate
# - Brake
# - Sound horn
# - Windows up/down
# 
# In conclusion,
# - An object has attributes that can you think of as the **state** of the object, and behaviours that can you think of **actions**
# - In programming, state is the variables defined, and behaviours are the methods
# - You can define these variables and methods inside of a class to make a template for the object
# 
# 
# Now, let's define a simple class with just variables and make an object from it.

# In[2]:


"""
    Defining a class named Car with attributes (state):
    - color
    - transmission
    - number_of_passengers
    - fuel_type
"""

class Car:
    color = "red"
    transmission = "automatic"
    number_of_passengers = 5
    fuel_type = "electric"


# We can create an object from a class, by calling the class using round brackets: `Car()`

# In[3]:


"""
    Now, let's create an object using the above class and print it's values
"""

tesla_model_3 = Car()
print("Tesla model 3")
print("Color: ", tesla_model_3.color)
print("Transmission: ", tesla_model_3.transmission)
print("Number of passangers: ", tesla_model_3.number_of_passengers)
print("Fuel Type: ", tesla_model_3.fuel_type)


# In[4]:


type(tesla_model_3)


# We can also modify these values of the object we have created, this wouldn't affect the other object

# In[5]:


# Creating a new model and printing it's values
tesla_model_s = Car()
print("Tesla model S")
print("Color: ", tesla_model_s.color)
print("Transmission: ", tesla_model_s.transmission)
print("Number of passangers: ", tesla_model_s.number_of_passengers)
print("Fuel Type: ", tesla_model_s.fuel_type)


# In[6]:


# Changing the color of model 3
tesla_model_3.color = "silver"

print("Tesla model 3")
print("Color: ", tesla_model_3.color)
print("Transmission: ", tesla_model_3.transmission)
print("Number of passangers: ", tesla_model_3.number_of_passengers)
print("Fuel Type: ", tesla_model_3.fuel_type)


# In[7]:


# Printing the unchanged values of model S
print("Tesla model S")
print("Color: ", tesla_model_s.color)
print("Transmission: ", tesla_model_s.transmission)
print("Number of passangers: ", tesla_model_s.number_of_passengers)
print("Fuel Type: ", tesla_model_s.fuel_type)


# **As you can see above the tesla_model_s object still has the color of Red while the tesla_model_3 has color silver now**

# In the upcoming chapters, we will learn more about objects and classes, and how to use them.
# 
# There are a few features of OOP which we will discuss in depth in the coming chapters:
# - Inheritence
# - Encapsulation
# - Polymorphism
# - Abstraction

# In[ ]:




