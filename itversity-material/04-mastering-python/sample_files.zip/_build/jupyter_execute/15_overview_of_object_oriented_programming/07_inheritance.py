#!/usr/bin/env python
# coding: utf-8

# ## Inheritance
# 
# Inheritence in OOP is similar to the inheritence in real world. For any inheritence to occur, there needs to be atleast two classes:
# - Parent
# - Child
# 
# Parent is the one from which you inherit and child is the one to which you inherit the properties and methods.
# 
# Properties are the variables defined and the values they contain, methods are the functions that are defined in the parent.
# 
# We can access the parent from the child using the `super` keyword

# In[1]:


import datetime


# Let's define a parent class called `User`

# In[2]:


class User:
    def __init__(self, user_id, user_fname, user_lname, user_email, user_created_dt):
        self.user_id = user_id
        self.user_fname = user_fname
        self.user_lname = user_lname
        self.user_email = user_email
        self.user_created_dt = user_created_dt
        
    def print_details(self):
        print("User ID: ", self.user_id)
        print("User first name: ", self.user_fname)
        print("User last name: ", self.user_lname)
        print("User email: ", self.user_email)
        print("User created dt: ", self.user_created_dt)


# In an application there can be many types of users. For now, we will just take one type of user called the `Admin`. We inherit the parent into the child by passing the parent class as a parameter to the child. As you can observe below, we can access the `print_details` function that is defined in the parent from the child class object.

# In[3]:


class Admin(User):
    pass
        
admin1 = Admin(
    user_id=1,
    user_fname='Scott',
    user_lname='Smith',
    user_email='scott@example.com',
    user_created_dt=str(datetime.datetime.now())
)
admin1.print_details()


# Now, let us modify the child class. Here, we have defined a constructor, and called the constructor of the parent using `super` keyword.
# Also, you can obser the following:
# - We have defined a function `print_details` in the child, this function also exists in the parent. When we define it in the child and make perform a similar or different functionality, we called it function overriding.
# - We can add any other methods that we need in the child class, in the below example, we add the function: `get_admin_level`

# In[4]:


class Admin(User):
    def __init__(self, user_id, user_fname, user_lname, user_email, user_created_dt):
        super().__init__(user_id, user_fname, user_lname, user_email, user_created_dt)
        self.user_role = "admin"
        self.admin_level = "senior"
        
    def print_details(self):
        print("User ID: ", self.user_id)
        print("User role: ", self.user_role)
        print("User first name: ", self.user_fname)
        print("User last name: ", self.user_lname)
        print("User email: ", self.user_email)
        print("User created dt: ", self.user_created_dt)
        
    def get_admin_level(self):
        return self.admin_level
        
admin1 = Admin(
    user_id=1,
    user_fname='Scott',
    user_lname='Smith',
    user_email='scott@example.com',
    user_created_dt=str(datetime.datetime.now())
)
admin1.print_details()
print("Admin level: ", admin1.get_admin_level())


# There are two three ways in which one can take advantage of Inheritence in python:
# - Simple inheritence: This is what we saw above
# - Mutliple inheritence: A child inheriting from more than once parent
# - Multi-level inheritence: This is where we have a chain of inheritence happening. Parent -> Child -> Grandchild
