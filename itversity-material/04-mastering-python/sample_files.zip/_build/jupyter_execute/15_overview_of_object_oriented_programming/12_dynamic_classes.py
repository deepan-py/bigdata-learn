#!/usr/bin/env python
# coding: utf-8

# ## Dynamic Classes

# Class is a collection of variables and methods of a specific type. Python being a flexible language, allows us to create classes in runtime. Such classes are called dynamic classes. These dynamic classes can be created by extending the `type` function. Lets look at an example below.

# In[1]:


import datetime


# In[2]:


def constructor(self, user_id, user_fname, user_lname, user_email, user_created_dt):
    self.user_id = user_id
    self.user_fname = user_fname
    self.user_lname = user_lname
    self.user_email = user_email
    self.user_created_dt = user_created_dt


def print_details(self):
    print("User ID: ", self.user_id)
    print("User first name: ", self.user_fname)
    print("User last name: ", self.user_lname)
    print("User email: ", self.user_email)
    print("User created dt: ", self.user_created_dt)
    
@staticmethod
def get_current_datetime():
    return str(datetime.datetime.now())
    

User = type("User", (object, ), {
    "__init__": constructor,
    "website": "itversity",
    "print_details": print_details,
    "get_current_datetime": get_current_datetime
})


# In[3]:


User.get_current_datetime()


# In[4]:


user1 = User(
    user_id=1,
    user_fname='Scott',
    user_lname='Smith',
    user_email='scott@example.com',
    user_created_dt=str(datetime.datetime.now())
)


# In[5]:


user1.print_details()


# In[3]:


class DynClass:
    def __init__(self, **kwargs):
        for key, value in kwargs.items():
            setattr(self, key, value)


# In[4]:


dyn_class = DynClass(foo1='bar1', foo2='bar2')


# In[5]:


dyn_class


# In[6]:


dyn_class.foo1


# In[ ]:




