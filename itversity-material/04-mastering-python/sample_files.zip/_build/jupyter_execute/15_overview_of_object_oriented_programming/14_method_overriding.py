#!/usr/bin/env python
# coding: utf-8

# ## Method Overriding
# 
# Method overriding is override (or overpower) a function from a parent when we inerit a class.
# - This can be done in python without any supporting packages.
# - Method overriding is an example of run time polymorphism.
# - In method overriding, the main change happens in the child class
# - As you can observe below, the `add` method is overriden in the `Child` class by defining a new function
# - When we create an object of Child class and call the add method, the overriden method gets called and not the add method in the parent
# 

# In[4]:


class Parent:
    def add(self, a, b):
        return a + b
    def mul(self, a, b):
        return a * b
    
class Child(Parent):
    def add(self, a, b, c):
        return a + b + c
    
obj_parent = Parent()
obj_child = Child()

print("Add in parent: ", obj_parent.add(1, 2))
print("Add in child: ", obj_child.add(1, 2, 3))
print("---------------------------")
print("Multiplication in parent: ", obj_parent.mul(3, 4))
print("Multiplication in child: ", obj_child.mul(3, 4))


# Now, let's try the same with a multiple inheritence.

# In[5]:


class Parent1:
    def add(self, a, b):
        return a + b
    def mul(self, a, b):
        return a * b
    
class Parent2:
    def div(self, a, b):
        return a / b
    def mod(self, a, b):
        return a % b
    
class Child(Parent1, Parent2):
    def add(self, a, b):
        return a + b
    def div(self, a, b):
        return b / a
    
obj_child = Child()
print("Addition: ", obj_child.add(2, 3))
print("Multiplication: ", obj_child.mul(2, 3))
print("Division: ", obj_child.div(2, 3))
print("Modulus: ", obj_child.mod(2, 3))

