#!/usr/bin/env python
# coding: utf-8

# ## repr and str functions
# 
# Let us understand the relevance of `__repr__` and `__str__` functions in Python.
# * `__repr__` - complete string representation of the object
# * `__str__` - nice string for printing.

# In[1]:


import datetime


# In[2]:


datetime.datetime.now()


# In[3]:


repr(datetime.datetime.now())


# In[4]:


str(datetime.datetime.now())


# In[9]:


class Car:
    def __str__(self):
        return 'car'


# In[10]:


car = Car()


# In[11]:


car


# In[12]:


str(car)


# In[13]:


repr(car)


# Container’s `__str__` uses contained object's `__repr__`.
# * If you implement `__repr__` function with out `__str__`, then when you invoke `str` on object, `__repr__` will be invoked automatically.

# In[15]:


class Bike:
    def __repr__(self):
        return 'bike'


# In[16]:


bike = Bike()


# In[18]:


str(bike)


# In[19]:


repr(bike)

