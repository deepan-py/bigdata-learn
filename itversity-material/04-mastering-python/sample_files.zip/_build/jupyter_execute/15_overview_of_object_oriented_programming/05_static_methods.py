#!/usr/bin/env python
# coding: utf-8

# ## Static methods
# 
# As part of the previous topic we have looked into class methods. They are primarily invoked using objects. Now, let us talk about static methods.
# - These are methods of a class which can be accessed by the class name.
# - They are not accessible through the objects of the class.
# - A method in a class can be made static using the `@staticmethod` attribute.
# - They can be private or public. We will see the details related private as well as public methods as part of next topic.

# In[2]:


class Car:
    def __init__(self, color, model):
        self.color = color
        self.model = model
        
    @staticmethod
    def current_ceo_of_the_company():
        return "Elon Musk"
    
    @staticmethod
    def warranty_till(year_of_purchase):
        return year_of_purchase + 5
    
print(Car.current_ceo_of_the_company())
print(Car.warranty_till(2019))


# Observations from the above code:
# - We didn't have to initialize the object of class Car to access the static methods
# - We don't pass the self object to the static methods
# - `current_ceo_of_the_company` was a non-parameterized method while `warranty_till` is a parameterized method
# - Static methods can be private or public
