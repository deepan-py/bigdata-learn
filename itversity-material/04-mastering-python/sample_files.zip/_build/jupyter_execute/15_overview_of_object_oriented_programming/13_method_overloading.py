#!/usr/bin/env python
# coding: utf-8

# ## Method Overloading
# 
# Now that we know Inheritence and polymorphism, let's dive in a bit into how we can leverage the methods we create to perform efficient computations.
# - Method overloading and overriding are important concepts that contribute to better code quality and unambiguous naming conventions
# - Method overloading is to have a two or more methods with a same name but a difference in their parameter or return types
#     - This cannot be natively done in python due to the interpreted nature of it. So, we use the package `multipledispatch`.
#     - Method overloading is an example of compile time polymorphism

# In[1]:


from multipledispatch import dispatch


# Below is an example where we create two methods with a same name, the only difference is the number of parameters. Using the dispatch attribute(`@dispatch`) of the `multipledispatch` package, we specify the type and number of parameters that each function takes. When we call the same method with different parameters, different functions occur

# In[2]:


@dispatch(int, int)
def add(a, b):
    return a + b

@dispatch(int, int, int)
def add(a, b, c):
    return a + b + c

print("Adding 1 and 2: ", add(1, 2))
print("Adding 1, 2, and 3: ", add(1, 2, 3))


# Let's try this out within a class

# In[3]:


class Operation:
    @dispatch(float, float)
    def mul(self, a, b):
        return a * b
    @dispatch(float, float, float)
    def mul(self, a, b, c):
        return a * b * c
    
obj = Operation()
print("Multiplication of 3 and 4: ", obj.mul(3.0, 4.0))
print("Multiplication of 3, 4, and 5: ", obj.mul(3.0, 4.0, 5.0))

