#!/usr/bin/env python
# coding: utf-8

# ## Using Slotted Classes
# 
# Let us get an overview of Slotted Classes. Data Classes will provide some common functionalities out-of-the-box which we need to implement with normal classes.
# * When we create a class in Python, we need not specify the attributes.
# * However, when multiple developers try to use the objects of the same class, they might end up adding new attributes to the object with out restriction.
# * We can restrict fields using `__slots__` as part of the class definition.

# In[14]:


class Course:
    course_id: int
    
    def __init__(self, course_id, course_title):
        self.course_id = course_id
        self.course_title = course_title

        
    def __repr__(self):
        return f'Course(course_id={self.course_id}, course_title={self.course_title})'


# In[15]:


course = Course(1, 'Learn Programming')


# In[16]:


course


# In[17]:


course.course_author = 'ITVersity' # Success


# In[18]:


course.course_author


# In[19]:


class Course:
    course_id: int
    
    __slots__ = 'course_id', 'course_title'
    
    def __init__(self, course_id, course_title):
        self.course_id = course_id
        self.course_title = course_title

        
    def __repr__(self):
        return f'Course(course_id={self.course_id}, course_title={self.course_title})'


# In[20]:


course = Course(1, 'Learn Programming')


# In[21]:


course


# In[22]:


course.course_author = 'ITVersity' # Fails with AttributeError

