#!/usr/bin/env python
# coding: utf-8

# # Overview of Object Oriented Programming
# 
# * Classes and Objects
# * Constructors
# * Methods
# * Inheritance
# * Encapsulation
# * Polymorphism
# * Dynamic Classes
