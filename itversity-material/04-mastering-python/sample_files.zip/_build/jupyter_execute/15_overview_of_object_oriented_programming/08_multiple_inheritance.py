#!/usr/bin/env python
# coding: utf-8

# ## Multiple Inheritance
# 
# Let's look at Multiple inheritance.
# * In Multiple inheritance, one child class inherits from multiple parents classes.
# * In this example, Coffee is the child class of both Milk and Sugar.
# * We are able to access the attributes from Milk and Sugar using the object of type Coffee.

# In[1]:


class Milk:
    quantity_milk = "100 ml"


# In[2]:


class Sugar:
    quantity_sugar = "2 spoons"


# In[3]:



class Coffee(Milk, Sugar):
quantity_coffee = "1 cup"


# In[4]:


coffee = Coffee()


# In[5]:


print("Quantity of milk: ", coffee.quantity_milk)


# In[6]:


print("Quantity of sugar: ", coffee.quantity_sugar)


# In[7]:


print("Quantity of cofee: ", coffee.quantity_coffee)

