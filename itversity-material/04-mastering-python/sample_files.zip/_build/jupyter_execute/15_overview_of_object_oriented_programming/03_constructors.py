#!/usr/bin/env python
# coding: utf-8

# ## Constructors

# - A constructor is a method that gets called when the **class gets initiated(or when an object gets created)**
# - This constructor lets us assign values or perform the initial computation if needed
# - A constructor is an private function inside the class, that is, it cannot be accessed from outside the class object

# In[1]:


class Car:
    def __init__(self):
        self.color = "red"


# In python, the `__init__` method is the constructor, the `self` variable that is passed as a parameter is the object of Car class iself

# In[2]:


class Car:
    def __init__(self):
        print(type(self))
        
tesla = Car()


# As you can see above, constructor is the method that gets called when an object of that class is initiated, and also the `self` object is the object of the Car class itself. You can also use self object to access the variables in the class.

# In[3]:


class Car:
    color = "red"
    def __init__(self):
        print("Color of tesla: ", self.color)
        
tesla = Car()


# **Here's a fun fact**:
# You can name the self object as anything, the self name is just a convention that is set and is being followed.

# In[4]:


class Car:
    def __init__(abc):
        print(type(abc))
        
tesla = Car()


# Now, let's take a look at the different ways in which you can use the constructor in python:
# - It can be used to assign initial values to the object
# - It can be used to perform an initial action

# In[2]:


# Let's see how we can pass initial values to the object
class Car:
    def __init__(self, color, model):
        self.color = color
        self.model = model

# Caution: You don't pass the self value, you pass only the other parameters
tesla = Car("red", "S")

print("Color of tesla: ", tesla.color)
print("Model of tesla: ", tesla.model)


# In[6]:


# Let's see how we perform some initial computation in the constructor
import datetime

class Car:
    def __init__(self):
        self.manufacturing_date = datetime.datetime.now()
        print("Car manufactured at: ", self.manufacturing_date.strftime("%d %B %Y"))
        
tesla = Car()


# ### Exercise
# Create a class Laptop, compute the manufactering date in the constructor, and also pass the parameters of model name and screen size(13, 15, 18).
# 
# Note: Remove the pass keyword below and proceed.

# In[7]:


class Laptop:
    pass

