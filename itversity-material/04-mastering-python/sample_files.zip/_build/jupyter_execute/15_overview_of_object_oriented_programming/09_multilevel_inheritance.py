#!/usr/bin/env python
# coding: utf-8

# ## Multi-level Inheritance
# Let's look at multi-level inheritance.
# * We will take the example of 3 classes with level hierarchy - **GrandFather -> Father -> Child**.
# * All the properties of GrandFather will be inherited by Father.
# * All the properties of Father will be inherited by Child.

# In[ ]:


class GrandFather:
    name_grandfather = "Prescott Sheldon Bush"
    
    def __init__(self):
        print('Inside grandfather')


# In[ ]:


grand_father = GrandFather()


# In[ ]:


class Father(GrandFather):
    name_father = "George H. W. Bush"
    
    def __init__(self):
        super().__init__()
        print('Inside father')


# In[ ]:


father = Father()


# In[ ]:


class Child(Father):
    name_child = "George W. Bush"
    
    def __init__(self):
        super().__init__()
        print('Inside child')


# In[ ]:


child = Child()


# In[ ]:


obj_child = Child()


# * We are able to access the attribute from both GrandFather as well as Father using the object of type Child.

# In[ ]:


print("Name of grandfather: ", obj_child.name_grandfather)


# In[ ]:


print("Name of father: ", obj_child.name_father)


# In[ ]:


print("Name of child: ", obj_child.name_child)


# In[ ]:




