#!/usr/bin/env python
# coding: utf-8

# ## Overview of Data Classes
# 
# Let us get an overview of Data Classes. Data Classes will provide some common functionalities out-of-the-box which we need to implement with normal classes.
# 
# Here are the steps we use with normal class.
# * Create a class with required attributes.
# * Define the constructor. As part of the constructor, we typically initialize class attributes.
# * We need to define `__repr__` function to provide representation of object.

# In[15]:


class Course:
    course_id: int
    course_title: str
    course_author: str
    course_price: float
    
    def __init__(self, course_id, course_title, course_author, course_price):
        self.course_id = course_id
        self.course_title = course_title
        self.course_author = course_author
        self.course_price = course_price
        
    def __repr__(self):
        return f'Course(course_id={self.course_id}, course_title={self.course_title}, course_author={self.course_author}, course_price={self.course_price})'


# In[16]:


course = Course(1, 'Learn Programming', 'ITVersity', 100.0)


# In[17]:


course


# In[19]:


course.course_id


# In[20]:


course.course_title


# * Here is how you can implement this using Data Classes.
# * You need to first install this external Python Module using `pip install dataclasses`

# In[21]:


from dataclasses import dataclass

@dataclass
class Course:
    course_id: int
    course_title: str
    course_author: str
    course_price: float


# In[22]:


course = Course(1, 'Learn Programming', 'ITVersity', 100.0)


# In[23]:


course


# In[26]:


course.course_id


# In[27]:


course.course_title


# In[28]:


help(course)


# In[33]:


hash(course)


# In[ ]:




