#!/usr/bin/env python
# coding: utf-8

# ## Private and Public methods
# 
# Let us get into the details related to Private and Public methods.
# - Private methods are the ones that can NOT be accessed from outside of class and object.
# - Private methods can only be accessed by other internal methods of a class and object.
# - Private methods start with `__` (double underscore).
# - Private methods cannot be static.
# - `__init__` is a private method, not accessible from outside.
# - Public methods can be accessed from outside the class and object.
# - Public methods can also be accessed from internal methods of a class and object.

# In[16]:


class Car:
    def __init__(self, color, model):
        self.color = color
        self.model = model
        
    def change_color(self, new_color):
        self.color = new_color
        
    def __change_model(self, new_model):
        self.model = new_model
        
    def exchange_car(self, new_model):
        self.__change_model(new_model)


# In[17]:


tesla = Car('red', '3')
print('Initial tesla color and model: ', tesla.color, ', ', tesla.model)


# In[19]:


tesla.change_color('silver')
print('Color after change: ', tesla.color)


# In[20]:


tesla.exchange_car('S')
print('Model after change: ', tesla.model)


# In the above code, the private function `__change_model` is being called by the public function `exchange_car`.
# 
# Now, let's try to call the private function using the object, this should produce an error.

# In[21]:


tesla.__change_model('Y')


# **The above error is expected as a private function is being called directly from outside the object**
