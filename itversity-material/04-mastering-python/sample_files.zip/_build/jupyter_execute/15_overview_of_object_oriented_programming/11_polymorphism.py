#!/usr/bin/env python
# coding: utf-8

# ## Polymorphism

# Polymorphism means to have many forms. In OOP polymorphism means that, a function or an object can take up various forms and act differently based on the situation.
# We will explore two ways of implementing polymorphism:
# - Polymorphism in functions (Method overloading): The length function `len` returns different result based on what is passed. If we pass a string, it will return the number of characters. If we pass a list, it will return the number of list items.
# - Class based polymorphism - Method overriding.

# In[1]:


print("Length of 'Apple': ", len("Apple"))


# In[2]:


print("Length of tuple (10, 20, 30): ", len((10, 20, 30)))


# The Country class will take in different values and return different values based on how we inherit it.

# In[2]:


class Country:
    def __init__(self, capital, driving_side, developed):
        self.capital = capital
        self.driving_side = driving_side
        self.developed = developed
    def get_capital(self):
        return self.capital
    def get_driving_side(self):
        return self.driving_side
    def get_developed_status(self):
        if self.developed:
            return "Developed"
        return "Developing"


# In[3]:


class India(Country):
    def __init__(self):
        super().__init__("New Delhi", "Left", False)


# In[3]:



class USA(Country):
    def __init__(self):
super().__init__("Washington, D.C.", "Right", True)


# In[4]:


ind = India()


# In[4]:


usa = USA()


# In[4]:


for obj in (ind, usa):
    print("Country name: ", type(obj).__name__)
    print("Capital: ", obj.capital)
    print("Driving side: ", obj.get_driving_side())
    print("Development status: ", obj.get_developed_status())
    print()

