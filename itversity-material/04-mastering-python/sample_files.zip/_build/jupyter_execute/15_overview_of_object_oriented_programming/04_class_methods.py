#!/usr/bin/env python
# coding: utf-8

# ## Class Methods
# 
# As part of this topic, we will focus on Class Methods. But before talking about Class Methods, let us understand about Method.
# - A method is a set of code that performs one or more actions
# - A method inside for a class is called a class method and can be accessed using the class or object
# - A method is created using the `def` keyword
# - With respect to how you can access a method, there are two types:
#     - Class method: A method that can accessed only through objects
#     - Static method: A method that can accessed through the class name
# - With respect to who can access a method, there are two types:
#     - Public method: Can be accessed from outside the class
#     - Private method: Can be only accessed from inside of the class
# - As a convention, the method names start with a small letter

# ### Class methods
# 
# Now let us talk about Class Methods.
# 
# - These methods are part of the class we define.
# - They are also part of the objects we create and can be called using the object.
# - They can be private or public. We will talk about private and public methods later.
# 
# From the previous explanation of OOP, the actions that an object do are the methods.

# In[1]:


class Car:
    def __init__(self, color, model):
        self.color = color
        self.model = model
        self.speed = 0
        self.ac_temperature = 28
        
    # Function to accelerate the car, it increases the speed of car by 2
    def accelerate(self):
        self.speed = self.speed + 2
    
    # Function to accelerate the car, it decreases the speed of car by 2
    def brake(self):
        self.speed = self.speed - 2
        
    # Function to set the air conditioner(AC) temperature in the car
    def set_ac_temperature(self, temp):
        self.ac_temperature = temp
        
tesla = Car("red", "S")
print("Car color: ", tesla.color)
print("Car model: ", tesla.model)
print("Car initial speed: ", tesla.speed)
tesla.accelerate()
tesla.accelerate()
tesla.accelerate()
print("Car speed after acceleration: ", tesla.speed)
tesla.brake()
print("Car speed after braking: ", tesla.speed)
print("Car initial AC temperature: ", tesla.ac_temperature)
tesla.set_ac_temperature(22)
print("Car AC temperature after change: ", tesla.ac_temperature)


# Observations to make from the above code:
# - `__init__` is a constructor
# - `accelerate`, `brake`, and `set_ac_temperature` are the three class methods
# - `accelerate` and `brake` are non-parameterized methods
# - `set_ac_temperature` is a parametized method
# - **Class methods have self as the first parameter**
# - These methods can be only accessed through the object of Car
