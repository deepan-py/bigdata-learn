#!/usr/bin/env python
# coding: utf-8

# ## Encapsulation

# Encapsulation is a concept of wrapping (or enclosing) data and the methods into a single unit called class. We already have seen that we define variables and methods in a class, then why this?
# - This concept specifically talks about who can access the data and methods defined in any class.
# - There are three types of access that can be provided:
#     - Public: Anybody can access the data and methods
#     - Private: data and methods only accessible within a particular class
#     - Protected: data and methods can be accessed by the class itself and the child class (Inheritance)
#         - However, this doesn't prevent other objects from accessing or modifying the data values
# - We don't have to use any specific syntax to define data and methods for public access
# - We need to use `__` (double underscore) to define private variables
# - We need to use `_` (single underscore) to defind protected variables

# In[1]:


import datetime


# In[2]:


class User:
    _user_id = None
    def __init__(self, user_id, user_fname, user_lname, user_email, user_password, user_created_dt):
        self._user_id = user_id
        self.user_fname = user_fname
        self.user_lname = user_lname
        self.user_email = user_email
        self.__user_password = user_password
        self.user_created_dt = user_created_dt
        
    def print_details(self):
        print("User ID: ", self._user_id)
        print("User first name: ", self.user_fname)
        print("User last name: ", self.user_lname)
        print("User email: ", self.user_email)
        print("User created dt: ", self.user_created_dt)
        
    def get_user_password(self):
        return self.__user_password


# In[3]:


class Admin(User):
    def __init__(self, user_id, user_fname, user_lname, user_email, user_password, user_created_dt):
        super().__init__(user_id, user_fname, user_lname, user_email, user_password, user_created_dt)
        self.user_role = "admin"
        self.admin_level = "senior"
        
    def print_details(self):
        print("User ID: ", self._user_id)
        print("User role: ", self.user_role)
        print("User first name: ", self.user_fname)
        print("User last name: ", self.user_lname)
        print("User email: ", self.user_email)
        print("User created dt: ", self.user_created_dt)
        
    def try_get_user_password(self):
        return self.__user_password


# In[3]:


admin1 = Admin(
    user_id=1,
    user_fname='Scott',
    user_lname='Smith',
    user_email='scott@example.com',
    user_password='Sample_Password@#1890',
    user_created_dt=str(datetime.datetime.now())
)


# In[3]:


admin1.print_details()


# In[3]:


print("Admin password: ", admin1.get_user_password())


# In[4]:


admin1.try_get_user_password()


# **We get an error while accessing the private variable in the parent class**
