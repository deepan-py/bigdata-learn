#!/usr/bin/env python
# coding: utf-8

# # Setup Postgres Database
# 
# Let us understand how to setup Postgres on Ubuntu VM. We will use Docker to set it up.
# 
# * Docker - Cheat Sheet
# * Setup Postgres using Docker
# * Accessing Postgres using Docker CLI
# * Create Database and User
# * Executing SQL Scripts
# * Setup SQL Workbench
# * SQL Workbench and Postgres
# * SQL Workbench Features
# * Troubleshooting Issues
# * Jupyter Lab and Postgresql

# In[1]:


get_ipython().run_cell_magic('HTML', '', '<iframe width="560" height="315" src="https://www.youtube.com/embed/bwEUYfkQWRk?rel=0&amp;controls=1&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>')


# You can access videos for this course module using [Setup labs on Ubuntu 18.04 VM on GCP using Docker to learn Python and SQL](https://www.youtube.com/playlist?list=PLf0swTFhTI8qOGXb3e6BmqHGQ-tnsP51q)
