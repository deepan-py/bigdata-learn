#!/usr/bin/env python
# coding: utf-8

# ## Create Database and User
# 
# Let us create **database** and **user** using `psql` CLI.

# In[1]:


get_ipython().run_cell_magic('HTML', '', '<iframe width="560" height="315" src="https://www.youtube.com/embed/YRHiZWfvwWc?rel=0&amp;controls=1&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>')


# * Postgres is multi tenant database.
# * We typically follow these steps to create a database which can be used by connecting as specific user.
#   * Connect to postgres server as user postgres (super user)
#   * Create database - `sms_db`
#   * Create user with password - `sms_user`
#   * Grant permissions on database to user
#   
# ```shell
# docker exec -it itv_pg psql -U postgres
# ```
# 
# ```sql
# CREATE DATABASE sms_db;
# CREATE USER sms_user WITH ENCRYPTED PASSWORD 'sms_password';
# GRANT ALL ON DATABASE sms_db TO sms_user;
# 
# \l --to list databases
# \q --to quit from postgres CLI
# ```
# 
# * Make sure to validate by connecting using sms_user.
# > When we use psql directly with in the container, you might be able to connect to database even with out password. Don't worry about it for now.
# 
# > Connect to postgres using newly created user
# 
# ```shell
# docker exec -it itv_pg psql -U sms_user -d sms_db -W
# ```
# 
# ```sql
# SELECT current_database();
# CREATE TABLE t (i INT);
# INSERT INTO t VALUES (1);
# SELECT * FROM t;
# 
# \d
# \d t
# 
# DROP TABLE t;
# ```
