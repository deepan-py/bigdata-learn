#!/usr/bin/env python
# coding: utf-8

# ## Docker - Cheat Sheet
# 
# As we have successfully setup Docker on our VM, let us go through some of the important commands related to docker.

# In[1]:


get_ipython().run_cell_magic('HTML', '', '<iframe width="560" height="315" src="https://www.youtube.com/embed/SFOpsK_LZVQ?rel=0&amp;controls=1&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>')


# Here are the steps involved in setting up Database Services such as Postgres using Docker:
# * Pull postgres image
# * Create container for postgres
# * Start the container
# * Review the logs to ensure that container is created with out any issues
# 
# Here are important commands to manage images and containers:
# 
# * Managing images - `docker image`
# 
# |Command           |Description |
# |------------------|------------|
# |docker image pull |Pull image  |
# |docker image rm   |Remove image|
# |docker image build|Build image |
# * Managing containers - `docker container`
# 
# |Command                  |Description                       |
# |-------------------------|----------------------------------|
# |docker container create  |Create container                  |
# |docker container start   |Start container                   |
# |docker container stop    |Stop  container                   |
# |docker container restart |Restart container                |
# |docker container rm      |Remove container                  |
# |docker container run     |Build, Create and Start container |
# |docker container logs    |Check logs of docker container    |
# |docker container rm      |Remove stopped container          |
# |docker container rm -f   |Stop and Remove running container |
# |docker container ls      |List containers                   |
# 
# ```{note}
# For most of these commonly used commands we have alternative with out image or container as keyword in the command - for example we can say `docker rm` to remove the container and `docker rmi` to remove the image.
# ```
# 
# ```shell
# docker pull postgres
# 
# docker container create \
#   --name itv_pg \
#   -p 5432:5432 \
#   -h itv_pg \
#   -e POSTGRES_PASSWORD=itversity \
#   postgres
#   
# docker container start itv_pg
# 
# docker container logs itv_pg
# docker container logs -f itv_pg
# ```
