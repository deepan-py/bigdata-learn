#!/usr/bin/env python
# coding: utf-8

# ## SQL Workbench and Postgres
# 
# Let us connect to Postgres Database using SQL Workbench.

# In[1]:


get_ipython().run_cell_magic('HTML', '', '<iframe width="560" height="315" src="https://www.youtube.com/embed/Cz2FHb0ElYA?rel=0&amp;controls=1&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>')


# * Download the JDBC Driver
# * Get the database connectivity information
# * Configure the connection using SQL Workbench
# * Validate the connection and save the profile

# ### Postgres on Docker
# 
# Here are the steps to connect to Postgres running as part of Docker container. You can go through the steps of dowloading the JDBC Driver as part of this [video](https://www.youtube.com/embed/IRRoAphUJmw?rel=0&amp;controls=1&amp;showinfo=0). This also covers how to connect to existing remote Postgres databases using SQL Workbench.
# 
# * We are trying to connect to Postgres Database that is running as part of Docker container running in a Ubuntu 18.04 VM provisioned from GCP.
# * We have published Postgres database port to port 5432 on Ubuntu 18.04 VM.
# * We typically use ODBC or JDBC to connect to a Database from remote machines (our PC).
# * Here are the pre-requisites to connect to a Database on GCP.
#   * Make sure 5432 port is opened as part of the firewalls.
#   * If you have telnet configured on your system on which SQL Workbench is installed, make sure to validate by running telnet command using ip or DNS Alias and port number 5432.
#   * Ensure that you have downloaded right JDBC Driver for Postgres.
#   * Make sure to have right credentials (username and password).
#   * Ensure that you have database created on which the user have permissions.
# * You can validate credentials and permissions to the database by installing postgres client on Ubuntu 18.04 VM and then by connecting to the database using the credentials.
# * Once you have all the information required along with JDBC jar, ensure to save the information as part of the profile. You can also validate before saving the details by using **Test** option.
