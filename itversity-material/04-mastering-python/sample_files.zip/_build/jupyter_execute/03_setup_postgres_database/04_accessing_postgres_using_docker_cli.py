#!/usr/bin/env python
# coding: utf-8

# ## Accessing Postgres using Docker CLI
# 
# Let us understand how to connect to Postgres Database running as part of docker container using Docker CLI.

# In[1]:


get_ipython().run_cell_magic('HTML', '', '<iframe width="560" height="315" src="https://www.youtube.com/embed/VIEkFUmBp6I?rel=0&amp;controls=1&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>')


# * We can use `docker container exec` or `docker exec` to connect to the container.
# * You can attach to the container by running `bash` using `docker exec`.
# * Also you can run single commands with out attaching the container - example: `docker exec -it itv_pg hostname -f`
# 
# > You have to use terminal to run these commands
# 
# * Attach to sms_db container - `docker exec -it itv_pg bash`
# * Run command to get hostname - `hostname -f`
# * Run command to connect to Postgres Database - `psql -U postgres`
# * You can also directly connect to Postgres Database using
# ```
# docker exec -it itv_pg psql -U postgres
# ```
# * Use `\q` to come out of the Postgres CLI.
