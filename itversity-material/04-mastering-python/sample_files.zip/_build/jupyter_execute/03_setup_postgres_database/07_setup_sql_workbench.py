#!/usr/bin/env python
# coding: utf-8

# ## Setup SQL Workbench
# 
# Let us understand how to setup and use SQL Workbench.

# In[1]:


get_ipython().run_cell_magic('HTML', '', '<iframe width="560" height="315" src="https://www.youtube.com/embed/HafnO2hryP0?rel=0&amp;controls=1&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>')


# **Why SQL Workbench**
# 
# Let us see the details why we might have to use SQL Workbench.
# * Using Database CLIs such as psql for postgres, mysql etc can be cumbersome for those who are not comfortable with command line interfaces.
# * Database IDEs such as SQL Workbench will provide required features to run queries against databases with out worrying to much about underlying data dictionaries.
# * SQL Workbench provide required features to review databases and objects with out writing queries or running database specific commands.
# * Also Database IDEs provide capabilities to preserve the scripts we develop.
# > **In short Database IDEs such as SQL Workbench improves productivity.**
# 
# **Alternative IDEs**
# 
# There are several IDEs in the market.
# * TOAD
# * SQL Developer for Oracle
# * MySQL Workbench
# and many others
# 
# **Install SQL Workbench**
# 
# Here are the instructions to setup SQL Workbench.
# * Download SQL Workbench (typically zip file)
# * Unzip and launch
# 
# Once installed we need to perform below steps which will be covered in detail as part of next topic.
# * Download JDBC driver for the database we would like to connect.
# * Get the database connectivity information and connect to the database.
