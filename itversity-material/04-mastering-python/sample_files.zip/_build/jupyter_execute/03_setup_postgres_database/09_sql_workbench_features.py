#!/usr/bin/env python
# coding: utf-8

# ## SQL Workbench Features
# 
# Here are some of the key features, you have to familiar with related to SQL Workbench.

# In[1]:


get_ipython().run_cell_magic('HTML', '', '<iframe width="560" height="315" src="https://www.youtube.com/embed/7vPJ7TKNQE4?rel=0&amp;controls=1&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>')


# * Ability to connect to different RDBMS, Data Warehouse and MPP Database servers such as Postgres, MySQL, Oracle, Redshift etc.
# * Saving profiles to connect to multiple databases.
# * Ability to access data dictionary or information schema using wizards to validate tables, columns, sequences, indexes, constraints etc.
# * Generate scripts out of existing data.
# * Ability to manage database objects with out writing any commands. We can drop tables, indexes, sequences etc by right clicking and then selecting drop option.
# * Develop SQL files and preserve them for future usage.
# 
# Almost all leading IDEs provide all these features in similar fashion.
# 
# **Usage Scenarios**
# 
# Here are **some of the usage scenarios** for database IDEs such as SQL Workbench as part of day to day responsibilities.
# * Developers for generating and validating data as part of unit testing.
# * Testers to validate data for their test cases.
# * Business Analysts and Data Analysts to run ad hoc queries to understand the data better.
# * Developers to troubleshoot data related to production issues using read only accounts.
