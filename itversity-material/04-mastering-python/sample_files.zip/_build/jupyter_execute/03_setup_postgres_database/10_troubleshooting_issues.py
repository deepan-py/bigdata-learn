#!/usr/bin/env python
# coding: utf-8

# ## Troubleshooting Issues
# 
# Let us understand how to troubleshoot common database connectivity issues related to Postgres DB.
# 
# * We need to have telnet or nc on the machine from which we are trying to connect to database to troubleshoot the issues.
# * Host not reachable - Root causes
#   * Typo in the host
#   * Using Private ip instead of public ip
#   * Might be blocked by the firewall
# * Unable to authenticate - Root causes
#   * Incorrect username or password
#   * Incorrect Hostname or Port Number
#   * Insufficient privileges for the user over the database
#   * Incorrect Database Name
# * Here are the following things you need to keep in mind while connecting to database running in docker container created in Ubuntu 18.04 Virtual Machine using GCP.
# 
# ```shell
# docker container create \
#   --name itv_pg \
#   -p 5432:5432 \
#   -h itv_pg \
#   -e POSTGRES_PASSWORD=itversity \
#   postgres
# ```
# 
#   * Make sure port number used by Postgres database in the container is published to host. In our example it is 5432. Port 5432 in container is published to port 5432 on the host.
#   * Ensure that port is opened in network firewall for the Virtual Machine in GCP using GCP Web Console.
#   * If you have `telnet` on your machine from which you are trying to connect on VM in GCP, run `telnet` command by passing public ip of GCP VM and the port 5432.

# In[ ]:




