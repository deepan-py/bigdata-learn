#!/usr/bin/env python
# coding: utf-8

# # Web Scraping using Beautiful Soup
# 
# * Problem Statement
# * Installing Pre-requisites
# * Overview of BeautifulSoup
# * Getting HTML Content
# * Processing HTML Content
# * Creating Data Frame
# * Processing Data using Data Frame APIs
