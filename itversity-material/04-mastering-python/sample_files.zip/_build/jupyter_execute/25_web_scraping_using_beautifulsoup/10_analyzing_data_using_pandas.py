#!/usr/bin/env python
# coding: utf-8

# ## Analyzing Website Data using Pandas
# 
# As we understood how to get the data from website using BeautifulSoup, let us go ahead and perform few scenarios to validate data using Pandas.
# * Create data frame using `url_and_content_list`.
# * Get length of content for each url.
# * Get word count for each url.
# * Get the list of pages with content less than 30 words.
# * Get unique word count for each url.
# * Get number of times each word repeated for each url.

# In[1]:


get_ipython().run_line_magic('run', '08_processing_data_using_data_frame_apis.ipynb')


# * Create data frame using `url_and_content_list`

# In[2]:


import pandas as pd

url_and_content_df = pd.DataFrame(url_and_content_list, columns=['url', 'content'])


# * Get length of content for each url

# In[3]:


url_and_content_df['content_length'] = url_and_content_df['content'].str.len()


# In[4]:


url_and_content_df


# * Get word count for each url

# In[5]:


url_and_content_df['word_count'] = url_and_content_df['content'].str.split(' ').str.len()


# In[6]:


url_and_content_df.sort_values('word_count')


# * Get the list of pages with content less than 30 words

# In[8]:


for url in url_and_content_df.query('word_count <= 30')['url']:
    print(url)


# * Get unique word count for each url

# In[82]:


def get_unique_count(words):
    return len(set(words))


# In[84]:


url_and_content_df['unique_word_count'] = url_and_content_df.apply(func=lambda cols: get_unique_count(cols['content'].split(' ')), axis=1)


# In[85]:


url_and_content_df


# * Get number of times each word repeated for each url

# In[95]:


words = url_and_content_df['content'].str.split(' ', expand=True)
words


# In[119]:


s = words.stack().reset_index(drop=True)


# In[120]:


word_count = s.groupby(s).agg(['count'])


# In[130]:


word_count.query('count >= 50 and count <= 100')

