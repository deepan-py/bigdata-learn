#!/usr/bin/env python
# coding: utf-8

# ## Scraping Website Content
# 
# We can use Python core library `requests` to get the content from HTML pages. Let us understand how we can pass the html content fetched by `requests` to `BeautifulSoup`.
# * `requests` provides `get` funcion to which we can pass web URL. - `python_page = requests.get(python_url)`
# * We can access content using `python_page.content`.
# * We can use pass the content to BeautifulSoup and parse the HTML Tags and data for further processing.

# In[1]:


get_ipython().run_cell_magic('HTML', '', '<iframe width="560" height="315" src="https://www.youtube.com/embed/cQLjStKMkZ4?rel=0&amp;controls=1&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>')


# In[1]:


import requests


# In[2]:


python_url = 'https://python.itversity.com/mastering-python.html'


# In[3]:


python_page = requests.get(python_url)


# In[4]:


type(python_page)


# In[5]:


# python_page.content


# In[6]:


type(python_page.content)


# ### Processing HTML Content
# 
# We can pass the content and extract HTML Tags as well as data using BeautifulSoup.
# * We have to pass the content using `html.parser` and build the BeautifulSoup object.
# * Let us prettify and print the content.

# In[7]:


from bs4 import BeautifulSoup


# In[8]:


soup = BeautifulSoup(python_page.content, 'html.parser')
# print(soup.prettify())


# In[ ]:




