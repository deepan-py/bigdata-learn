#!/usr/bin/env python
# coding: utf-8

# ## Processing Website Content
# 
# We can process the website content and extract HTML Tags as well as data using BeautifulSoup.
# * We have to pass the content using `html.parser` and build the BeautifulSoup object.
# * Let us prettify and print the content.

# In[1]:


get_ipython().run_cell_magic('HTML', '', '<iframe width="560" height="315" src="https://www.youtube.com/embed/cgDtbgFSv_4?rel=0&amp;controls=1&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>')


# In[1]:


import requests

python_base_url = 'https://python.itversity.com'
python_url = f'{python_base_url}/mastering-python.html'
python_page = requests.get(python_url)

from bs4 import BeautifulSoup

soup = BeautifulSoup(python_page.content, 'html.parser')


# In[ ]:


print(soup.prettify())


# * Let us extract all the `a` tags. We can extract links provided as part of this webpage.
# * Here is the code snippet to get the `a` tags from the landing page.

# In[3]:


for a in soup.find_all('a'):
    print(a)


# * We can use `field_name.string` to get only the value.

# In[ ]:


for a in soup.find_all('a'):
    print(a.string)


# In[ ]:


for a in soup.find_all('a'):
    print(a.get_text())


# * We can also get the urls used as part of these `a` tags.

# In[6]:


for a in soup.find_all('a'):
    print(a['href'])


# In[7]:


for a in soup.find_all('a'):
    if a.get('href'):
        print(a['href'])


# * We can also pass attributes such as `class`, `id` etc to narrow down the filter for specific class or id.

# In[8]:


for a in soup.find_all('a'):
    if a.get('class'):
        print(a['class'])


# In[10]:


classes = set()
for a in soup.find_all('a'):
    if a.get('class'):
        classes.add(tuple(a.get('class')))


# In[11]:


classes


# In[12]:


soup.find('a', {'class': 'reference internal'})


# In[13]:


soup.find('a', class_='reference internal')


# * We can also access attribute values such as `href` of `a` tag.

# In[14]:


for a in soup.find_all('a', {'class': 'reference internal'}):
    if a.get('href'):
        print(a['href'])


# In[15]:


for a in soup.find_all('a', class_='reference internal'):
    if a.get('href'):
        print(a['href'])


# In[16]:


for a in soup.find_all('a'):
    if a.get('id'):
        print(a['id'])


# * Here is an example to narrow down the filter based on `id` on top of `a` tag.

# In[17]:


soup.find('a', {'id': 'next-link'})


# In[18]:


soup.find('a', id='next-link')


# In[ ]:




