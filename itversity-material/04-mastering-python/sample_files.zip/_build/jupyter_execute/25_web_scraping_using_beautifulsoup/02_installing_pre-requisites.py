#!/usr/bin/env python
# coding: utf-8

# ## Installing Pre-requisites
# 
# Let us install prerequisites to take care of web scraping using Python. We will use Python libraries such as `requests`, `BeautifulSoup` and optionally `pandas` to perform Web Scraping and then process the data.
# * Library to get the content from HTML Pages `requests`
# * Process HTML Tags and extract data using APIs provided by`beautifulsoup4`
# * Once the data is scraped from HTML pages we can process it by using `pandas` Data Frame APIs. Alternatively, we can also use native collections and associated libraries to process the scraped data.
# 
# ```shell
# pip install beautifulsoup4
# pip install pandas
# ```

# In[1]:


get_ipython().run_cell_magic('HTML', '', '<iframe width="560" height="315" src="https://www.youtube.com/embed/hj6yg_8fLpo?rel=0&amp;controls=1&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>')


# In[1]:


get_ipython().system('pip show beautifulsoup4')


# In[3]:


get_ipython().system('pip show pandas')


# In[2]:


get_ipython().system('pip install beautifulsoup4==4.9.3')


# In[4]:


get_ipython().system('pip install pandas==1.1.5')


# In[ ]:




