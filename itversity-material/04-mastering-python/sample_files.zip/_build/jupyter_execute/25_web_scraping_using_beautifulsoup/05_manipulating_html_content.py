#!/usr/bin/env python
# coding: utf-8

# ## Manipulating HTML Content
# 
# Let us understand how to manipulate HTML content leveraging APIs provided by BeautifulSoup.
# 
# * `decompose` - to remove the tag along with the content.
# * `unwrap` - to remove the tag by retaining the content.
# * We can also change the properties of the tag, by assigning values  to the generated dict type object.
# * We can also enclose existing content or tag into new tags.

# In[1]:


get_ipython().run_cell_magic('HTML', '', '<iframe width="560" height="315" src="https://www.youtube.com/embed/v5k1iA2RkW4?rel=0&amp;controls=1&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>')


# In[2]:


html_str = """
<p>Some Text</p>
<table>
    <tbody>
        <tr>
            <th>Details</th>
            <th>URL</th>
        </tr>
        <tr>
            <td>Video Content</td>
            <td><a href="https://www.youtube.com/itversityin">YouTube Channel</a>
            </td>
        </tr>
        <tr>
            <td>Reference Material</td>
            <td><a href="https://www.github.com/dgadiraju/itversity-books">GitHub Repository</a>
            </td>
        </tr>
    </tbody>
</table>
"""


# In[3]:


from IPython.core.display import HTML, display
display(HTML(html_str))


# In[4]:


from bs4 import BeautifulSoup

soup = BeautifulSoup(html_str, 'html.parser')
print(soup.prettify())


# ### Using decompose

# In[5]:


p = soup.find('p')


# In[6]:


p.decompose()


# In[7]:


soup


# ### Using unwrap

# In[8]:


a = soup.find('a')


# In[9]:


a


# In[10]:


a.unwrap()


# In[11]:


soup


# In[12]:


from IPython.core.display import display, HTML
display(HTML(str(soup)))


# ### Updating Tag Attribute

# In[13]:


for tag in soup.find_all('tr'):
    print(tag)


# In[14]:


for tag in soup.find_all('tr'):
    print(tag['class'])


# In[15]:


for tag in soup.find_all('tr'):
    tag['class'] = 'special'


# In[16]:


for tag in soup.find_all('tr'):
    print(tag['class'])


# In[17]:


soup


# ### Wrapping Text

# In[18]:


strong = soup.new_tag('strong')


# In[19]:


strong


# In[21]:


type(strong)


# In[22]:


td = soup.find('td')


# In[23]:


td.text


# In[24]:


strong.insert(0, td.text)


# In[25]:


strong


# In[26]:


td.string = ''


# In[27]:


td


# In[28]:


td.insert(0, strong)


# In[29]:


soup


# In[30]:


for tag in soup.find_all('td'):
    if not tag.find('a'):
        strong = soup.new_tag('strong')
        strong.insert(0, tag.text)
        tag.string = ''
        tag.insert(0, strong)


# In[31]:


soup


# In[32]:


from IPython.core.display import HTML, display
display(HTML(str(soup)))


# In[ ]:




