#!/usr/bin/env python
# coding: utf-8

# ## Getting URLs from Website
# 
# Let us understand how we can get URLs from a web page's nav bar or side bar using `BeautifulSoup`.
# 
# * Here are some of the key observations about [https://python.itversity.com/mastering-python.html](ttps://python.itversity.com/mastering-python.html).
#   * All the content in the website can be accessed using nav bar on the left side.
#   * When we click on a particular topic, it will expand the sub topics.
#   * First level links are defined using class as `reference internal`.
#   * Second level links defined using class as `reference internal` under `li` with class `toctree-l1 current active`. They are visible only when we click on main topics as part of the nav bar on the left.

# In[3]:


get_ipython().run_cell_magic('HTML', '', '<iframe width="560" height="315" src="https://www.youtube.com/embed/QZfEiFsblPg?rel=0&amp;controls=1&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>')


# In[1]:


import requests

python_base_url = 'https://python.itversity.com'
python_url = f'{python_base_url}/mastering-python.html'
python_page = requests.get(python_url)

from bs4 import BeautifulSoup

soup = BeautifulSoup(python_page.content, 'html.parser')


# Let us get first level urls using `reference internal`.
# * Get all the first level urls.
# * Here are the observations about all the first level of urls from [https://python.itversity.com/mastering-python.html](ttps://python.itversity.com/mastering-python.html).
#   * All the URLs are on left nav bar under `nav` tag.
#   * We need to get hrefs from the `nav` tag.
# * Here are the steps we are going to follow:
#   * Get all the nav tags. We need to use `docs` nav.
#   * Get all the hrefs from nav using id

# In[2]:


for nav in soup.find_all('nav'):
    print(nav['id'])


# In[3]:


nav = soup.find('nav', {'id': 'bd-docs-nav'})


# In[4]:


nav = soup.find('nav', id='bd-docs-nav')


# In[5]:


for a in nav.find_all('a', {'class': 'reference internal'}):
    print(f"{python_base_url}/{a['href']}")


# In[8]:


for a in nav.find_all('a', class_='reference internal'):
    print(f"{python_base_url}/{a['href']}")


# In[10]:


for a in nav.find_all('a', {'class': 'reference internal'}):
    if a['href'] != '#':
        print(f"{python_base_url}/{a['href']}")


# In[12]:


first_level_urls = []
for a in nav.find_all('a', class_='reference internal'):
    if a['href'] != '#':
        first_level_urls.append(a['href'])


# In[13]:


for url in first_level_urls: print(url)


# Let us get second level urls using `reference internal` with in `current reference internal`.
# * Get all the first level urls.
# * Create soup objects for each of the first level urls and then get content from `toctree-l1 current active` using `reference internal`.
# * Make sure the urls are prefixed properly by replacing last part of the url with the `href` extracted.

# In[14]:


for first_level_url in first_level_urls:
    url = f"{python_base_url}/{first_level_url}"
    print(url)
    page = requests.get(url)
    soup = BeautifulSoup(page.content, 'html.parser')
    current_nav = soup.find('nav', id='bd-docs-nav')
    current_href = current_nav.find('li', class_='toctree-l1 current active')
    for second_level_href in current_href.find_all('a', class_='reference internal'):
        print(f"{'/'.join(url.split('/')[:-1])}/{second_level_href['href']}")


# In[ ]:




