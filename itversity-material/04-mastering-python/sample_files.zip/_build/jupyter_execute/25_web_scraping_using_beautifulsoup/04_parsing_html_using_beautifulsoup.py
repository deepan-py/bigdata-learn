#!/usr/bin/env python
# coding: utf-8

# ## Parsing HTML using BeautifulSoup
# 
# As we have created beautiful soup object, let us explore APIs or methods to scrape the content in HTML. 
# 
# * Fundamentally `BeautifulSoup` object is similar to a complex dict with tree structure.
# 
# Let us see some basic examples to understand how we can read the tags or attributes or content with in HTML string.
# * Accessing first occurrence of `tr`.
# * Accessing first `th` value, we can use attribute `string` or method `get_text()`
# * Accessing first occurrence of anchor tag
# * Getting the url from `href` attribute of anchor tag
# * Accessing the value of anchor tag.
# * Get all anchor tags
# * Get all `td` tags
# * Get value from all `td` tags.
# * Get values and URLs from anchor tags as a list of dicts

# In[1]:


get_ipython().run_cell_magic('HTML', '', '<iframe width="560" height="315" src="https://www.youtube.com/embed/bR9MzFdRZew?rel=0&amp;controls=1&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>')


# In[1]:


get_ipython().run_line_magic('run', '03_overview_of_beautifulsoup.ipynb')


# * Accessing first occurrence of `tr`

# In[2]:


type(soup)


# In[3]:


soup.table


# In[4]:


soup.table.tbody.tr


# In[5]:


list(soup.table.tbody.children)


# In[6]:


ele = soup.table.tbody.tr
while True:
    if not ele:
        break
    print(ele)
    ele = ele.next_sibling


# * Accessing first `th` value, we can use attribute `string` or method `get_text()`

# In[7]:


soup.table.tbody.tr.th


# In[8]:


soup.table.tbody.tr.th.string


# In[9]:


soup.table.tbody.tr.th.get_text()


# * Accessing first occurrence of anchor tag

# In[15]:


soup.table.tbody.a


# * Getting the url from `href` attribute of anchor tag

# In[16]:


soup.table.tbody.a['href']


# * Accessing the value of anchor tag.

# In[17]:


soup.table.tbody.a.string


# In[18]:


soup.table.tbody.a.get_text()


# * Get all anchor tags

# In[19]:


soup.table.tbody.find_all('a')


# In[20]:


soup.find_all('a')


# * Get all `td` tags

# In[21]:


soup.find_all('td')


# In[22]:


for a in soup.find_all('td'):
    print(a)


# * Get value from all `td` tags.

# In[23]:


# If the text in the tag have characters like new line, string might return None
for td in soup.find_all('td'):
    print(td.string)


# In[24]:


# If the text in the tag have characters like new line, we can use get_text
for td in soup.find_all('td'):
    print(td.get_text())


# In[25]:


# Stripping new line characters
for td in soup.find_all('td'):
    print(td.get_text().rstrip('\n'))


# * Get values and URLs from anchor tags as a list of dicts

# In[26]:


itversity_details = []
for a in soup.find_all('a'):
    rec = {'description': a.get_text(), 'url': a['href']}
    itversity_details.append(rec)

itversity_details


# In[27]:


itversity_details[0]['description']


# In[28]:


itversity_details[0]['url']


# In[29]:


for i in itversity_details:
    print(i['url'])


# In[ ]:




