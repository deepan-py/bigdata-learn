#!/usr/bin/env python
# coding: utf-8

# ## Power Shell and Command Prompt
