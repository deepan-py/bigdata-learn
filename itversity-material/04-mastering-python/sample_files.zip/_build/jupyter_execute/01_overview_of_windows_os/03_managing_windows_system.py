#!/usr/bin/env python
# coding: utf-8

# ## Managing Windows System
# Let us understand how to manage system effectively. We can use tools like Control Panel and Task Manager.
# * Control Panel provides administrative capabilities in a Windows System.
#   * Managing users
#   * Manage installed softwares
#   * Configure Devices such as printers over network
#   * and many more
# * When system is slow, one can go to "Task Manager" and see if any applications are causing the slowness.
# * We can kill the processes that are not important.
