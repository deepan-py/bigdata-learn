#!/usr/bin/env python
# coding: utf-8

# ## Overview of Microsoft Office
# As IT Professionals, it is important to have an idea about tools we typically use for effective communication. Microsoft provide multiple tools under the Microsoft Office umbrella.
# * Outlook - for email commmunication.
# * Teams - for interactive chats.
# * Word - to create required documents for design and support.
# * Powerpoint - to create effective presentations.
# * Excel - to create spreadsheets for simple metrics and reports.
# 
# Most of the organizations started using Google Suite and we get similar products under the Google Suite as well.
