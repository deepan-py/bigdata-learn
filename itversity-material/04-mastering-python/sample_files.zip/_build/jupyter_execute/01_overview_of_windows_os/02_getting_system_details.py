#!/usr/bin/env python
# coding: utf-8

# ## Getting System Details
# 
# Let us understand how to get System Details for Windows.
# * A computer or server is combination of CPU, Memory, Storage etc connected over a motherboard.
# * One need to have idea about the computer they are using to quantify the performance.
# * In Windows, one can go to File explorer and then to "This PC", right click and then check the details.
# * We can also go to task manager to have better understanding of the system configuration.
