#!/usr/bin/env python
# coding: utf-8

# # Overview of Windows Operating System 
# 
# * Getting System Details
# * Managing Windows System
# * Overview of Microsoft Office
# * Overview of Editors and IDEs
# * Power Shell and Command Prompt
# * Connecting to Linux Servers
# * Folders and Files
