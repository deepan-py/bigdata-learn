#!/usr/bin/env python
# coding: utf-8

# ## Filtering Data
# 
# Let us perform few tasks to understand how to filter the data in collections using loops and conditionals.
# 
# Here are the details about orders.
# * Data is in text file format
# * Each line in the file contains one record.
# * Each record contains 4 attributes which are separated by “,”
#   * order_id
#   * order_date
#   * order_customer_id
#   * order_status

# In[1]:


get_ipython().run_cell_magic('HTML', '', '<iframe width="560" height="315" src="https://www.youtube.com/embed/XjKW__S8TJc?rel=0&amp;controls=1&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>')


# In[1]:


get_ipython().run_cell_magic('sh', '', '\nls -ltr /data/retail_db/orders/part-00000')


# In[2]:


get_ipython().run_cell_magic('sh', '', '\ntail /data/retail_db/orders/part-00000')


# In[3]:


path = '/data/retail_db/orders/part-00000'
# C:\\users\\itversity\\Research\\data\\retail_db\\orders\\part-00000
orders_file = open(path)


# In[4]:


type(orders_file)


# In[5]:


orders_raw = orders_file.read()


# In[6]:


type(orders_raw)


# In[7]:


get_ipython().run_line_magic('pinfo', 'orders_raw.splitlines')


# In[8]:


orders = orders_raw.splitlines()


# In[9]:


type(orders)


# In[10]:


orders[:10]


# In[11]:


type(orders[0])


# In[12]:


len(orders)


# In[13]:


get_ipython().run_cell_magic('sh', '', '\nwc -l /data/retail_db/orders/part-00000')


# ### Task 1
# Create a function by name get_customer_orders which take orders list and customer_id as arguments and return all the orders placed by customer_id

# In[15]:


orders[:10]


# In[16]:


order = '3,2013-07-25 00:00:00.0,12111,COMPLETE'


# In[20]:


int(order.split(',')[2]) == 12111


# In[21]:


def get_customer_orders(orders, customer_id):
    orders_filtered = []
    for order in orders:
        if int(order.split(',')[2]) == customer_id:
            orders_filtered.append(order)
    return orders_filtered


# In[22]:


# Use the function and get all the orders which are placed by customer with id 12431
get_customer_orders(orders, 12431)


# In[23]:


len(get_customer_orders(orders, 12431))


# ### Task 2
# 
# Create a function by name get_customer_orders_for_month which take orders list, customer_id and month in the format YYYY-MM as arguments and return all the orders placed by customer_id for a given month.

# In[24]:


order = '3,2013-07-25 00:00:00.0,12111,COMPLETE'


# In[25]:


int(order.split(',')[2]) == 12111


# In[26]:


order.split(',')[1].startswith('2013-07')


# In[28]:


import datetime as dt
d = dt.datetime.strptime(order.split(',')[1], '%Y-%m-%d %H:%M:%S.%f')


# In[29]:


d.year == 2013 and d.month == 7


# In[30]:


int(order.split(',')[2]) == 12111 and order.split(',')[1].startswith('2013-07')


# In[33]:


def get_customer_orders_for_month(orders, customer_id, order_month):
    orders_filtered = []
    for order in orders:
        order_elements = order.split(',')
        if (int(order_elements[2]) == customer_id and
            order_elements[1].startswith(order_month)):
            orders_filtered.append(order)
    return orders_filtered


# In[34]:


# Use the function and get all the orders which are placed by customer with id 12431 in January 2014
get_customer_orders_for_month(orders, 12431, '2014-01')


# ### Task 3
# Write ad hoc code to get all the orders which are placed by customer with id 12431 in January 2014 and status is in PENDING_PAYMENT or PROCESSING

# In[35]:


for order in orders:
    order_elements = order.split(',')
    if int(order_elements[2]) == 12431         and order_elements[1].startswith('2014-01')         and (order_elements[3] in ('PROCESSING', 'PENDING_PAYMENT')):
        print(order)


# In[ ]:




