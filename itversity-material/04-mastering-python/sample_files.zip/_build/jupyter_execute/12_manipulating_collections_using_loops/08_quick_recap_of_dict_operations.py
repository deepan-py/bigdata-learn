#!/usr/bin/env python
# coding: utf-8

# ## Quick Recap of Dict Operations
# 
# Let us recap some of the important concepts and operations related to `dict`. We will primarily focus on those operations which are important for aggregations and joins.
# * `dict` contains heterogeneous type of elements.
# * Typically it is used to represent a row in a table or a sheet. But we can also use `dict` to store the aggregated results based up on a key.
# * We use `dict` for aggregations or joins, as we need to do a look up for a given key to update or insert. `list` is not efficient for lookups.
# * Each and every element in a `dict` contains key value pair where key is typically column name.
# * Here are the common `dict` operations relevant to aggregrations and joins.
#   * Adding elements to the dict
#   * Checking if the key exists
#   * Getting value for a given key
#   * Updating value if the key exists
# * As part of aggregations or joins, the output is typically a `dict`. It means we will have multiple records in the dict in the form of key value pairs.

# In[1]:


get_ipython().run_cell_magic('HTML', '', '<iframe width="560" height="315" src="https://www.youtube.com/embed/HDCSAosvEZI?rel=0&amp;controls=1&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>')


# In[1]:


order_count_by_date = {}


# In[2]:


# Adding elements in dict
order_count_by_date['2014-01-01'] = 1
order_count_by_date['2014-01-02'] = 1
order_count_by_date['2014-01-03'] = 1


# In[3]:


order_count_by_date


# In[4]:


# Checking if element exists in dict
'2014-01-01' in order_count_by_date


# In[5]:


'2014-01-04' in order_count_by_date


# In[6]:


# Getting value for a given key
order_count_by_date['2014-01-01']


# In[7]:


order_count_by_date['2014-01-04'] # Throws KeyError exception


# In[8]:


order_count_by_date.get('2014-01-01')


# In[9]:


order_count_by_date.get('2014-01-04') # Returns None


# In[16]:


# Updating value
order_count_by_date['2014-01-01'] = 2


# In[11]:


order_count_by_date


# In[12]:


order_count_by_date['2014-01-01'] = order_count_by_date['2014-01-01'] + 1 # Incrementing the existing value for a given key


# In[13]:


order_count_by_date


# In[14]:


order_count_by_date['2014-01-01'] += 1 # Incrementing the existing value for a given key


# In[15]:


order_count_by_date


# In[17]:


order_count_by_date.update({'2014-01-02': 2}) # Alternate way to update an existing element value in dict


# In[18]:


order_count_by_date


# In[ ]:




