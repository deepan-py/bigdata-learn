#!/usr/bin/env python
# coding: utf-8

# ## Preparing Data Sets
# 
# We will be primarily using orders and order_items data set to understand about manipulating collections.
# * orders is available at path **/data/retail_db/orders/part-00000**
# * order_items is available at path **/data/retail_db/order_items/part-00000**
# * orders - columns
#   * order_id - it is of type integer and unique
#   * order_date - it can be considered as string
#   * order_customer_id - it is of type integer
#   * order_status - it is of type string
# * order_items - columns
#   * order_item_id - it is of type integer and unique
#   * order_item_order_id - it is of type integer and refers to orders.order_id
#   * order_item_product_id - it is of type integer and refers to products.product_id
#   * order_item_quantity - it is of type integer and represents number of products as an order item with in an order.
#   * order_item_subtotal - it is item level revenue (product of order_item_quantity and order_item_product_price)
#   * order_item_product_price - it is product price for each item with in an order.
# * orders is parent data set to order_items and will contain one record per order. Each order can contain multiple items.
# * order_items is child data set to orders and can contain multiple entries for a given order_item_order_id.

# In[1]:


get_ipython().run_cell_magic('HTML', '', '<iframe width="560" height="315" src="https://www.youtube.com/embed/t0-GeVfbBEo?rel=0&amp;controls=1&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>')


# ### Task 1 - Read orders into collection
# Let us read orders data set into the collection called as **orders**. This will be used later.

# In[1]:


orders_path = '/data/retail_db/orders/part-00000'
# C:\\users\\itversity\\Research\\data\\retail_db\\orders\\part-00000
orders_file = open(orders_path)


# In[2]:


orders_raw = orders_file.read()


# In[3]:


orders = orders_raw.splitlines()


# In[4]:


orders[:10]


# In[5]:


len(orders) # same as number of records in the file


# ### Task 2 - Read order_items into collection
# Let us read order_items data set into the collection called as **order_items**. This will be used later.

# In[6]:


order_items_path = '/data/retail_db/order_items/part-00000'
# C:\\users\\itversity\\Research\\data\\retail_db\\order_items\\part-00000
order_items_file = open(order_items_path)


# In[7]:


order_items_raw = order_items_file.read()


# In[8]:


order_items = order_items_raw.splitlines()


# In[9]:


order_items[:10]


# In[10]:


len(order_items) # same as number of records in the file


# In[ ]:




