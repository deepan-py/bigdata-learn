#!/usr/bin/env python
# coding: utf-8

# In[1]:


get_ipython().run_line_magic('run', '07_preparing_data_sets.ipynb')


# In[2]:


orders[:10]


# In[3]:


order_items[:10]


# In[ ]:




