#!/usr/bin/env python
# coding: utf-8

# # Manipulating Collections using Loops
# 
# Let us understand how to manipulate collections using loops. We will be performing quite a lot of tasks to get enough programming practice.
# * Reading files into collections
# * Overview of Standard Transformations
# * Row level transformations
# * Getting unique elements
# * Filtering Data
# * Preparing Data Sets
# * Quick Recap of Dict Operations
# * Performing Total Aggregations
# * Performing Grouped Aggregations
# * Joining Data Sets
# * Limitations of using Loops
# * Exercises - Manipulating Collections

# In[ ]:




