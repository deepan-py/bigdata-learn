#!/usr/bin/env python
# coding: utf-8

# ## Row level transformations
# 
# Let us understand how to perform row level transformations using orders data set. Here are the details about orders.
# * Data is in text file format
# * Each line in the file contains one record.
# * Each record contains 4 attributes which are separated by “,”
#   * order_id
#   * order_date
#   * order_customer_id
#   * order_status

# In[1]:


get_ipython().run_cell_magic('HTML', '', '<iframe width="560" height="315" src="https://www.youtube.com/embed/yS-DrNN8SrI?rel=0&amp;controls=1&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>')


# In[2]:


get_ipython().run_cell_magic('sh', '', '\nls -ltr /data/retail_db/orders/part-00000')


# In[3]:


get_ipython().run_cell_magic('sh', '', '\ntail /data/retail_db/orders/part-00000')


# In[4]:


path = '/data/retail_db/orders/part-00000'
# C:\\users\\itversity\\Research\\data\\retail_db\\orders\\part-00000
orders_file = open(path)


# In[5]:


type(orders_file)


# In[6]:


orders_raw = orders_file.read()


# In[7]:


type(orders_raw)


# In[8]:


get_ipython().run_line_magic('pinfo', 'orders_raw.splitlines')


# In[9]:


orders = orders_raw.splitlines()


# In[10]:


type(orders)


# In[11]:


orders[:10]


# In[12]:


type(orders[0])


# In[14]:


len(orders)


# In[15]:


get_ipython().run_cell_magic('sh', '', '\nwc -l /data/retail_db/orders/part-00000')


# ### Task 1
# 
# Get all order ids and associated statuses. Each record in the output should be comma separated string.

# In[16]:


order = '1,2013-07-25 00:00:00.0,11599,CLOSED' # -> '1,CLOSED'


# In[ ]:


# We invokde join on delimiter


# In[19]:


get_ipython().run_line_magic('pinfo', 'str.join')


# In[22]:


':'.join(['1', '2', '3', '4'])


# In[23]:


order.split(',')[0]


# In[24]:


order.split(',')[3]


# In[25]:


[order.split(',')[0], order.split(',')[3]]


# In[26]:


','.join([order.split(',')[0], order.split(',')[3]])


# In[27]:


l = [1]


# In[28]:


l.append(2)


# In[29]:


l


# In[30]:


order_statuses = []
for order in orders:
    order_statuses.append(','.join([order.split(',')[0], order.split(',')[3]]))


# In[31]:


order_statuses[:10]


# In[32]:


len(order_statuses)


# In[33]:


order_statuses = [','.join([order.split(',')[0], order.split(',')[3]]) for order in orders] # alternative solution


# In[34]:


order_statuses[:10]


# In[35]:


len(order_statuses)


# ### Task 2
# 
# Get all order ids, the dates on which order is placed and order status. Each record in the output should be dict with following column names as keys.
# * order_id
# * order_date
# * order_status

# In[36]:


{'order_id': 1, 'order_date': '2020-12-22', 'order_status': 'COMPLETE'}


# In[37]:


def get_order_details(order):
    """Extract order details such as id, date as well as status and return as dict"""
    order_values = order.split(',')
    return ({
        'order_id': int(order_values[0]),
        'order_date': order_values[1],
        'order_status': order_values[3]
    })


# In[38]:


get_order_details('1,2013-07-25 00:00:00.0,11599,CLOSED')


# In[39]:


order_details = []
for order in orders:
    order_details.append(get_order_details(order))


# In[40]:


order_details[:10]


# In[41]:


len(order_details)


# In[42]:


order_details = [get_order_details(order) for order in orders]


# In[43]:


order_details[:10]


# In[44]:


len(order_details)


# In[ ]:




