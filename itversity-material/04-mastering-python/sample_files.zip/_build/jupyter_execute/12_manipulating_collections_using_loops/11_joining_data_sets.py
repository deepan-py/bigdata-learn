#!/usr/bin/env python
# coding: utf-8

# ## Joining Data Sets
# 
# Let us perform few tasks to understand how to perform joins over multiple collections using loops and conditionals.
# * There are different strategies for joins.
#   * Nested Loops
#   * Sort Merge
#   * Hash Join
# * We will be using Nested Loops approach using orders and order_items.
#   * Build dict for one data set - orders.
#   * Iteratively lookup into the orders data set while processing the other one - order_items
# * Develop a function get_daily_revenue which takes orders, order_items and order_status as arguments and return dict containing order_date and order_revenue. We need to get revenue considering only those orders which satisfy the status passed.

# In[1]:


get_ipython().run_cell_magic('HTML', '', '<iframe width="560" height="315" src="https://www.youtube.com/embed/SY_nOz0phU4?rel=0&amp;controls=1&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>')


# In[1]:


get_ipython().run_line_magic('run', '07_preparing_data_sets.ipynb')


# In[2]:


orders[:10]


# In[3]:


len(orders)


# In[4]:


order_items[:10]


# In[5]:


len(order_items)


# In[6]:


def get_orders_dict(orders, order_status):
    orders_dict = {}
    for order in orders:
        order_details = order.split(',')
        if order_details[3] == order_status:
            orders_dict[int(order_details[0])] = order_details[1]
    return orders_dict


# In[7]:


list(get_orders_dict(orders, 'COMPLETE').items())[:10]


# In[8]:


get_orders_dict(orders, 'COMPLETE')[3]


# In[9]:


get_orders_dict(orders, 'COMPLETE').get(3)


# In[10]:


len(get_orders_dict(orders, 'COMPLETE'))


# In[11]:


orders_dict = get_orders_dict(orders, 'COMPLETE')


# In[13]:


order_item = order_items[0]
order_item


# In[14]:


int(order_item.split(',')[1]) # order_id


# In[15]:


int(order_item.split(',')[1]) in orders_dict


# In[16]:


3 in orders_dict


# In[17]:


def get_daily_revenue(orders, order_items, order_status):
    orders_dict = get_orders_dict(orders, order_status) # dict with order_id as key and order_date as value
    daily_revenue = {} # Initializing empty dict to have date and corresponding revenue
    for order_item in order_items: 
        # Processing all order_items
        order_item_order_id = int(order_item.split(',')[1])
        order_item_subtotal = float(order_item.split(',')[4])
        
        if order_item_order_id in orders_dict:
            # Look up into orders_dict using order_id to get order_date
            orders_dict_date = orders_dict[order_item_order_id]
            if orders_dict_date in daily_revenue:
                # If order_date exists in orders_dict then add order_item_subtotal to the existing value
                # based up on the key in daily_revenue
                daily_revenue[orders_dict_date] = round(daily_revenue[orders_dict_date] + order_item_subtotal, 2)
            else:
                # If order_date does not exists then add new element to daily_revenue
                daily_revenue[orders_dict_date] = order_item_subtotal
    return daily_revenue


# In[21]:


orders_sample = [
    '4,2013-07-25 00:00:00.0,8827,CLOSED',
    '5,2013-07-25 00:00:00.0,11318,COMPLETE',
    '7,2013-07-25 00:00:00.0,4530,COMPLETE',
    '105,2013-07-26 00:00:00.0,8220,COMPLETE'
]


# In[22]:


order_items_sample = [
    '5,4,897,2,49.98,24.99',
    '6,4,365,5,299.95,59.99',
    '7,4,502,3,150.0,50.0',
    '8,4,1014,4,199.92,49.98',
    '9,5,957,1,299.98,299.98',
    '10,5,365,5,299.95,59.99',
    '11,5,1014,2,99.96,49.98',
    '12,5,957,1,299.98,299.98',
    '13,5,403,1,129.99,129.99',
    '14,7,1073,1,199.99,199.99',
    '15,7,957,1,299.98,299.98',
    '16,7,926,5,79.95,15.99',
    '239,105,403,1,129.99,129.99',
    '240,105,365,3,179.97,59.99',
    '241,105,365,2,119.98,59.99'
]


# In[23]:


get_daily_revenue(orders_sample, order_items_sample, 'COMPLETE')


# ```{note}
# Use the function to get daily revenue considering only COMPLETE orders.
# ```

# In[24]:


get_daily_revenue(orders, order_items, 'COMPLETE')


# In[25]:


len(get_daily_revenue(orders, order_items, 'COMPLETE'))


# In[26]:


get_daily_revenue(orders, order_items, 'COMPLETE')['2014-07-10 00:00:00.0']


# In[ ]:




