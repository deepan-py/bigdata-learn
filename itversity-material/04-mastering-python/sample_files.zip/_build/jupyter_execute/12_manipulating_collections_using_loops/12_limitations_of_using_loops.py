#!/usr/bin/env python
# coding: utf-8

# ## Limitations of using Loops
# 
# There are several limitations using loops.
# 
# * If you look at the below examples related to processing collections using loops, most of the functions have similar logic to iterate through elements.
# * We are spending more time on coding non business logic.
# * It results in too much of code and it can become a maintenance problem.

# In[4]:


get_ipython().run_cell_magic('HTML', '', '<iframe width="560" height="315" src="https://www.youtube.com/embed/Ru9-Bj_E4ZY?rel=0&amp;controls=1&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>')


# In[ ]:


def get_customer_orders(orders, customer_id):
    orders_filtered = []
    for order in orders:
        if int(order.split(',')[2]) == customer_id:
            orders_filtered.append(order)
    return orders_filtered


# In[ ]:


def get_customer_orders_for_month(orders, customer_id, order_month):
    orders_filtered = []
    for order in orders:
        order_elements = order.split(',')
        if (int(order_elements[2]) == customer_id and
            order_elements[1].startswith(order_month)):
            orders_filtered.append(order)
    return orders_filtered


# In[ ]:


for order in orders:
    order_elements = order.split(',')
    if int(order_elements[2]) == 12431         and order_elements[1].startswith('2014-01')         and (order_elements[3] in ('PROCESSING', 'PENDING_PAYMENT')):
        print(order)


# * Map Reduce APIs or Higher level libraries such as Pandas will solve these problems.
#   * We do not have to develop loops and conditionals.
#   * Loops and Conditionals are taken care by the existing APIs.
#   * We can just focus on business logic. It can be passed using Lambda Functions.

# In[1]:


get_ipython().run_line_magic('run', '07_preparing_data_sets.ipynb')


# ```{note}
# Here is the approach using `filter` that comes as part of Map Reduce APIs. You will learn about Map Reduce APIs soon.
# ```

# In[2]:


orders_filtered = filter(
    lambda order: int(order.split(',')[2]) == 12431,
    orders
)
list(orders_filtered)


# In[3]:


orders_filtered = filter(
    lambda order: int(order.split(',')[2]) == 12431
        and order.split(',')[1].startswith('2014-01'),
    orders
)
list(orders_filtered)


# In[4]:


orders_filtered = filter(
    lambda order: int(order.split(',')[2]) == 12431
        and order.split(',')[1].startswith('2014-01')
        and (order.split(',')[3] in ('PROCESSING', 'PENDING_PAYMENT')),
    orders
)
list(orders_filtered)


# ```{note}
# Here is the approach using Pandas library. You will learn about how to process data using Pandas in subsequent sections.
# ```

# In[5]:


import pandas as pd
orders_schema = [
    'order_id',
    'order_date',
    'order_customer_id',
    'order_status'
]
orders = pd.read_csv('/data/retail_db/orders/part-00000', names=orders_schema)


# In[6]:


orders.query('order_customer_id == 12431')


# In[7]:


orders.query('order_customer_id == 12431 & order_date.str.startswith("2014-01")')


# In[8]:


orders.query('order_customer_id == 12431 & ' +
             'order_date.str.startswith("2014-01") &' +
             'order_status in ("PROCESSING", "PENDING_PAYMENT")'
            )


# In[ ]:




