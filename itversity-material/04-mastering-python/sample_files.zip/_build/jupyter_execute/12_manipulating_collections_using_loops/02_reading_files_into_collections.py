#!/usr/bin/env python
# coding: utf-8

# ## Reading files into collections
# 
# Let us understand how to read data from files into collections.
# * Python have simple and yet rich APIs to perform file I/O
# * We can create a file object with open in different modes (by default read only mode)
# * To read the contents from the file into memory, we have APIs on top of file object such as read()
# * read() will create large string using contents of the files
# * If the data have multiple records with new line character as delimiter, we can apply splitlines() on the output of read
# * splitlines() will convert the string into list with new line character as delimiter

# In[1]:


get_ipython().run_cell_magic('HTML', '', '<iframe width="560" height="315" src="https://www.youtube.com/embed/oI4KSnDSAO8?rel=0&amp;controls=1&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>')


# In[12]:


get_ipython().run_cell_magic('sh', '', '\nls -ltr /data/retail_db/orders/part-00000')


# In[13]:


get_ipython().run_cell_magic('sh', '', '\ntail /data/retail_db/orders/part-00000')


# In[14]:


path = '/data/retail_db/orders/part-00000'
# C:\\users\\itversity\\Research
orders_file = open(path)


# In[15]:


type(orders_file)


# In[16]:


orders_raw = orders_file.read()


# In[17]:


type(orders_raw)


# In[18]:


get_ipython().run_line_magic('pinfo', 'orders_raw.splitlines')


# In[19]:


orders = orders_raw.splitlines()


# In[20]:


type(orders)


# In[21]:


orders[:10]


# In[22]:


len(orders) # same as number of records in the file


# In[ ]:




