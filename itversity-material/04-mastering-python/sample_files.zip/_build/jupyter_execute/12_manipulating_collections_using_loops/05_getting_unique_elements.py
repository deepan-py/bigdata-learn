#!/usr/bin/env python
# coding: utf-8

# ## Getting unique elements
# 
# Let us perform few tasks to understand how to extract unique elements. We can use either of these approaches.
# * We can create a list of elements first and then convert into a set.
# * We can also build set directly while extracting the information.

# In[1]:


get_ipython().run_cell_magic('HTML', '', '<iframe width="560" height="315" src="https://www.youtube.com/embed/8qx-4IXikq4?rel=0&amp;controls=1&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>')


# In[1]:


get_ipython().run_cell_magic('sh', '', '\nls -ltr /data/retail_db/orders/part-00000')


# In[2]:


get_ipython().run_cell_magic('sh', '', '\ntail /data/retail_db/orders/part-00000')


# In[3]:


path = '/data/retail_db/orders/part-00000'
# C:\\users\\itversity\\Research\\data\\retail_db\\orders\\part-00000
orders_file = open(path)


# In[4]:


type(orders_file)


# In[5]:


orders_raw = orders_file.read()


# In[6]:


type(orders_raw)


# In[7]:


get_ipython().run_line_magic('pinfo', 'orders_raw.splitlines')


# In[8]:


orders = orders_raw.splitlines()


# In[9]:


type(orders)


# In[10]:


orders[:10]


# In[11]:


type(orders[0])


# In[12]:


len(orders)


# In[13]:


get_ipython().run_cell_magic('sh', '', '\nwc -l /data/retail_db/orders/part-00000')


# ### Task 1
# 
# Get all the unique dates from orders data.

# In[27]:


order = '1,2013-07-25 00:00:00.0,11599,CLOSED'


# In[28]:


order.split(',')[1]


# In[29]:


order_dates = set()


# In[30]:


order_dates.add('2013-07-25 00:00:00.0')


# In[31]:


order_dates


# In[32]:


order_dates.add('2013-07-26 00:00:00.0')


# In[33]:


order_dates


# In[34]:


order_dates.add('2013-07-25 00:00:00.0')


# In[35]:


order_dates


# In[36]:


order_dates = set()
for order in orders:
    order_dates.add(order.split(',')[1])


# In[37]:


list(order_dates)[:10]


# In[38]:


len(order_dates)


# In[39]:


order_dates = {order.split(',')[1] for order in orders}


# In[40]:


list(order_dates)[:10]


# In[41]:


len(order_dates)


# ### Task 2
# 
# Get all the unique weekend dates from orders data.

# In[52]:


order_date = '2014-01-25 00:00:00.0'


# In[53]:


import datetime as dt


# In[54]:


dt.datetime.strptime(order_date, '%Y-%m-%d %H:%M:%S.%f')


# In[56]:


d = dt.datetime.strptime(order_date, '%Y-%m-%d %H:%M:%S.%f')


# In[57]:


get_ipython().run_line_magic('pinfo', 'd.weekday')


# In[58]:


dt.datetime.strptime(order_date, '%Y-%m-%d %H:%M:%S.%f').weekday() # Returns 0 to 6 (for Monday to Sunday)


# In[59]:


import calendar


# In[60]:


list(calendar.day_name)


# In[61]:


calendar.day_name[5]


# In[62]:


calendar.day_name[dt.datetime.strptime(order_date, '%Y-%m-%d %H:%M:%S.%f').weekday()]


# In[63]:


calendar.day_abbr[dt.datetime.strptime(order_date, '%Y-%m-%d %H:%M:%S.%f').weekday()]


# In[64]:


dt.datetime.strptime(order_date, '%Y-%m-%d %H:%M:%S.%f').weekday() in (5, 6)


# In[65]:


import datetime as dt
def is_weekend(order_date):
    return dt.datetime.strptime(order_date, '%Y-%m-%d %H:%M:%S.%f').weekday() in (5, 6)


# In[66]:


is_weekend('2014-01-25 00:00:00.0')


# In[67]:


is_weekend('2014-01-22 00:00:00.0')


# In[68]:


weekend_dates = set()
for order in orders:
    order_date = order.split(',')[1]
    if is_weekend(order_date):
        weekend_dates.add(order_date)


# In[69]:


list(weekend_dates)[:10]


# In[70]:


len(weekend_dates)


# In[ ]:




