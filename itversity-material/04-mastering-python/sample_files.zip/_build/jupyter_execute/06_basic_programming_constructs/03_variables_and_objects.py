#!/usr/bin/env python
# coding: utf-8

# ## Variables and Objects
# 
# Let us get an overview about variables and objects in Python. In Python we need not define data types for variables or objects.

# In[7]:


get_ipython().run_cell_magic('HTML', '', '<iframe width="560" height="315" src="https://www.youtube.com/embed/nbJfgGbDXPo?rel=0&amp;controls=1&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>')


# * Data types are inherited based up on the values assigned to the variables.
# * We can check the type of the variable or object using `type` function.
# * Python is interpreter based programming language which means it does not go through compilation and hence data types are not validated until run time.
# * Python variables or objects are dynamically typed. In case of compiler based programming languages such as Java, Scala etc variables or objects are statically typed.
# * We can specify data types for variables or objects starting from Python 3. However it is only informational and does not enforce.

# In[1]:


i = 10


# In[2]:


type(i) == int


# In[3]:


j: int = 10 # You can specify data type starting from Python 3
j = 'Hello'


# In[4]:


print(j)


# In[5]:


type(j)


# In[6]:


type(j) == str


# In[ ]:




