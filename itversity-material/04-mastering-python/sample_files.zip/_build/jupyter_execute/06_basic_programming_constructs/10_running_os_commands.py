#!/usr/bin/env python
# coding: utf-8

# ## Running OS Commands
# 
# Let us understand how to run OS commands using Python using libraries such as `os` and `subprocess`.

# In[1]:


get_ipython().run_cell_magic('HTML', '', '<iframe width="560" height="315" src="https://www.youtube.com/embed/9UvQ0extBhQ?rel=0&amp;controls=1&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>')


# * Python provides several libraries which can be used to run OS commands. `os` and `subprocess` are most popular ones.
# * We can import the libraries such as `os` and `subprocess` to start using them.
# * There are bunch of commands to create directories, change ownership, change permission, run general system commands etc.
# * `os` library is extensively used to read environment variables at run time of the application. It is used to pass keys and credentials to work with databases, external applications etc.
# * Typically keys and credentials should not be part of the source code.
# * `subprocess` can be used to run the commands and also to process the output.

# In[1]:


import os


# * Get current working directory.

# In[2]:


os.getcwd()


# * Read environment variables

# In[3]:


os.environ.get('PATH')


# In[4]:


os.environ.get('USER')


# In[8]:


os.environ.get('HOME')


# In[7]:


get_ipython().run_cell_magic('sh', '', '\nenv')


# In[9]:


get_ipython().run_line_magic('pinfo', 'os.environ.get')


# In[11]:


os.environ.get('PASSWORD', 'Passwords should be confidential')


# * Run `ls -ltr` command to get list of files in the current directory.

# In[12]:


import subprocess


# In[13]:


get_ipython().run_cell_magic('sh', '', '\nls -ltr')


# In[14]:


output = subprocess.check_call(['ls', '-ltr'])


# In[15]:


output


# In[16]:


output = subprocess.check_output(['ls', '-ltr'])


# In[17]:


output # output is of type binary


# In[18]:


type(output)


# In[19]:


output.decode('utf-8') # converts to string of type utf-8


# In[20]:


type(output.decode('utf-8'))


# ```{note}
# Let us convert string into list of strings. Once it is broken into list of strings we can process the data as per our requirements either by using Map Reduce libraries or Pandas based libraries.
# ```

# In[21]:


output.decode('utf-8').splitlines()


# In[22]:


type(output.decode('utf-8').splitlines())


# In[23]:


# splitlines is the function available on string type
# It converts string with line breaks into list of strings
for rec in output.decode('utf-8').splitlines():
    print(rec)


# In[ ]:




