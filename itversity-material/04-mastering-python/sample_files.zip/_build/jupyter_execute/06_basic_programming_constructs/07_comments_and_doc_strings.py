#!/usr/bin/env python
# coding: utf-8

# ## Comments and Doc Strings
# 
# Let us understand how we can add comments in Python. We will also see how doc strings are specified in Python.

# In[1]:


get_ipython().run_cell_magic('HTML', '', '<iframe width="560" height="315" src="https://www.youtube.com/embed/0Qtp243txLc?rel=0&amp;controls=1&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>')


# * Typically comments start with **#**
# * We need to start a comment with **#** always in each line.
# * We also use doc strings to provide instructions to use a function.
# * Doc strings are provided immediately after function name. We can specify it as standard Python string.
# * People typically enclose doc string with in 3 quotes (single or double). However, we can use one quote as well.

# In[1]:


print('Hello World')


# In[2]:


print("Hello World")


# In[3]:


print("Hello World from 'itversity'")


# In[4]:


print('Hello World from "itversity"')


# In[5]:


print("""Hello World from 'itversity'""")


# In[6]:


print("""Hello World from "itversity" """)


# In[7]:


var1 = 'World'
var2 = 'itversity'
print(f'Hello {var1} from {var2}')


# In[8]:


print(f'Hello {var1} from {var2}'.format(var1='world', var2='itversity'))

