#!/usr/bin/env python
# coding: utf-8

# ## All about for Loops
# 
# Let us understand how we can loop through using `for` in Python.

# In[1]:


get_ipython().run_cell_magic('HTML', '', '<iframe width="560" height="315" src="https://www.youtube.com/embed/Uti9PxgAnm8?rel=0&amp;controls=1&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>')


# * Go through range between 2 integers (5 and 10) and print them. We can use range function to get range between two integers.

# In[1]:


range(5, 11)


# In[2]:


list(range(5, 11))


# In[3]:


list(range(5, 11, 2))


# In[4]:


for i in range(5, 11): print(i)


# * Create a list of 7 elements and print alternate numbers starting from 1.
# `[1, 6, 8, 3, 7, 2, 9]`
# * In this example we are using list. It will be covered extensively at a later point in time. `list` is one of the core Python Data Structures.

# In[5]:


l = [1, 6, 8, 3, 7, 2, 9]


# In[6]:


type(l)


# In[7]:


cnt = 0
for i in l:
    if cnt % 2 == 0: # checking if cnt is even or not
        print(i)
    cnt += 1 # incrementing cnt by 1


# * Go through range between 2 integers (5 and 15) and print even numbers.

# In[8]:


for i in range(5, 16): 
    if i % 2 == 0:
        print(i)


# * Iterate through a list of months and print them.

# In[9]:


months = ['January', 'February', 'March']
for month in months:
    print(month)


# In[10]:


import calendar
list(calendar.month_name)


# In[11]:


for month in list(calendar.month_name)[1:]:
    print(month)


# ### Task 1
# 
# Take the list of ages and determine the category of the baby.
# * Print **New Born or Infant** till 6 months.
# * Print **Toddler** from 7 months to 18 months.
# * Print **Grown up** from 19 months to 144 months.
# * Print **Youth** from 145 months to 216 months

# In[12]:


ages = [7, 3, 15, 145, 217, 18]


# In[13]:


for age in ages:
    if age <= 6:
        print(f'Kid with {age} months age is "New Born or Infant"')
    elif age > 6 and age <= 18:
        print(f'Kid with {age} months age is "Toddler"')
    elif age > 18 and age <= 144:
        print(f'Kid with {age} months age is "Grown up"')
    elif age > 144 and age <= 216:
        print(f'Kid with {age} months age is "Youth"')
    else:
        print(f'Kid with {age} months age is "Adult"')


# ### Task 2
# 
# Check if each number in list of integers is even or divisible by 3.

# In[14]:


ns = [1, 6, 2, 7, 9, 11, 3, 4]


# In[15]:


for n in ns:
    if n % 2 == 0 or n % 3 == 0:
        print(f'Number {n} is even or divisible by 3')


# ### Task 3
# 
# Check if the number in list of integers is even and divisible by 3

# In[16]:


ns = [1, 6, 2, 7, 9, 11, 3, 4]


# In[17]:


for n in ns:
    if n % 2 == 0 and n % 3 == 0:
        print(f'Number {n} is even or divisible by 3')
    elif n % 3 == 0:
        print(f'Number {n} is divisible by 3 but not even')
    elif n % 2 == 0:
        print(f'Number {n} is even but not divisible by 3')


# ### Task 4
# 
# Check if each salary in list of salaries is valid. If the salary is negative or 0, then print **Salary {salary_amount} is invalid**. If the salary is `None` then print **Salary is Not Available**.

# In[18]:


sals = [100.0, 1000.0, 0.0, -100, 1200.0, None, -500]


# In[19]:


for sal in sals:
    if sal == None:
        print('Salary is Not Available')
    elif sal <= 0:
        print(f'Salary {sal} is invalid')


# In[20]:


for sal in sals:
    if not sal:
        print('Salary is Not Available')
    elif sal <= 0:
        print(f'Salary {sal} is invalid')


# ```{note}
# We can also use list of tuples with employee id and salary. You will see examples like this as part of manipulating collections later.
# ```

# In[22]:


emp_sals = [
    (1, 100.0), 
    (2, 1000.0), 
    (3, 0), 
    (4, -100), 
    (5, 1200.0), 
    (6, None), 
    (7, -500)
]


# In[23]:


for emp_sal in emp_sals:
    if emp_sal[1] == None:
        print(f'Salary for employee with id {emp_sal[0]} is Not Available')
    elif emp_sal[1] <= 0:
        print(f'Salary {emp_sal[1]} for employee with id {emp_sal[0]} is invalid')


# In[ ]:




