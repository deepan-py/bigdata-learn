#!/usr/bin/env python
# coding: utf-8

# ## Overview of Boolean Type
# 
# Let us get into the details related to Boolean.
# * Boolean typically will have `True` or `False`. In Python it is defined as `bool`.
# * You can assign boolean value by saying `a = True` or `a = False`.
# * All comparison operators which we will be seeing as part of the next topic will return bool type.
# * `not` can be used to get the negation of the `bool` value.

# In[ ]:


a = True


# In[ ]:


type(a)


# In[ ]:


a = False


# In[ ]:


type(a)


# In[ ]:


# Assigning 10 to i
i = 10


# In[ ]:


# Comparing i with some number
# Returns True
i == 10


# In[ ]:


# Comparing i with some value of type string
# Returns False
i == '10'


# In[ ]:


type(i == 10)


# In[ ]:


type(i == '10')


# In[ ]:


i = 10


# In[ ]:


i == 10


# In[ ]:


not i == 10

