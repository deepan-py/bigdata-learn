#!/usr/bin/env python
# coding: utf-8

# ## Getting Help
# 
# We have already seen how to get help earlier. Let's deep dive to understand more about getting help using Python.

# In[1]:


get_ipython().run_cell_magic('HTML', '', '<iframe width="560" height="315" src="https://www.youtube.com/embed/n5AigWIswkQ?rel=0&amp;controls=1&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>')


# * We can get help either in Python CLI or Jupyter Notebook.
# * Help can be launched by calling help()
# * It will launch CLI and we can enter a class name or function name.
# * We can hit ctrl+c to come out of help
# * We can also get help on a class or function by passing them to help function interactively.
# * We will be able to get help by passing objects as well. In cases like str it will try to get the help on the value of variable.

# ### Tasks
# 
# Here are some of the tasks we can perform to understand help better.
# * Launch help
# * Get help for str
# * Get help for str.lstrip function
# * Exit from help
# * Get help on str and str.lstrip directly
# * Create an integer object i=0 and get help by passing the object.
