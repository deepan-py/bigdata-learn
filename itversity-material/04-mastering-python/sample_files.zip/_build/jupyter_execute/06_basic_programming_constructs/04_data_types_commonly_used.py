#!/usr/bin/env python
# coding: utf-8

# ## Data Types - Commonly used
# Python has several data types which are commonly used. There are advanced data types such as Data Frames as part of modules such as pandas.

# In[2]:


get_ipython().run_cell_magic('HTML', '', '<iframe width="560" height="315" src="https://www.youtube.com/embed/AY86oJYfgbg?rel=0&amp;controls=1&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>')


# * Numeric - `int`, `float`, complex
# * Alpha Numeric - `str`
# * Boolean - `bool` (it will be covered in another topic)
# * Collections
#   * `list`
#   * `set`
#   * `dict`
# * `tuple`
# * type(VARIABLE_NAME) returns the data type of the variable.
# * All the data types are nothing but classes.
# * We can type cast data types by invoking constructor.

# In[ ]:




