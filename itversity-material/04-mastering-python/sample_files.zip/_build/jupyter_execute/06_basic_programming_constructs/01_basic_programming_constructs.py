#!/usr/bin/env python
# coding: utf-8

# # Basic Programming Constructs
# 
# 
# As part of this section we will see basic programming constructs in Python.
# 
# * Getting Help
# * Variables and Objects
# * Data Types - Commonly used
# * Operators in Python
# * Comments and Doc Strings
# * Conditionals
# * All about for loops
# * Running OS Commands

# In[ ]:




