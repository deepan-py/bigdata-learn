#!/usr/bin/env python
# coding: utf-8

# ## eval and exec
# 
# Let us understand how we can use `eval` and `exec` in Python.
# 
# * Typically we perform arithmetic operations like this `a = b + c`.
# * We can also use `eval` and `exec` for the same.
# * `eval` typically evaluates the expression. We need to assign the value to some variable when we use `eval`.
# * `exec` executes the statement.

# In[1]:


b = 10


# In[2]:


c = 20


# In[3]:


a = b + c


# In[4]:


a


# In[5]:


eval('b + c')


# In[9]:


exec('d = b + c')


# In[10]:


d


# In[ ]:




