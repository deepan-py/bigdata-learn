#!/usr/bin/env python
# coding: utf-8

# ## Conditionals
# Let us go through conditionals in Python. We typically use “if else” for conditionals. Let us perform a few tasks to understand how conditionals are developed.

# In[1]:


get_ipython().run_cell_magic('HTML', '', '<iframe width="560" height="315" src="https://www.youtube.com/embed/vo2_1q9bXco?rel=0&amp;controls=1&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>')


# * Create a variable i with 5. Write a conditional to print whether i  is even or odd.

# In[1]:


i = 5


# In[2]:


# Regular if else
if i % 2 == 0:
    print("even")
else:
    print("odd")


# In[ ]:


# (cond) ? on_true : on_false


# In[ ]:


# on_true (cond) else on_false


# In[3]:


# Ternary Operator (one liner)
print("even") if i % 2 == 0 else print("odd")


# * Improvise it to check if i is 0 and print zero

# In[8]:


i = int(input("Enter an integer: "))


# In[9]:


if i == 0:
    print(f"i is 0")
elif i % 2 == 0:
    print(f"{i} is even")
else:
    print(f"{i} is odd")


# * Object of type `None` is special object which represent nothing. At times we need to check against `None`.

# In[10]:


n = None
print('Not None') if n else print(n)


# In[8]:


i = int(input("Enter an integer: "))


# In[10]:


if i:
    print('Not None') 
else: print(n)


# In[30]:


i = int(input("Enter an integer: "))


# In[31]:


if not i % 2 == 0: print(f'{i} is odd')


# * We can also perform boolean operations such as **boolean or** and **boolean and**.

# ### Task 1
# 
# Determine the category of the baby.
# * Print **New Born or Infant** till 6 months.
# * Print **Toddler** from 7 months to 18 months.
# * Print **Grown up** from 19 months to 144 months.
# * Print **Youth** from 145 months to 216 months

# In[16]:


age = int(input('Enter age in months: '))


# In[17]:


if age <= 6:
    print('New Born or Infant')
elif age > 6 and age <= 18:
    print('Toddler')
elif age > 18 and age <= 144:
    print('Grown up')
elif age > 144 and age <= 216:
    print('Youth')
else:
    print('Adult')


# ### Task 2
# 
# Check if the number is even or divisible by 3.

# In[22]:


n = int(input('Enter integer: '))


# In[23]:


if n % 2 == 0 or n % 3 == 0:
    print(f'Number {n} is even or divisible by 3')


# ### Task 3
# 
# Check if the number is even and divisible by 3

# In[26]:


n = int(input('Enter integer: '))


# In[27]:


if n % 2 == 0 and n % 3 == 0:
    print(f'Number {n} is even and divisible by 3')
elif n % 3 == 0:
    print(f'Number {n} is divisible by 3 but not even')
elif n % 2 == 0:
    print(f'Number {n} is even but not divisible by 3')


# In[ ]:




