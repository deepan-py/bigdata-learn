#!/usr/bin/env python
# coding: utf-8

# ## Signing up for GCP
# 
# GCP is one of the leading cloud provider. We will be primarily using it to get hands on with respect to several skills such as Linux, Python, SQL etc over the duration of this course as well as other courses.

# In[1]:


get_ipython().run_cell_magic('HTML', '', '<iframe width="560" height="315" src="https://www.youtube.com/embed/ETZJln4jtAo?rel=0&amp;controls=1&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>')


# * Google provides USD 300 credit for one year to try out GCP.
# * Go to [Google Cloud](https://cloud.google.com) and complete sign up process.
# * Make sure to avail USD 300 credit.
# * Once you complete the sign up process you will get access to Web Console of GCP.
