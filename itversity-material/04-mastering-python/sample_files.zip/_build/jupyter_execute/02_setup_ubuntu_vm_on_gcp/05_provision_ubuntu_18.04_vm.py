#!/usr/bin/env python
# coding: utf-8

# ## Provision Ubuntu 18.04 Virtual Machine
# 
# As we got GCP account and understood pricing, now it is time to provision Ubuntu 18.04 Virtual Machine.

# In[1]:


get_ipython().run_cell_magic('HTML', '', '<iframe width="560" height="315" src="https://www.youtube.com/embed/rLTbhSaXhSM?rel=0&amp;controls=1&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>')


# * Setup Virtual Machine
# * Connect to Virtual Machine using Web Console.
# * Configure Static ip to the Virtual Machine so that the public ip does not change on reboot.
