#!/usr/bin/env python
# coding: utf-8

# ## Setup Docker
# Let us setup docker. We will be using it to create Database required for this course.

# In[1]:


get_ipython().run_cell_magic('HTML', '', '<iframe width="560" height="315" src="https://www.youtube.com/embed/wP7BhXrJKR8?rel=0&amp;controls=1&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>')


# * Go to this [link](https://www.digitalocean.com/community/tutorials/how-to-install-and-use-docker-on-ubuntu-18-04) and follow the instructions to setup Docker.
# * Make sure to add the user to `docker` group so that we do not have to use `sudo` to manage Docker related components such as images, containers etc.
# * Let us validate docker by creating simple **Hello World** Container.
# * Here are the commands to setup docker and validate. Make sure to run these commands one at a time.
# 
# ```shell
# sudo apt update
# sudo apt install apt-transport-https ca-certificates curl software-properties-common -y
# curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo apt-key add -
# sudo add-apt-repository "deb [arch=amd64] https://download.docker.com/linux/ubuntu bionic stable"
# sudo apt update
# apt-cache policy docker-ce
# sudo apt install docker-ce -y
# 
# sudo systemctl status docker # Validates that docker is started
# 
# sudo usermod -aG docker ${USER}
# 
# docker run hello-world
# ```
