#!/usr/bin/env python
# coding: utf-8

# # Setup Ubuntu VM on GCP
# 
# * Signing up for GCP
# * Understanding GCP Web Console
# * Overview of GCP Pricing
# * Provision Ubuntu 18.04 Virtual Machine
# * Setup Docker 
# * Validating Python 
# * Setup Jupyter Lab
# 
# You can access videos for this course module using [Setup labs on Ubuntu 18.04 VM on GCP using Docker to learn Python and SQL](https://www.youtube.com/playlist?list=PLf0swTFhTI8qOGXb3e6BmqHGQ-tnsP51q)
