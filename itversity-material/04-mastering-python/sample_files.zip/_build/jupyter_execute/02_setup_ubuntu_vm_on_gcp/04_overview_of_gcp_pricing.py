#!/usr/bin/env python
# coding: utf-8

# ## Overview of GCP Pricing
# 
# It is very important to spend some time and understand the pricing of GCP for the virtual machine.

# In[1]:


get_ipython().run_cell_magic('HTML', '', '<iframe width="560" height="315" src="https://www.youtube.com/embed/qfUbPLsLQcQ?rel=0&amp;controls=1&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>')


# * GCP Provides Pricing Calculator to estimate the cost.
# * Here is the configuration for our Virtual Machine.
#   * 16 GB RAM
#   * At least 4 core CPU
#   * 60 GB Storage
# * For Storage, we will have fixed cost as long as it is provisioned.
# * For Virtual Machine (CPU and Memory), we will be paying only for the time for which the Virtual Machine is up and running.
# * Best Practices to get most out of the credit or to reduce the cost of using GCP.
#   * Ensure that you stop the Virtual Machine when you are not using.
#   * Make sure to use static ip address (incurs a nominal fixed cost).
#   * Make sure to open only those ports that are relevant to you (to avoid attacks).
