#!/usr/bin/env python
# coding: utf-8

# ## Setup Jupyter Lab
# 
# Let us setup Jupyter Lab on Ubuntu VM. This will also facilitate you to understand firewall configuration in GCP.

# In[1]:


get_ipython().run_cell_magic('HTML', '', '<iframe width="560" height="315" src="https://www.youtube.com/embed/f4V6Gg3ybFw?rel=0&amp;controls=1&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>')


# * Create Python based virtual environment - `python3 -m venv demojl`
# * Activate virtual environment - `source demojl/bin/activate`
# * Install required dependencies for Jupyter Lab - `pip install jupyterlab`
# * Launch Jupyter Lab - `jupyter lab --ip 0.0.0.0`
# * At this time, you will not be able to access Jupyter Lab
# * Go to firewall and open the port using GCP Web Console
# * Now enter the ip address and port number to access the Jupyter Lab UI.
