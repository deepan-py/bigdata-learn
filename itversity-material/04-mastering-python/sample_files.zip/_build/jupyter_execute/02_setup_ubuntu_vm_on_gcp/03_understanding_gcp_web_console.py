#!/usr/bin/env python
# coding: utf-8

# ## Understanding GCP Web Console
# 
# Let us have some basic idea about GCP Web Console.

# In[1]:


get_ipython().run_cell_magic('HTML', '', '<iframe width="560" height="315" src="https://www.youtube.com/embed/1OVHjHTkP3M?rel=0&amp;controls=1&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>')


# * We can use GCP Web Console for managing Google Cloud Infrastructure. Here I am highlighting some of them.
#   * Provision Virtual Machines
#   * Deploy Applications
#   * Leverage Existing out of the box services
# * We should also know how to get billing details. You can go to Billing Section and should be able review the credits.
# * For this section, we will be primarily focusing on these.
#   * Provision Virtual Machine
#   * Stop and Start Virtual Machine
#   * Make sure to configure firewalls for the virtual machine created.
