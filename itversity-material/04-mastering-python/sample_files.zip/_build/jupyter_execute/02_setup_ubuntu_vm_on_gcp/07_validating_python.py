#!/usr/bin/env python
# coding: utf-8

# ## Validating Python
# 
# Let us validate Python on Ubuntu VM that is provisioned.

# In[1]:


get_ipython().run_cell_magic('HTML', '', '<iframe width="560" height="315" src="https://www.youtube.com/embed/L-72r4mxhZI?rel=0&amp;controls=1&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>')


# * By default, Ubuntu 18.04 VM will have Python3 installed. You can run `python3` and launch Python CLI.
# * However, there might not be additional important modules such as pip, venv etc.
# * We need to validate and ensure that they are installed. If `pip` and `venv` are not installed you can install them using these commands.
# 
# ```shell
# sudo apt install python3-pip -y
# python3 -m pip install configparser
# 
# sudo apt install python3-venv -y
# python3 -m venv testing
# ls -ltr
# rm -rf testing
# ```
