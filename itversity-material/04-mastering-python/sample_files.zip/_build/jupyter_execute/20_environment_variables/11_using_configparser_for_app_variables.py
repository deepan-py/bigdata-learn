#!/usr/bin/env python
# coding: utf-8

# ## Using configparser for App Variables
# 
# Let us understand how we can use `configparser` to pass the application variables.
# * Make sure you have `ini` file with all sections that are relevant for your application. You can also use other standard formats such as JSON, YML etc.
# * Create `configparser` object and read the `ini` file by passig the path as argument.
# * You can read specific section to build required URLs or objects to connect to external applications.
# * Now, we can pass the dict to `format` to replace the variables in the string with actual values from the dict.

# * Make sure `application.ini` is available. It is typically placed in a location which is accessible to the Linux user using which we deploy the application.

# In[ ]:


get_ipython().system('ls -ltr /home/${USER}/application.ini')


# In[ ]:


get_ipython().system('cat /home/${USER}/application.ini')


# * Reading the `ini` file using `configparser`.

# In[ ]:


import configparser


# In[ ]:


config = configparser.ConfigParser()


# In[ ]:


# This will make sure that the case of keys in dict is not converted to lower
config.optionxform = str


# In[ ]:


import getpass
username = getpass.getuser()


# In[ ]:


config.read(f'/home/{username}/application.ini')


# * Reviewing `POSTGRES_DB` section. We can use `dict` to convert `section` object to dict.

# In[ ]:


type(config['POSTGRES_DB'])


# In[ ]:


dict(config['POSTGRES_DB'])


# * Replacing the values in `connection_url` using `format`.

# In[ ]:


connection_url = 'postgresql://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}'


# In[ ]:


connection_url.format(**dict(config['POSTGRES_DB']))


# In[ ]:




