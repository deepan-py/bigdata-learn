#!/usr/bin/env python
# coding: utf-8

# ## Overview of SDLC
# 
# Let us get an overview of SDLC. It's full form is **Software Development Life Cycle**.
# 
# * Let us go through the typically SDLC.
#   * We start with requirements, then design and then development.
#   * Once the code is developed, it will go through multiple levels of testing.
#     * Integration
#     * Functionality Testing
#     * User Acceptance Testing
#   * Once the code is thoroughly tested, it will go to production.
#   * Any application will go through at least development, one cycle of testing and then production.
#   * Design, Development, Testing, Production are called as Phases.
# * For each phase we will have phase specific external systems the application might have to talk to.
# * The most commonly used ones are database, 3rd party REST API Gateways.
# * For security reasons, we need to use different databases and REST API Gateways with different values.
# * We should not hardcode as part of the application. One of the way to pass these phase specific variables is by leveraging environment variables.
# * Let us undertand how it can be handled using `os` module as part of the subsequent topics in this section. There are alternative ways as well.
#   * Using `configparser` by specifying phase specific values in the form of JSON, YAML etc.

# In[ ]:




