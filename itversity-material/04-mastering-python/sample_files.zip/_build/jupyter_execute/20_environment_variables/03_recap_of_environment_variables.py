#!/usr/bin/env python
# coding: utf-8

# ## Recap of Environment Variables
# 
# Let us recap of environment variables. In the subsequent topics in this section, we will understand how to process them using Python.
# * Environment Variables will play a significant role in controlling linux sessions as well as behavior of our programs.
# * To get environment variables for a given session, you can do the following:
#   * Go to Terminal
#   * Run `env` command to list all the environment variables
# * If you run `!env` using Jupyter, you will see the difference as the context of Jupyter is different from the terminal.
# * You can read values of individual environment variables using `echo` command.
# * Here are some of the important environment variables.
#   * `USER` - the current user logged into the Linux Environment
#   * `HOME` - the current user's home directory.
#   * `PWD` - the current directory you are in.
#   * `PATH` - the locations where it will search for the executables of the commands.
# * Let us review the values of important environment variables.

# In[ ]:


get_ipython().system('env')


# In[ ]:


get_ipython().system('echo $USER')


# In[ ]:


get_ipython().system('echo $HOME')


# In[ ]:


get_ipython().system('echo $PWD')


# In[ ]:


get_ipython().system('echo $PATH')

