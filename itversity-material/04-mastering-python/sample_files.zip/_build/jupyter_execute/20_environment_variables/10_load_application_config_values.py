#!/usr/bin/env python
# coding: utf-8

# ## Load Application Config Values
# 
# Let us understand how to load application config values using `configparser`. We will be using `ini` file format.
# * Create `configparser` object.
# * Read the `ini` file by passing the path as string.
# * Now you should be able to read the config values as sections.

# In[ ]:


import configparser


# In[ ]:


config = configparser.ConfigParser()


# In[ ]:


type(config)


# In[ ]:


import getpass
username = getpass.getuser()


# In[ ]:


config.read(f'/home/{username}/application.ini')


# In[ ]:


get_ipython().system('cat /home/${USER}/application.ini')


# * `configparser` object is similar to dict.
# * You can read the values for a given section as below. Here we are reading **DEFAULT** section.

# In[ ]:


config['DEFAULT']


# In[ ]:


# We are reading the value for property FOO under section DEFAULT.
config['DEFAULT']['FOO']


# In[ ]:


# Reading POSTGRES_DB section
config['POSTGRES_DB']


# In[ ]:


# Reading the value for property POSTGRES_DB under section DEFAULT.
config['POSTGRES_DB']['DB_HOST']


# In[ ]:


# We can also read values under DEFAULT section using specific sections.
config['POSTGRES_DB']['FOO']


# In[ ]:


pg_section = config['POSTGRES_DB']


# In[ ]:


# We will see the variables under DEFAULT in all sections
# Even though keys are originally in upper case, here you can see them in lower case.
dict(pg_section)


# In[ ]:


config['DEFAULT']['FOO']


# In[ ]:


# The variables under other sections are not accessible using DEFAULT
config['DEFAULT']['DB_HOST']


# In[ ]:


config = configparser.ConfigParser()


# In[ ]:


# This will make sure that the case of keys in dict is not converted to lower
config.optionxform = str


# In[ ]:


config.read(f'/home/{username}/application.ini')


# In[ ]:


dict(config['POSTGRES_DB'])


# In[ ]:




