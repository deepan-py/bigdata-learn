#!/usr/bin/env python
# coding: utf-8

# ## Overview of dotenv
# 
# Let us understand how to pass bunch of environment variables using `dotenv`.
# * We can update our profiles in Linux or export as part of the session in terminal and access those using `os` module.
# * Here are the steps to validate this.
#   * Go to Terminal
#   * Say `export FOO=bar`
#   * Launch Python CLI from the terminal and run the below code.
# 
# ```python
# import os
# os.environ.get('FOO')
# ```
# 
# * You can also try accessing it from Jupyter. But it did not work as Jupyter is not related to the terminal session.

# In[ ]:


import os


# In[ ]:


os.environ.get('FOO')


# * It can become tedious to export all the environment variables related to **dev** or **qa** or **prod** in the session or to update the profile.
# * We can use `dotenv` module. Here are the steps you need to follow.
#   * Make sure `python-dotenv` module is installed.
#   * Create `.env` file in the home directory.
#   * Add all the relevant environment variables related to the application. We will see an example using database connectivity information.
#   * Import `dotenv` and then invoke `load_dotenv`. It will take care of loading all the environment variables.

# In[ ]:


# You can confirm if dotenv is installed or not by running this command
get_ipython().system('pip list|grep dotenv')


# In[ ]:


get_ipython().system('rm /home/${USER}/.env')


# In[ ]:


get_ipython().system('touch /home/${USER}/.env')


# In[ ]:


get_ipython().system('ls -ltr /home/${USER}/.env')


# In[ ]:


# There should not be export for the variables that are being added to .env
get_ipython().system('echo "DB_HOST=pg.itversity.com" >> /home/${USER}/.env')


# In[ ]:


get_ipython().system('echo "DB_PORT=5432" >> /home/${USER}/.env')


# In[ ]:


get_ipython().system('echo "DB_NAME=retail_db" >> /home/${USER}/.env')


# In[ ]:


get_ipython().system('echo "DB_USER=retail_user" >> /home/${USER}/.env')


# In[ ]:


get_ipython().system('echo "DB_PASS=retail_pass" >> /home/${USER}/.env')


# In[ ]:


get_ipython().system('cat /home/${USER}/.env')


# In[ ]:


import dotenv


# In[ ]:


get_ipython().run_line_magic('pinfo', 'dotenv.load_dotenv')


# In[ ]:


# If .env is part of home directory with .env name, you don't need to specify dotenv_path
dotenv.load_dotenv()


# In[ ]:


os.environ.get('DB_HOST')

