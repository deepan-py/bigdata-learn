#!/usr/bin/env python
# coding: utf-8

# ## Create Application Config File
# 
# Let us have a config file created under our home directory. We will see how to use the properties as part of the next topic.
# * Create a file by name `application.ini` under home directory.
#   * Go to terminal.
#   * Create a file using nano editor or vi editor. If you are not comfortable you can use the below python code.
#   * In case you want to use nano editor, copy paste the below content to **/home/${USER}/application.ini**
# 
# ```
# [DEFAULT]
# FOO = bar
# 
# [POSTGRES_DB]
# DB_HOST = pg.itversity.com
# DB_PORT = 5432
# DB_NAME = retail_db
# DB_USER = retail_user
# DB_PASS = retail_pass
# ```

# In[ ]:


config_str = '''[DEFAULT]
FOO = bar

[POSTGRES_DB]
DB_HOST = pg.itversity.com
DB_PORT = 5432
DB_NAME = retail_db
DB_USER = retail_user
DB_PASS = retail_pass'''


# In[ ]:


import getpass
username = getpass.getuser()


# In[ ]:


config_file = open(f'/home/{username}/application.ini', 'w')


# In[ ]:


config_file.write(config_str)


# In[ ]:


config_file.close()


# In[ ]:


get_ipython().system('ls -ltr /home/${USER}/application.ini')


# In[ ]:


get_ipython().system('cat /home/${USER}/application.ini')


# In[ ]:




