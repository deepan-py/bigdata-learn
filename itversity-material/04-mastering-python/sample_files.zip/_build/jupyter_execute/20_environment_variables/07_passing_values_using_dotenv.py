#!/usr/bin/env python
# coding: utf-8

# ## Passing Values using dotenv
# 
# Let us understand how to pass values using `dotenv` effectively.
# * Even though we can use `os.environ.get` to read the enviornment variables after they are loaded using `dotenv`, it is a tedious process.

# In[ ]:


import dotenv


# In[ ]:


dotenv.load_dotenv()


# In[ ]:


import os


# In[ ]:


os.environ.get('DB_HOST')


# In[ ]:


os.environ.get('DB_PORT')


# * You can read all the values at once using `dotenv.dotenv_values` after the values from **.env** are loaded using `dotenv.load_dotenv`

# In[ ]:


# It is similar to dict
dotenv.dotenv_values()


# * This is how, we typically have database url strings.

# In[ ]:


connection_url = 'postgresql://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}'


# * We can replace all the variables using `format` on string.

# In[ ]:


# format typically takes keyword arguments
get_ipython().run_line_magic('pinfo', 'connection_url.format')


# In[ ]:


# We can convert dict to an argument for varrying keyword arguments like this
connection_url.format(**dotenv.dotenv_values())


# In[ ]:


# The above code is effective alternative for this.

envs = dotenv.dotenv_values()
connection_url.format(
    DB_HOST=envs['DB_HOST'],
    DB_PORT=envs['DB_PORT'],
    DB_NAME=envs['DB_NAME'],
    DB_USER=envs['DB_USER'],    
    DB_PASS=envs['DB_PASS']
)


# In[ ]:


import dotenv
dotenv.load_dotenv()
connection_url = 'postgresql://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}'
connection_url.format(**dotenv.dotenv_values())

