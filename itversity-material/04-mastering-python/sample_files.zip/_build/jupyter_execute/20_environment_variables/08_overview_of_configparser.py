#!/usr/bin/env python
# coding: utf-8

# ## Overview of configparser
# 
# Let us go through the details related to configparser. The variables which will control the run time behavior of the application are also known as configuration variables, application variables, run time variables etc.
# * On top of using **.env**, another popular way of managing these variables is by using `configparser`.
# * You can check if `configparser` is already installed by running below command.

# In[ ]:


get_ipython().system('pip list|grep configparser')


# * We can represent the configuration variables in different formats.
#   * `ini`
#   * `json`
#   * `yml`
# * We can define variables using the supported file formats.
# * We can group related variables using sections.
# * Here is an example of using `ini` format to define the configuration variables.
# 
# ```
# [DEFAULT]
# FOO = bar
# 
# [POSTGRES_DB]
# DB_HOST = pg.itversity.com
# DB_PORT = 5432
# DB_NAME = retail_db
# DB_USER = retail_user
# DB_PASS = retail_pass
# ```

# In[ ]:




