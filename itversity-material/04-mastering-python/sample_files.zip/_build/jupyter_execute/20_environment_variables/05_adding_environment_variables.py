#!/usr/bin/env python
# coding: utf-8

# ## Adding Environment Variables
# 
# Earlier we have understood how to access environment variables using Python. Now, let us go through the details about setting up environment variables.
# * As seen earlier, we might have to use different values in our application based on the phase such as development, testing, production etc.
# * First, you need to import `os` module.

# In[ ]:


import os


# * `os.environ` have a method called `setdefault`. It can be used to set the environment variables.
# * The variables are available only for that session.

# In[ ]:


get_ipython().run_line_magic('pinfo', 'os.environ.setdefault')


# In[ ]:


os.environ.setdefault('DB_USER', 'itversity')


# * If there is OS level environment variable with the same name or key, the OS level value will take prcedence.
# * In the below example `USER` is a OS level environment variable which returns logged in user. Even though we tried to set using `setdefault`, it does not have any effect.

# In[ ]:


os.environ.get('USER')


# In[ ]:


os.environ.setdefault('USER', 'itversity1')


# In[ ]:


os.environ.get('USER')


# In[ ]:




