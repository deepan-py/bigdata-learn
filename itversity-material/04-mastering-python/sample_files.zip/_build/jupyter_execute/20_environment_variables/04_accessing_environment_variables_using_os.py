#!/usr/bin/env python
# coding: utf-8

# ## Accessing Environment Variables using Python
# 
# Let us understand how to access environment variables using Python.
# * We can use `os` module to access environment variables.

# In[ ]:


import os


# * `os` have an instance called as `environ`.
# * `environ` exposes environment variables in the form of key value pairs.

# In[ ]:


os.environ


# * You can check the type of `environ`. It is of type `os._Environ` class.

# In[ ]:


type(os.environ)


# * We can read the values of variables using `get` function.

# In[ ]:


# Reading the value of USER
os.environ.get('USER')


# In[ ]:


# Reading the value of PATH
os.environ.get('PATH')


# In[ ]:




