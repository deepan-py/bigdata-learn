#!/usr/bin/env python
# coding: utf-8

# ## Process dict values
# 
# Let us understand how we can process the values in dicts.
# * We have already seen a function called as `values` which return all the values as a list like object.

# In[ ]:


order_item_subtotals = {
    1: 299.98,
    2: 199.99,
    3: 250.0,
    4: 129.99
}


# In[ ]:


order_item_subtotals


# In[ ]:


type(order_item_subtotals)


# In[ ]:


order_item_subtotals.values()


# * If we would like to get total revenue by adding all the values, we can apply `sum`.

# In[ ]:


sum(order_item_subtotals.values())


# In[ ]:


# min
min(order_item_subtotals.values())


# In[ ]:


# max
max(order_item_subtotals.values())


# In[ ]:


# sort
sorted(order_item_subtotals.values())


# * We can convert the values to `list` and perform all available list operations.

# In[12]:


list(order_item_subtotals.values())


# * The values in the `dict` need not be unique. Sometimes, we might want to get all the unique values.
# * For example, get all the unique sports that is part of this dict. In this `dict`, the key is name of the sports person and the value is the sport the person plays.
# 
# ```{note}
# You can always use `set` to get unique elements from any list type object.
# ```

# In[13]:


famous_players = {
    'Pete Sampras': 'Tennis',
    'Sachin Tendulkar': 'Cricket',
    'Brian Lara': 'Cricket',
    'Diego Maradona': 'Soccer',
    'Roger Federer': 'Tennis',
    'Ian Thorpe': 'Swimming',
    'Ronaldo': 'Soccer',
    'Usain Bolt': 'Running',
    'P. V. Sindhu': 'Badminton',
    'Shane Warne': 'Cricket',
    'David Beckham': 'Cricket',
    'Michael Phelps': 'Swimming'
}


# In[15]:


famous_players.values()


# In[16]:


len(famous_players.values())


# In[17]:


set(famous_players.values())


# In[18]:


len(set(famous_players.values()))


# In[ ]:




