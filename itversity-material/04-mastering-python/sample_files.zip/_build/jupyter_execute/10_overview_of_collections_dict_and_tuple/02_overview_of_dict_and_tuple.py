#!/usr/bin/env python
# coding: utf-8

# ## Overview of dict and tuple
# 
# As we have gone through details related to `list` and `set`, now let us get an overview of `dict` and `tuple` in Python.

# In[1]:


get_ipython().run_cell_magic('HTML', '', '<iframe width="560" height="315" src="https://www.youtube.com/embed/G79XqjTXm74?rel=0&amp;controls=1&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>')


# * `dict`
#   * Group of heterogeneous elements
#   * Each element is a key value pair.
#   * All the keys are unique in the `dict`.
#   * `dict` can be created by enclosing elements in `{}`. Key Value pair in each element are separated by `:` - example `{1: 'a', 2: 'b', 3: 'c', 4: 'd'}`
#   * Empty `dict` can be initialized using `{}` or `dict()`.
# * `tuple`
#   * Group of heterogeneous elements.
#   * We can access the elements in `tuple` only by positional notation (by using index)
#   * `tuple` can be created by enclosing elements in `()` - example `(1, 2, 3, 4)`.

# In[2]:


d = {'id': 1, 'first_name': 'Scott', 'last_name': 'Tiger', 'amount': 1000.0} # dict


# In[3]:


d


# In[4]:


type(d)


# In[5]:


d = dict() # Initializing empty dict


# In[6]:


d


# In[7]:


d = {} # d will be of type dict


# In[8]:


type(d)


# In[9]:


t = (1, 'Scott', 'Tiger', 1000.0) # tuple


# In[10]:


type(t)


# In[11]:


t


# In[12]:


t = ()


# In[13]:


t


# In[14]:


type(t)


# In[15]:


t = tuple()


# In[16]:


t


# In[ ]:




