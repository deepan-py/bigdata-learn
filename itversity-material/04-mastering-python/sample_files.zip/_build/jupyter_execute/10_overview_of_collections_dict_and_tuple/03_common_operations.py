#!/usr/bin/env python
# coding: utf-8

# ## Common Operations
# 
# There are some functions which can be applied on all collections. Here we will see details related to `tuple` and `dict` using Python as programming language.

# In[1]:


get_ipython().run_cell_magic('HTML', '', '<iframe width="560" height="315" src="https://www.youtube.com/embed/Cc_zWN2u6F8?rel=0&amp;controls=1&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>')


# * `in` - check if element exists in the `tuple`
# * `in` can also be used on `dict`. It checks if the key exists in the `dict`.
# * `len` - to get the number of elements.
# * `sorted` - to sort the data (original collection will be untouched). Typically, we assign the result of sorting to a new collection.
# * `sum`, `min`, `max`, etc - arithmetic operations. In case of `dict`, the operations will be performed on key.
# * There can be more such functions.

# In[2]:


t = (1, 2, 3, 4) # tuple


# In[3]:


1 in t


# In[4]:


5 in t


# In[5]:


len(t)


# In[6]:


sorted(t, reverse=True)


# In[7]:


sum(t)


# In[8]:


d = {1: 'a', 2: 'b', 3: 'c', 4: 'd'} # dict


# In[9]:


1 in d


# In[10]:


5 in d


# In[11]:


'a' in d


# In[12]:


len(d)


# In[13]:


sorted(d) # only sorts the keys


# In[14]:


sum(d) # applies only on keys


# In[ ]:




