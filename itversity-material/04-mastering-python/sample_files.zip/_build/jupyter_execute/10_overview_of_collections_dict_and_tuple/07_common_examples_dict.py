#!/usr/bin/env python
# coding: utf-8

# ## Common Examples - dict
# 
# Let us see some common examples while creating `dict` in Python. If you are familiar with JSON, `dict` is similar to JSON.

# In[1]:


get_ipython().run_cell_magic('HTML', '', '<iframe width="560" height="315" src="https://www.youtube.com/embed/-XmkPihHHhA?rel=0&amp;controls=1&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>')


# * A dict can have key value pairs where key is of any type and value is of any type.
# * However, typically we use attribute names as keys for `dict`. They are typically of type `str`.
# * The value can be of simple types such as `int`, `float`, `str` etc or it can be object of some custom type.
# * The value can also be of type `list` or nested `dict`.
# * An individual might have multiple phone numbers and hence we can define it as `list`.
# * An individual address might have street, city, state and zip and hence we can define it as nested `dict`.
# * Let us see some examples.

# In[2]:


# All attribute names are of type str and values are of type int, str or float
d = {'id': 1, 'first_name': 'Scott', 'last_name': 'Tiger', 'amount': 1000.0}


# In[3]:


for key in d.keys():
    print(f'type of attribute name {key} is {type(key)}')


# In[4]:


for value in d.values():
    print(f'type of value {value} is {type(value)}')


# In[5]:


d.update([('phone_numbers', [1234567890, 2345679180])])


# In[6]:


d


# In[7]:


for value in d.values():
    print(f'type of value {value} is {type(value)}')


# In[8]:


d['address'] = {'street': '1234 ABC Towers', 'city': 'Round Rock', 'state': 'Texas', 'zip': 78664}


# In[9]:


d


# In[10]:


d['address']


# In[11]:


type(d['address'])


# In[12]:


for value in d.values():
    print(f'type of value {value} is {type(value)}')


# In[ ]:




