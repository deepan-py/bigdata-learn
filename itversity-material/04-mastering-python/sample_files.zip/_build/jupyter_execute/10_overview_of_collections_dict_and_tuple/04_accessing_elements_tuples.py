#!/usr/bin/env python
# coding: utf-8

# ## Accessing Elements - tuples
# 
# Let us see details related to operations on tuples. Unlike other collections (`list`, `set`, `dict`) we have limited functions with `tuple` in Python.

# In[2]:


get_ipython().run_cell_magic('HTML', '', '<iframe width="560" height="315" src="https://www.youtube.com/embed/fZ-QOUk-ia4?rel=0&amp;controls=1&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>')


# * `tuple` is by definition immutable and hence we will not be able to add elements to a tuple or delete elements from a tuple.
# * Only functions that are available are `count` and `index`.
# * `count` gives number of times an element is repeated in a tuple.
# * `index` returns the position of element in a tuple. `index` can take up to 3 arguments - `element`, `start` and `stop`.

# In[2]:


t = (1, 2, 3, 4, 4, 6, 1, 2, 3)


# In[3]:


help(t)


# In[4]:


get_ipython().run_line_magic('pinfo', 't.count')


# In[5]:


t.count(4)


# In[6]:


t.count(9)


# In[7]:


get_ipython().run_line_magic('pinfo', 't.index')


# In[8]:


t.index(2) # Scans all the elements


# In[9]:


t.index(2, 3) # Scans all the elements starting from 4th


# In[10]:


t.index(2, 3, 5) # throws ValueError, scans from 4th element till 5th element


# In[11]:


t.index(9)


# In[12]:


t.index(6, 3, 5) # throws ValueError, scans from 4th element till 5th element


# In[13]:


t.index(6, 3, 6) 


# In[ ]:




