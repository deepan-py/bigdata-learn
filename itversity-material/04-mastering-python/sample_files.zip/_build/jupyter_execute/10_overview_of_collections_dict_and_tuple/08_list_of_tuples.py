#!/usr/bin/env python
# coding: utf-8

# ## List of tuples
# Let us see an example of how we can read data from a file into **list of tuples** using Python as programming language.

# In[1]:


get_ipython().run_cell_magic('HTML', '', '<iframe width="560" height="315" src="https://www.youtube.com/embed/ad-GXe5J9RE?rel=0&amp;controls=1&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>')


# * When we read data from a file into a `list`, typically each element in the list will be of type binary or string.
# * We can convert the element into `tuple` to simplify the processing.
# * Once each element is converted to `tuple`, we can access elements in the `tuple` using positional notation.
# * Let us see an example to read the data from a file into **list of tuples** and access dates.

# In[2]:


get_ipython().run_cell_magic('sh', '', '\nls -ltr /data/retail_db/orders/part-00000')


# In[3]:


get_ipython().run_cell_magic('sh', '', '\ntail /data/retail_db/orders/part-00000')


# In[4]:


# Reading data from file into a list
path = '/data/retail_db/orders/part-00000'
# C:\\users\\itversity\\Research\\data\\retail_db\\orders\\part-00000
orders_file = open(path)


# In[5]:


type(orders_file)


# In[6]:


orders_raw = orders_file.read()


# In[7]:


type(orders_raw)


# In[8]:


get_ipython().run_line_magic('pinfo', 'str.splitlines')


# In[9]:


orders_raw[:10]


# In[10]:


orders = orders_raw.splitlines()


# In[11]:


type(orders)


# In[12]:


orders[:10]


# In[13]:


len(orders) # same as number of records in the file


# In[14]:


order = '1,2013-07-25 00:00:00.0,11599,CLOSED'


# In[15]:


order


# In[16]:


order.split(',')


# In[17]:


tuple(order.split(','))


# In[18]:


(*order.split(','), )# special operator to convert list to tuple


# In[19]:


order_tuples = [(*order.split(','),) for order in orders] 


# In[20]:


order_tuples = [tuple(order.split(',')) for order in orders] 


# In[21]:


type(order_tuples)


# In[22]:


order_tuples[0]


# In[23]:


order_tuples[:3]


# In[24]:


len(order_tuples)


# In[25]:


order_dates = [order[1] for order in order_tuples]


# In[26]:


order_dates[:3]


# In[27]:


len(order_dates)


# In[28]:


# We can also change the data types of elements in the tuples
def get_order_details(order):
    order_details = order.split(',')
    return (int(order_details[0]), order_details[1], int(order_details[2]), order_details[3])


# In[29]:


order_tuples = [get_order_details(order) for order in orders]


# In[30]:


order_tuples[:3]


# In[31]:


order_customer_ids = [order[2] for order in order_tuples]


# In[32]:


order_customer_ids[:3]


# In[33]:


type(order_customer_ids[0])


# In[34]:


path = '/data/retail_db/orders/part-00000'
# C:\\users\\itversity\\Research\\data\\retail_db\\orders\\part-00000
orders_file = open(path)
orders_raw = orders_file.read()
orders = orders_raw.splitlines()
order_tuples = [(*order.split(','),) for order in orders] 
order_dates = [order[1] for order in order_tuples]


# In[35]:


unique_dates = set(order_dates)


# In[36]:


len(unique_dates)


# In[ ]:




