#!/usr/bin/env python
# coding: utf-8

# ## Accessing Elements - dict
# 
# Let us see how we can access elements from the `dict` using Python as programming language.

# In[1]:


get_ipython().run_cell_magic('HTML', '', '<iframe width="560" height="315" src="https://www.youtube.com/embed/FpxL1G8ktOk?rel=0&amp;controls=1&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>')


# * We can access a value of a particular element in `dict` by passing key `d[key]`. If the key does not exists, it will throw **KeyError**.
# * `get` also can be used to access a value of particular element in `dict` by passing key as argument. However, if key does not exists, it will return None.
# * We can also pass a default value to `get`.
# * We can get all the keys in the form of set like object by using `keys` and all the values in the form of list like object by using `values`.
# * We can also use `items` to convert a `dict` into a set like object with pairs. Each element (which is a pair) in the set like object will be a tuple.
# * Let us see few examples.

# In[2]:


d = {'id': 1, 'first_name': 'Scott', 'last_name': 'Tiger', 'amount': 1000.0}


# In[3]:


d['id']


# In[4]:


d['first_name']


# In[5]:


d['commission_pct'] # throws key error


# In[6]:


get_ipython().run_line_magic('pinfo', 'd.get')


# In[7]:


d.get('first_name')


# In[8]:


d.get('commission_pct') # Returns None


# In[9]:


d.get('first_name', 'Some First Name')


# In[10]:


d.get('commission_pct', 0) 


# In[11]:


get_ipython().run_line_magic('pinfo', 'd.keys')


# In[12]:


d.keys()


# In[13]:


get_ipython().run_line_magic('pinfo', 'd.values')


# In[14]:


d.values()


# In[15]:


get_ipython().run_line_magic('pinfo', 'd.items')


# In[16]:


d.items()


# In[17]:


list(d.items())[0]


# In[18]:


list(d.items())[1]


# In[19]:


type(list(d.items())[1])


# In[ ]:




