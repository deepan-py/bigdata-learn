#!/usr/bin/env python
# coding: utf-8

# ## Manipulating dict
# 
# Let us understand how we can manipulate the dicts in Python.

# In[1]:


get_ipython().run_cell_magic('HTML', '', '<iframe width="560" height="315" src="https://www.youtube.com/embed/EVp-skflxO4?rel=0&amp;controls=1&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>')


# * We can add new key value pairs to `dict` by using typical assignment.
# * We can also use assignment operation to update existing key value pair in the `dict`.
# * `setdefault` can be used to get the element from the `dict` by using key. If key does not exist, it will update the `dict` with the key passed along with default value.
# * `update` can be used to merge a list of pairs (2 tuples) or a `dict` into the `dict`.
# * Elements from the dict can be removed using functions like `pop` and `popitem`.
#   * `pop` is typically used to remove the element using key.
#   * `popitem` is used to remove one of the item (typically last) from the `dict`.

# In[2]:


d = {'id': 1, 'first_name': 'Scott', 'last_name': 'Tiger', 'amount': 1000.0}


# In[3]:


d['commission_pct'] = 10 # Adding Element


# In[4]:


d['phone_numbers'] = 1234567890


# In[5]:


d


# In[6]:


d['amount'] = 1500.0


# In[7]:


d


# In[8]:


d = {'id': 1, 'first_name': 'Scott', 'last_name': 'Tiger', 'amount': 1000.0}


# In[9]:


get_ipython().run_line_magic('pinfo', 'd.setdefault')


# In[10]:


d.setdefault('amount')


# In[11]:


d.setdefault('commission_pct')


# In[12]:


d


# In[13]:


d = {'id': 1, 'first_name': 'Scott', 'last_name': 'Tiger', 'amount': 1000.0}


# In[14]:


d


# In[15]:


d.setdefault('commission_pct', 0)


# In[16]:


d


# In[17]:


d.setdefault('commission_pct', 100)


# In[18]:


d


# In[19]:


get_ipython().run_line_magic('pinfo', 'd.update')


# In[20]:


d = {'id': 1}


# In[21]:


d


# In[22]:


d.update({'first_name': 'Donald', 'last_name': 'Duck'})


# In[23]:


d


# In[24]:


d.update([('amount', 1000.0), ('commission_pct', 10)])


# In[25]:


d


# In[26]:


d.update([('amount', 1500.0), ('commission_pct', 5), ('phone_numbers', 1234567890)])


# In[27]:


d


# In[28]:


d = {'id': 1, 'first_name': 'Scott', 'last_name': 'Tiger', 'amount': 1000.0}


# In[29]:


d['commission_pct'] = 10 # Adding Element


# In[30]:


d['phone_numbers'] = 1234567890


# In[31]:


d


# In[32]:


d.pop('phone_numbers')


# In[33]:


d


# In[34]:


d.pop('phone_numbers') # throws KeyError


# In[35]:


d.pop('phone_numbers', 'No such key exists')


# In[36]:


get_ipython().run_line_magic('pinfo', 'd.pop')


# In[37]:


d


# In[38]:


get_ipython().run_line_magic('pinfo', 'd.popitem')


# In[39]:


d.popitem()


# In[40]:


d


# In[ ]:




