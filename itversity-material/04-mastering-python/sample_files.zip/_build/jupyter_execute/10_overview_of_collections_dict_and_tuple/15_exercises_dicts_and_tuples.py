#!/usr/bin/env python
# coding: utf-8

# ## Exercises - Dicts and Tuples
# 
# Let us go through some exercises related to dict and tuple.

# ### Exercise 1 - Access all the values
# 
# Get the values from the below dict in the form of a list.

# In[ ]:


d = {
    'order_id': 1,
    'order_date': '2013-07-25',
    'order_customer_id': 100,
    'order_status': 'COMPLETE'
}


# In[ ]:


def get_values(d):
    return l


# In[ ]:


get_values(d) # Desired output: [1, '2013-07-25', 100, 'COMPLETE']


# In[ ]:


type(get_values(d)) # list


# ### Exercise 2 - Get Data types of values
# 
# Continue on previous exercise and print data type of each value returned by get_values.

# In[ ]:


l = get_values(d)


# * As l is list, you will be able to use `for` loop to access the elements from l. Here is the desired output.

# In[ ]:


for e in l: print(e)


# ### Exercise 3 - Data Type Conversion
# 
# As part of the below dict object, order_date is of type string. You need to convert the data type of **order_date** to date type.

# In[ ]:


d = {
    'order_id': 1,
    'order_date': '2013-07-25',
    'order_customer_id': 100,
    'order_status': 'COMPLETE'
}


# In[ ]:


import datetime

def convert_date_type(d):
    return d


# * Run below cell to validate the output. Here is the desired output.
# 
# ```python
# {'order_id': 1,
#  'order_date': datetime.datetime(2013, 7, 25, 0, 0),
#  'order_customer_id': 100,
#  'order_status': 'COMPLETE'}
# ```

# In[ ]:


d_converted = convert_date_type(d)
d_converted


# In[ ]:


type(d_converted['order_date']) # Output: datetime.datetime


# ### Exercise 4 - Create list of dicts
# 
# Create list of dicts for the following data.
# * Each element in the list should be of type dict.
# * The dict should contain **order_item_order_id** and **order_item_subtotal** as keys.
# 
# |order_item_order_id|order_item_subtotal|
# |---|---|
# |1|299.98|
# |2|199.99|
# |2|250.0|
# |2|129.99|
# |4|49.98|
# |4|299.95|
# |4|150.0|
# |4|199.92|

# ### Exercise 5: Dict with max value
# 
# Create a dict with order id and max order item subtotal using the below dict. The below dict contains order id as key and order item subtotals list as corresponding value.

# In[ ]:


order_item_subtotals = {
    1: [299.98],
    2: [199.99, 250.0, 129.99],
    4: [49.98, 150.0, 199.92],
    5: [299.98, 299.95, 99.96, 299.98, 129.99],
    7: [199.99, 299.98, 79.95],
    8: [179.97, 299.95, 199.92, 50.0]
}


# In[ ]:


# Your solution should go here


# * Here is the desired output.
# 
# ```python
# {1: 299.98, 2: 250.0, 4: 199.92, 5: 299.98, 7: 299.98, 8: 299.95}
# ```

# ### Exercise 6: Dict with order revenue
# 
# Create a dict with order item id and order item subtotal. The input dict will contain order item id as key and quantity along with price as value. **order item subtotal** is product of quantity and price.

# In[ ]:


order_items = {1: (1, 299.98),
 2: (1, 199.99),
 3: (5, 50.0),
 4: (1, 129.99),
 5: (2, 24.99),
 6: (5, 59.99),
 7: (3, 50.0),
 8: (4, 49.98),
 9: (1, 299.98),
 10: (5, 59.99)}


# In[ ]:


# Your solution should go here


# * Here is the expected output.
# 
# ```python
# {1: 299.98,
#  2: 199.99,
#  3: 250.0,
#  4: 129.99,
#  5: 49.98,
#  6: 299.95,
#  7: 150.0,
#  8: 199.92,
#  9: 299.98,
#  10: 299.95}
# ```

# In[ ]:




