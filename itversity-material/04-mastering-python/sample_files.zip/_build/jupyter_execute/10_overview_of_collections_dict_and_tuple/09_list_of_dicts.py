#!/usr/bin/env python
# coding: utf-8

# ## List of dicts
# Let us see an example of how we can read data from a file into **list of dicts** using Python as programming language.

# In[1]:


get_ipython().run_cell_magic('HTML', '', '<iframe width="560" height="315" src="https://www.youtube.com/embed/pxwPEnLsKvU?rel=0&amp;controls=1&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>')


# * When we read data from a file into a `list`, typically each element in the `list` will be of type binary or string.
# * We can convert the element into `dict` to simplify the processing.
# * Once each element is converted to `dict`, we can access elements in the `dict` using attribute name.
# * Let us see an example to read the data from a file into **list of dicts** and access dates.

# In[2]:


# Reading data from file into a list
path = '/data/retail_db/orders/part-00000'
# C:\\users\\itversity\\Research\\data\\retail_db\\orders\\part-00000
orders_file = open(path)


# In[3]:


get_ipython().run_cell_magic('sh', '', '\nwc -l /data/retail_db/orders/part-00000')


# In[4]:


type(orders_file)


# In[5]:


orders_raw = orders_file.read()


# In[6]:


orders = orders_raw.splitlines()


# In[7]:


orders[:10]


# In[8]:


len(orders) # same as number of records in the file


# In[9]:


def get_order_dict(order):
    order_details = order.split(',')
    order_dict = {
        'order_id': int(order_details[0]),
        'order_date': order_details[1],
        'order_customer_id': int(order_details[2]),
        'order_status': order_details[3],
    }
    return order_dict


# In[10]:


get_order_dict(orders[0])


# In[11]:


order_dicts = [get_order_dict(order) for order in orders]


# In[12]:


type(order_dicts)


# In[13]:


type(order_dicts[0])


# In[14]:


order_dicts[0]


# In[15]:


order_dicts[:3]


# In[16]:


len(order_dicts)


# In[17]:


order_dates = [order['order_date'] for order in order_dicts]


# In[18]:


order_dates[:3]


# In[19]:


len(order_dates)


# In[20]:


set(order_dates)


# In[21]:


order_customer_ids = [order['order_customer_id'] for order in order_dicts]


# In[22]:


order_customer_ids[:3]


# In[23]:


type(order_customer_ids[0])


# In[24]:


def get_order_dict(order):
    order_details = order.split(',')
    order_dict = {
        'order_id': int(order_details[0]),
        'order_date': order_details[1],
        'order_customer_id': int(order_details[2]),
        'order_status': order_details[3],
    }
    return order_dict


# In[25]:


# Reading data from file into a list
path = '/data/retail_db/orders/part-00000'
# C:\\users\\itversity\\Research\\data\\retail_db\\orders\\part-00000
orders_file = open(path)
orders_raw = orders_file.read()
orders = orders_raw.splitlines()
order_dicts = [get_order_dict(order) for order in orders]
order_dates = [order['order_date'] for order in order_dicts]


# In[26]:


order_dates[:3]


# In[27]:


len(order_dates)


# In[ ]:




