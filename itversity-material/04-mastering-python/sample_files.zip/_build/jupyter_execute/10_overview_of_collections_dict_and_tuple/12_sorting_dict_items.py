#!/usr/bin/env python
# coding: utf-8

# ## Sorting dict items
# 
# Let us understand how we can sort the dict items in Python.
# * `dict` is nothing but group of key value pairs where keys are unique.
# * `sorted` on `dict` returns only sorted keys.

# In[ ]:


famous_players = {
    'Pete Sampras': 'Tennis',
    'Sachin Tendulkar': 'Cricket',
    'Brian Lara': 'Cricket',
    'Diego Maradona': 'Soccer',
    'Roger Federer': 'Tennis',
    'Ian Thorpe': 'Swimming',
    'Ronaldo': 'Soccer',
    'Usain Bolt': 'Running',
    'P. V. Sindhu': 'Badminton',
    'Shane Warne': 'Cricket',
    'David Beckham': 'Cricket',
    'Michael Phelps': 'Swimming'
}


# In[ ]:


sorted(famous_players) # Creates list with only keys from dict


# In[ ]:


type(sorted(famous_players)) # Creates list with only keys from dict


# * But at times we might want to sort the items based up on the values in the `dict`.
# * Here are the steps involved to sort the items in dict by values.
#   * Create list like object using `items`.
#   * Sort the list like object using `sorted` with custom comparison or sort logic. We need to use `key` argument for that.
# * The output of `sorted` will be of type `list`.

# In[5]:


famous_players.items()


# In[6]:


# Sorts based up on natural order of tuples
# By default data will be sorted by names of the players.
# Player names are first elemen in the tuples
sorted(famous_players.items())


# In[7]:


# Use key argument to pass the custom comparison logic
# We would like to compare by sport name.
# Sport name is second elemet in tuple.
sorted(famous_players.items(), key=lambda player: player[1])


# * You can see that data is sorted in ascending order by name of the sport now.

# In[ ]:




