#!/usr/bin/env python
# coding: utf-8

# # Overview of Collections - dict and tuple
# Let us get an overview of dict and tuple as part of the Python Collections.
# 
# * Overview of dict and tuple
# * Common Operations
# * Accessing Elements - tuples
# * Accessing Elements - dict
# * Manipulating dict
# * Common Examples - dict
# * List of tuples
# * List of dicts
