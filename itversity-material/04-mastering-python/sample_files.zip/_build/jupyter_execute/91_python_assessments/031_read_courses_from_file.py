#!/usr/bin/env python
# coding: utf-8

# ## Read Courses from file
# 
# Develop logic to read the data from tab delimited file into list of tuples.
# * The file which you are supposed to use is **./data/courses/courses.csv** in the current folder.
# * It is a text file where lines are delimited by **new line** character.
# * Each line contain data for multiple attributes related to courses table. Each attribute value in each line is separated by **'\t'** (tab) character.
# * The first line of the file is header, it means we have name of the attributes as part of the first line.
# * You need to develop a function which will return list of tuples with all the values from the file.
# 
# **Hint: Using Pandas or csv will facilitate you to come up with the solution faster**

# In[ ]:


# Provide the solution here
import pandas as pd

def get_courses(path):
    return courses


# In[ ]:


courses = get_courses('./data/courses/courses.csv')


# In[ ]:


type(courses) # should be list


# In[ ]:


len(courses) # should be 12


# In[ ]:


courses[0] # Output: ('Programming using Python', 'Bob Dillon', 'published', '2020-09-30')


# In[ ]:


type(courses[0]) # tuple


# In[ ]:




