#!/usr/bin/env python
# coding: utf-8

# ## Standardization of Dates
# 
# At times, we might end up getting dates using different formats along with information related to the format using which dates should be interpreted. As part of the database we typically store using one format.
# 
# **Hint: Use datetime library to format the dates**
# * Here are the details for formatting date components such as year, month, day etc.
#   * `%b`: Returns the first three characters of the month name. For example, September will be considered as "Sep"
#   * `%m`: Returns the the month in two-digit format. In our example, Septermber will be considered as 09
#   * `%d`: Returns day of the month, from 1 to 31. In our example, 5th of the month will be considered as 05
#   * `%Y`: Returns the year in four-digit format.
#   * `%H`: Returns the hour, from 00 to 23.
#   * `%M`: Returns the minute, from 00 to 59.
#   * `%S`: Returns the second, from 00 to 59. 
# 
# * Here is the sample input data

# In[ ]:


dates = [
    {'date': '2020-05-21', 'format': 'yyyy-MM-dd'},
    {'date': '2021-Feb-28', 'format': 'yyyy-Mon-dd'},
    {'date': 20190131, 'format': 'yyyyMMdd'},
    {'date': '18-Mar-2018', 'format': 'dd-Mon-yyyy'}
]


# * Create a mapping for above formats with actual python formats

# In[ ]:


# The mapping dict goes here
format_mapping = {
    'yyyy-MM-dd': '%Y-%m-%d',
    'yyyy-Mon-dd': '%Y-%b-%d',
    'yyyyMMdd': '%Y%m%d',
    'dd-Mon-yyyy': '%d-%b-%Y'
}


# * Apply the format to convert to dates and then to the one uniform format - **yyyy-MM-dd**
# * Develop a function by name **standardize_dates** which take the list and return sorted dates with uniform date format.
# * The function should take the list of dates and dict for format mapping.

# In[ ]:


# The logic to format dates to standard format goes here


# In[ ]:


standardize_dates(dates, format_mapping)


# * Here is the expected output

# In[ ]:


['2018-03-18', '2019-01-31', '2020-05-21', '2021-02-28']


# In[ ]:




