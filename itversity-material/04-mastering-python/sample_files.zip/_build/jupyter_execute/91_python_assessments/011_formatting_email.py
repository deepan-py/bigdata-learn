#!/usr/bin/env python
# coding: utf-8

# ## Formatting Emails
# 
# Develop a function to format the place holders in a string with the actual values. This is primarily to test usage of **key word arguments** and **formatting strings**.
# 
# Here is a typical way how we send emails as part of the applications.
# * Function Name: **gen_email_body**.
# * Define email templates and store in a file or database. In this case we will be storing in a file. The actual email body template will be created using HTML.
# * We typically send emails in different scenarios. Here are some examples.
#   * When user signs up to our portal.
#   * When user purchase some product in our portal.
#   * When there is update about his order.
#   * Confirmation emails such as account created, updated, order successfully placed, order cancelled etc.
# * For each type of email, we will use one template. These templates will have placeholders which are supposed to be replaced before email is sent.
# * Now we get the data to be replaced in emails in the form of objects.
# * Once we get the data in the form of objects, we replace the placeholders or variables in the file using the data in the objects.
# * After generating email body with actual values, we will then send the email across.

# In[22]:


BODY_HTML = """
<html>
    <head>
    </head>
    <body>
        Dear {customer_first_name},
        <br>
        <br>
        Thank you for puchasing the <b>{product_subscription}</b> subscription of <b>{product_name}</b>.
        <br>
        Your credit card is charged for <b>{amount_received}</b> and it will be charged again on <b>{next_renewal_date}</b>.
        
        <br>
        <br>
        {product_description} We hope you to enjoy with your family members!!!
    </body>
</html>
"""


# In[16]:


product_purchase_details = {
    'customer_first_name': 'Scott',
    'customer_last_name': 'Tiger',
    'product_name': 'Prime Video',
    'product_subscription': 'quarterly',
    'amount_received': '$20',
    'product_description': 'You will get access to thousands of movies, exclusive web series as part of this subscription.',
    'next_renewal_date': '01 August, 2020'
}


# In[17]:


# Your code should go here.
# Update the function.

def gen_email_body(BODY_HTML):
    # Develop the logic here.
    return email_body


# * Here is the sample output.
# 
# ```html
# 
# <html>
#     <head>
#     </head>
#     <body>
#         Dear Scott,
#         <br>
#         <br>
#         Thank you for puchasing the <b>quarterly</b> subscription of <b>Prime Video</b>.
#         <br>
#         Your credit card is charged for <b>$20</b> and it will be charged again on <b>01 August, 2020</b>.
#         
#         <br>
#         <br>
#         You will get access to thousands of movies, exclusive web series as part of this subscription. We hope you to enjoy with your family members!!!
#     </body>
# </html>
# ```

# * Here is how the actual email body will be.

# In[21]:


get_ipython().run_cell_magic('HTML', '', '\n\n<html>\n    <head>\n    </head>\n    <body>\n        Dear Scott,\n        <br>\n        <br>\n        Thank you for puchasing the <b>quarterly</b> subscription of <b>Prime Video</b>.\n        <br>\n        Your credit card is charged for <b>$20</b> and it will be charged again on <b>01 August, 2020</b>.\n        \n        <br>\n        <br>\n        You will get access to thousands of movies, exclusive web series as part of this subscription. We hope you to enjoy with your family members!!!\n    </body>\n</html>')


# In[ ]:




