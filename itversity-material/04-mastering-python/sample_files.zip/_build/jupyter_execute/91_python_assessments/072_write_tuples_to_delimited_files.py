#!/usr/bin/env python
# coding: utf-8

# ## Write tuples to delimited files
# 
# Develop a function to write the list of tuples to delimited files. The function should take the list of tuples, delimiter, column names, and file name as argument.
# * The output should contain header.
# * Attribute values in each record should be delimited by the delimiter passed.
# * Keep in mind that `csv` need not be comma separated. We can use any delimiter. Some of the commonly used delimiters are `,` (comma), `|` (pipe), `;` (semicolon), `:` (colon),  `\t` (tab), etc.
# 
# **Restriction: You need to use `pandas` to write data to files. Also, by default `pandas` writes index to the file. Make sure to not to write index of each record to the file.**

# In[ ]:


import pandas as pd
def write_tuples(tuples, delim, columns, file_name):
    return


# * Run below cells to validate. You should see the data with header and `\t` as delimiter between attribute values.
# 
# ```text
# course_name	course_author	course_status	course_publised_dt
# Programming using Python	Bob Dillon	published	2020-09-30
# Data Engineering using Python	Bob Dillon	published	2020-07-15
# Data Engineering using Scala	Elvis Presley	draft	
# Programming using Scala	Elvis Presley	published	2020-05-12
# Programming using Java	Mike Jack	inactive	2020-08-10
# Web Applications - Python Flask	Bob Dillon	inactive	2020-07-20
# Web Applications - Java Spring	Mike Jack	draft	
# Pipeline Orchestration - Python	Bob Dillon	draft	
# Streaming Pipelines - Python	Bob Dillon	published	2020-10-05
# Web Applications - Scala Play	Elvis Presley	inactive	2020-09-30
# Web Applications - Python Django	Bob Dillon	published	2020-06-23
# Server Automation - Ansible	Uncle Sam	published	2020-07-05
# ```

# In[ ]:


courses = [('Programming using Python', 'Bob Dillon', 'published', '2020-09-30'),
 ('Data Engineering using Python', 'Bob Dillon', 'published', '2020-07-15'),
 ('Data Engineering using Scala', 'Elvis Presley', 'draft', None),
 ('Programming using Scala', 'Elvis Presley', 'published', '2020-05-12'),
 ('Programming using Java', 'Mike Jack', 'inactive', '2020-08-10'),
 ('Web Applications - Python Flask', 'Bob Dillon', 'inactive', '2020-07-20'),
 ('Web Applications - Java Spring', 'Mike Jack', 'draft', None),
 ('Pipeline Orchestration - Python', 'Bob Dillon', 'draft', None),
 ('Streaming Pipelines - Python', 'Bob Dillon', 'published', '2020-10-05'),
 ('Web Applications - Scala Play', 'Elvis Presley', 'inactive', '2020-09-30'),
 ('Web Applications - Python Django', 'Bob Dillon', 'published', '2020-06-23'),
 ('Server Automation - Ansible', 'Uncle Sam', 'published', '2020-07-05')]


# In[ ]:


import getpass
username = getpass.getuser()
write_tuples(courses, 
             '\t', 
             ['course_name', 'course_author', 'course_status', 'course_published_dt'],
             f'/home/{username}/output/courses.tsv'
            )


# In[ ]:


get_ipython().system('cat /home/${USER}/output/courses.tsv')


# In[ ]:




