#!/usr/bin/env python
# coding: utf-8

# ## Save Players JSON as CSV
# 
# Develop a function which will convert the contents of a JSON file into CSV.
# * This exercise is primarily to test the abilities to perform I/O, process json module and also to sort using **Pandas**.
# * First understand how the data is structured.
# * Read the json data from **/data/sports/famous_players.json**
# * Sort the data by country and then by name.
# * Save the output to a csv file (a text file with comma as delimiter).
# * Output should be saved to **/home/${USER}/output/sports/famous_players.csv**
# * Develop a function which reads the data from the path passed and write the output to the path passed.
#   * Check if the input directory exists. If the file does not exists, print **{input_file} does not exists, check the path of the file passed**
#   * Check if the target file already exists. If the file already exists, you should display a message saying **{output_file} already exists, do you want to replace (y/N): **.
#     * Make sure **{output_file}** in the message is replaced by the path.
#     * If you input **y** or **Y**, then target file should be replaced.
#     * If you input nothing or n or N, it should ignore.
#     * If you input some other character, you should print the message saying **Invalid input {input_character}**. Display the actual input value in place of **{input_character}**.
#     * If the target file does not exists, check for directory and create if it does not exists. Once the directory is created, then create csv file in that directory.
#   * Read JSON Data.
#   * Sort by country and then by name.
#   * Write sorted data in the form of CSV with header. The data should contain all the 3 attributes. Header should be generated based up on the names in the input data.

# * Run this command to confirm whether file exists or not.

# In[ ]:


get_ipython().system('ls -ltr /data/sports/famous_players.json')


# * Run this command to preview the data.

# In[ ]:


get_ipython().system('cat /data/sports/famous_players.json')


# * Develop the function using the below cell.

# In[1]:


# Your solution should go here
import pandas as pd, os
def save_players_as_csv(input_file_path, output_file_path):
    return


# * Test Case 1: Validating Input Path
# * Generate input and output paths and invoke the function.

# In[ ]:


import getpass
username = getpass.getuser()
input_file_path = f'/home/{username}/data/json/famous_players.csv' # Make sure this path does not exists
output_file_path = f'/home/{username}/output/sports/famous_players.csv'


# In[ ]:


save_players_as_csv(input_file_path, output_file_path)


# * Test Case 1: Expected output
# 
# ```
# /home/itversity/data/json/famous_players.csv does not exists, check the path of the file passed
# ```

# * Test Case 2: Writing the output to CSV
# * Below cell will take care of deleting the output file if exists.

# In[ ]:


get_ipython().system('rm /home/${USER}/output/sports/famous_players.csv')


# In[ ]:


get_ipython().system('ls /data/sports/famous_players.json')


# In[ ]:


import getpass
username = getpass.getuser()
input_file_path = f'/data/sports/famous_players.json' # Make sure to pass correct input path
output_file_path = f'/home/{username}/output/sports/famous_players.csv'


# In[ ]:


save_players_as_csv(input_file_path, output_file_path)


# In[ ]:


get_ipython().system('ls -ltr /home/${USER}/output/sports/famous_players.csv')


# In[ ]:


get_ipython().system('cat /home/${USER}/output/sports/famous_players.csv')


# * Test Case 2: Expected Output
# ```
# country,name,sport
# Argentina,Diego Maradona,Soccer
# Australia,Ian Thorpe,Swimming
# Australia,Shane Warne,Cricket
# Brazil,Ronaldo,Soccer
# England,David Beckham,Cricket
# India,P. V. Sindhu,Badminton
# India,Sachin Tendulkar,Cricket
# Jamaica,Usain Bolt,Running
# Switzerland,Roger Federer,Tennis
# USA,Michael Phelps,Swimming
# USA,Pete Sampras,Tennis
# West Indies,Brian Lara,Cricket
# ```

# * Here are the additional test case scenarios. You can check the timestamp on the file to see if the files are replaced or not.
#   * Test Case 3: Run the function when target file exists with **y** or **Y**. See if the file is replaced.
#   * Test Case 4: Run the function when target file exists with **n** or **N**. See if the file is not replaced.
#   * Test Case 5: Run the function when target file exists with some other character than n or N or y or Y - for example yes. You should see the message about invalid input.

# In[ ]:




