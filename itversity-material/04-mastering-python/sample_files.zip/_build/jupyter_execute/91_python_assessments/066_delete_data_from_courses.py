#!/usr/bin/env python
# coding: utf-8

# ## Delete Data from Courses
# 
# As part of this topic, you need to develop the required logic (Step 3 below) to delete the data from the table.
# * Make sure courses table is created
# * Validate all courses
# * Setup data to be deleted
# * Delete data from the table
# * Validate data in the table

# In[ ]:


get_ipython().run_line_magic('run', '000_get_database_connection.ipynb')


# ### Step 1: Make sure courses table is created
# 
# You need to ensure courses table is created before going further and load data into the table.

# In[ ]:


connection = get_pg_connection(
    host=postgres_host,
    port=postgres_port,
    database=f'{username}_sms_db',
    user=f'{username}_sms_user',
    password=password
)


# In[ ]:


cursor = connection.cursor()


# In[ ]:


cursor.execute(f"""
    SELECT * FROM information_schema.tables 
    WHERE table_catalog = '{username}_sms_db' AND table_schema = 'public'
    LIMIT 10
""")


# In[ ]:


for row in cursor:
    print(row)


# * If you do not see courses table, you can create using the below SQL cells.

# In[ ]:


get_ipython().run_line_magic('load_ext', 'sql')


# In[ ]:


get_ipython().run_line_magic('env', 'DATABASE_URL=postgresql://{username}_sms_user:{password}@{postgres_host}:{postgres_port}/{username}_sms_db')


# In[ ]:


get_ipython().run_cell_magic('sql', '', '\nDROP TABLE IF EXISTS courses')


# In[ ]:


get_ipython().run_cell_magic('sql', '', "\nCREATE TABLE courses (\n    course_id SERIAL PRIMARY KEY,\n    course_name VARCHAR(60),\n    course_author VARCHAR(40),\n    course_status VARCHAR(9) CHECK (course_status IN ('published', 'inactive', 'draft')),\n    course_published_dt DATE\n)")


# In[ ]:


get_ipython().run_cell_magic('sql', '', "\nINSERT INTO courses \n    (course_name, course_author, course_status, course_published_dt) \nVALUES \n    ('Programming using Python', 'Bob Dillon', 'published', '2020-09-30'),\n    ('Data Engineering using Python', 'Bob Dillon', 'published', '2020-07-15'),\n    ('Data Engineering using Scala', 'Elvis Presley', 'draft', NULL),\n    ('Programming using Scala', 'Elvis Presley', 'published', '2020-05-12'),\n    ('Programming using Java', 'Mike Jack' , 'inactive', '2020-08-10'),\n    ('Web Applications - Python Flask', 'Bob Dillon', 'inactive', '2020-07-20'),\n    ('Web Applications - Java Spring', 'Mike Jack', 'draft', NULL),\n    ('Pipeline Orchestration - Python', 'Bob Dillon', 'draft', NULL),\n    ('Streaming Pipelines - Python', 'Bob Dillon', 'published', '2020-10-05'),\n    ('Web Applications - Scala Play', 'Elvis Presley', 'inactive', '2020-09-30'),\n    ('Web Applications - Python Django', 'Bob Dillon', 'published', '2020-06-23'),\n    ('Server Automation - Ansible', 'Uncle Sam' , 'published', '2020-07-05');")


# ### Step 2: Validate all courses
# 
# Let us make sure courses table have all the data.

# In[ ]:


cursor.execute(f"""
    SELECT * FROM courses
""")


# In[ ]:


courses = [course for course in cursor]


# In[ ]:


len(courses) # should return 12


# In[ ]:


courses # Review the data to make sure that all the records are as expected


# ### Step 3: Setup Data to be deleted
# 
# Let us setup the courses to be deleted. We will create a list which contain courses to be deleted.

# In[ ]:


courses_to_be_deleted = ['Web Applications - Scala Play', 'Server Automation - Ansible']


# ### Step 4: Delete data from the table
# 
# Here you need to develop the logic which will insert the data into the table. Make sure to close connection after loading the data.

# In[ ]:


# Your logic should go here


# ### Step 5: Validate Data
# 
# Make sure the output only contain 10 records. 

# In[ ]:


get_ipython().run_line_magic('load_ext', 'sql')


# In[ ]:


get_ipython().run_line_magic('env', 'DATABASE_URL=postgresql://{username}_sms_user:{password}@{postgres_host}:{postgres_port}/{username}_sms_db')


# In[ ]:


get_ipython().run_cell_magic('sql', '', '\nSELECT * FROM courses')


# * This query should not return any thing

# In[ ]:


get_ipython().run_cell_magic('sql', '', "\nSELECT * FROM courses\nWHERE course_name IN ('Web Applications - Scala Play', 'Server Automation - Ansible')")


# In[ ]:




