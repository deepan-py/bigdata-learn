#!/usr/bin/env python
# coding: utf-8

# ## Get Max Number
# 
# As part of this exercise, you need to get the maximum number. This exercise is primarily to test the comfort level on if and for loop. Hence, you need to develop the program using if and for.
# * Here is the list.

# In[1]:


l = [5, 1, None, 'Hello', 7]


# * You need to consider only numbers from the list and get maximum of it.
# * **Expected output**: 7

# In[ ]:




