#!/usr/bin/env python
# coding: utf-8

# ## Sort addresses by state
# 
# Develop a code snippet which process the list of strings which contain addresses. It should return the list of sorted addresses by state and then by street address.
# * This is primarily to test the understanding of string manipulation functions and sorting the data.
# * Each address contain street address, optional number, city and state. All these are comma seperated.
# * Addresses should be sorted in ascending order by state and then by street address.
# * Use appropriate sort function
# * Here is the list of addresses

# In[1]:


addresses = [
    '67 Bobwhite Avenue,Suite 20,Washington,District of Columbia',
    '9 Stoughton Place,Orlando,Florida',
    '5940 Kedzie Terrace,#316,New York City,New York',
    '4519 7th Street,NA,Rochester,New York',
    '3 Truax Pass,Apt 400,Louisville,Kentucky',
    '8 Hauk Street,Indianapolis,Indiana',
    '10 Spaight Street,San Francisco,California',
    '042 Tennyson Way,#18,Columbus,Georgia',
    '6957 Crescent Oaks Park,Topeka,Kansas',
    '94 Talmadge Circle,San Antonio,Texas'
]


# In[2]:


# Code should go here


# * Here is the desired output
# 
# ```python
# ['10 Spaight Street,San Francisco,California',
#  '67 Bobwhite Avenue,Suite 20,Washington,District of Columbia',
#  '9 Stoughton Place,Orlando,Florida',
#  '042 Tennyson Way,#18,Columbus,Georgia',
#  '8 Hauk Street,Indianapolis,Indiana',
#  '6957 Crescent Oaks Park,Topeka,Kansas',
#  '3 Truax Pass,Apt 400,Louisville,Kentucky',
#  '4519 7th Street,NA,Rochester,New York',
#  '5940 Kedzie Terrace,#316,New York City,New York',
#  '94 Talmadge Circle,San Antonio,Texas']
# ```

# In[ ]:




