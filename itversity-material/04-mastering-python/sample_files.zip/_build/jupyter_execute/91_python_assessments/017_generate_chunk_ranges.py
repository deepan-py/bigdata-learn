#!/usr/bin/env python
# coding: utf-8

# ## Generate Chunk Ranges
# 
# Develop a function to generate chunk ranges from a list. This is primarily to assess the understanding of using functions on top of list effectively.
# * Quite often, we might get a list of dicts or objects which have to be written into the database in batches.
# * For example, we might have read data from file into list and the list might have 10,000 records. However we might want to write 200 records at a time in batch and commit.
# * The function should take a list as an argument and it should return the chunk ranges as list based upon the chunk size.

# In[ ]:


# Your code should go here

def get_chunk_ranges(data_list, chunk_size=4):
    return chunk_ranges


# * You can validate by using below cell.
# * Here is the expected output.
# ```python
# [(0, 4), (4, 8), (8, 9)]
# ```

# In[ ]:


get_chunk_ranges([1, 2, 3, 4, 5, 6, 7, 8, 9])


# In[ ]:




