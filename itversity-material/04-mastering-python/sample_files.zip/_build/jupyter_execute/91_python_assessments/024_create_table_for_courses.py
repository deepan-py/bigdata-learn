#!/usr/bin/env python
# coding: utf-8

# ## Create Table for Courses
# 
# Create table - **courses**
# * **course_id** - sequence generated integer and primary key
# * **course_name** - which holds alpha numeric or string values up to 60 characters
# * **course_author** - which holds the name of the author up to 40 characters
# * **course_status** - which holds one of these values (**published**, **draft**, **inactive**). It should also be defaulted to **draft**.
# * **course_published_dt** - which holds date type value. 

# In[ ]:


# Make sure to update the file 000_get_database_connection.ipynb
# Run this cell before going further
get_ipython().run_line_magic('run', '000_get_database_connection.ipynb')


# * After running above cell, make sure to create connection object to validate.
# * If you see errors, please reach out to us for the support.

# In[ ]:


connection = get_pg_connection(
    host=postgres_host,
    port=postgres_port,
    database=f'{username}_sms_db',
    user=f'{username}_sms_user',
    password=password
)


# * Drop the table if already exists. Run below cells to drop it.

# In[ ]:


get_ipython().run_line_magic('load_ext', 'sql')


# In[ ]:


get_ipython().run_line_magic('env', 'DATABASE_URL=postgresql://{username}_sms_user:{password}@{postgres_host}:{postgres_port}/{username}_sms_db')


# In[ ]:


get_ipython().run_cell_magic('sql', '', '\nDROP TABLE IF EXISTS courses')


# In[ ]:


get_ipython().run_cell_magic('sql', '', "\nSELECT * FROM information_schema.tables \nWHERE table_catalog = '{username}_sms_db' AND table_schema = 'public'\nLIMIT 10")


# * Develop the logic to create the table using Python.

# In[ ]:


connection = get_pg_connection(
    host=postgres_host,
    port=postgres_port,
    database=f'{username}_sms_db',
    user=f'{username}_sms_user',
    password=password
)


# In[ ]:


# The code to create the table should go here.
# Make sure the constraints, sequence, default values are honored as per the requirement


# * Validate by running query here. The below query should return the table that is created.

# In[ ]:


get_ipython().run_cell_magic('sql', '', "\nSELECT * FROM information_schema.tables \nWHERE table_catalog = '{username}_sms_db' AND table_schema = 'public'\nLIMIT 10")


# In[ ]:


get_ipython().run_cell_magic('sql', '', "\nSELECT * FROM information_schema.columns \nWHERE table_catalog = '{username}_sms_db' AND table_schema = 'public'\nLIMIT 10")


# In[ ]:




