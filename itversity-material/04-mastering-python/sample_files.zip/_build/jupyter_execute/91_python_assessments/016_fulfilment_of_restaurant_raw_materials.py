#!/usr/bin/env python
# coding: utf-8

# ## Fulfilment of Restaurant Raw Materials
# 
# Develop a function which will return the details of current raw material inventory in the restaurant. As a restaurant inventory manager, I would like to see current status of raw materials in the industry and fulfilment details to get the raw materials to the desired level.
# * The function should take a list of dicts as argument.
# * If actual_quantity is missing, the status should be **Actual Quantity Missing**.
# * If actual_quantity is less than minimum_quantity, the status should be **Purchase {desired_quantity - actual_quantity} {units}**
# * If actual_quantity is greater than or equal to minimum_quantity, the status should be **Current stock is {actual_quantity - minimum_quantity} {units} more than minimum quantity**.
# * It should return the details sorted by each status.
#   * First we should get the data with **Actual Quantity Missing**.
#   * Then we should get the data with **Purchase Details**.
#   * Then we should get the rest.
# * The output should contain all the fields along with the status.
# * You can use for loops or map function.

# In[ ]:


inventory = [
    {'raw_material_name': 'rice', 'desired_quantity': 1000, 'actual_quantity': 50, 'minimum_quantity': 200, 'units': 'kgs'},
    {'raw_material_name': 'wheat', 'desired_quantity': 800, 'actual_quantity': 300, 'minimum_quantity': 150, 'units': 'kgs'},
    {'raw_material_name': 'sugar', 'desired_quantity': 300, 'actual_quantity': 10, 'minimum_quantity': 60, 'units': 'kgs'},
    {'raw_material_name': 'cake mix', 'desired_quantity': 100, 'actual_quantity': 50, 'minimum_quantity': 20, 'units': 'kgs'},
    {'raw_material_name': 'vegetable oil', 'desired_quantity': 50, 'minimum_quantity': 20, 'units': 'gallons'},
    {'raw_material_name': 'cardamom', 'desired_quantity': 10, 'actual_quantity': 2, 'minimum_quantity': 5, 'units': 'kgs'},
    {'raw_material_name': 'cashews', 'desired_quantity': 20, 'minimum_quantity': 5, 'units': 'kgs'},
    {'raw_material_name': 'almond milk', 'desired_quantity': 10, 'actual_quantity': 5, 'minimum_quantity': 2, 'units': 'gallons'},
    {'raw_material_name': 'pistachios', 'desired_quantity': 20, 'actual_quantity': 3, 'minimum_quantity': 5, 'units': 'kgs'}
]


# In[ ]:


## Your solution should go here. Make sure to return sorted list of dicts.
def get_inventory_details(inventory):
    return


# * Run below cell to validate. Here is the sample output.
# ```python
# [{'raw_material_name': 'vegetable oil',
#   'desired_quantity': 50,
#   'minimum_quantity': 20,
#   'units': 'gallons',
#   'status': 'Actual Quantity Missing'},
#  {'raw_material_name': 'cashews',
#   'desired_quantity': 20,
#   'minimum_quantity': 5,
#   'units': 'kgs',
#   'status': 'Actual Quantity Missing'},
#  {'raw_material_name': 'rice',
#   'desired_quantity': 1000,
#   'actual_quantity': 50,
#   'minimum_quantity': 200,
#   'units': 'kgs',
#   'status': 'Purchase 950 kgs'},
#  {'raw_material_name': 'sugar',
#   'desired_quantity': 300,
#   'actual_quantity': 10,
#   'minimum_quantity': 60,
#   'units': 'kgs',
#   'status': 'Purchase 290 kgs'},
#  {'raw_material_name': 'cardamom',
#   'desired_quantity': 10,
#   'actual_quantity': 2,
#   'minimum_quantity': 5,
#   'units': 'kgs',
#   'status': 'Purchase 8 kgs'},
#  {'raw_material_name': 'pistachios',
#   'desired_quantity': 20,
#   'actual_quantity': 3,
#   'minimum_quantity': 5,
#   'units': 'kgs',
#   'status': 'Purchase 17 kgs'},
#  {'raw_material_name': 'wheat',
#   'desired_quantity': 800,
#   'actual_quantity': 300,
#   'minimum_quantity': 150,
#   'units': 'kgs',
#   'status': 'Current stock is 150 kgs more than minimum quantity'},
#  {'raw_material_name': 'cake mix',
#   'desired_quantity': 100,
#   'actual_quantity': 50,
#   'minimum_quantity': 20,
#   'units': 'kgs',
#   'status': 'Current stock is 30 kgs more than minimum quantity'},
#  {'raw_material_name': 'almond milk',
#   'desired_quantity': 10,
#   'actual_quantity': 5,
#   'minimum_quantity': 2,
#   'units': 'gallons',
#   'status': 'Current stock is 3 gallons more than minimum quantity'}]
# ```

# In[ ]:


get_inventory_details(inventory)


# In[ ]:




