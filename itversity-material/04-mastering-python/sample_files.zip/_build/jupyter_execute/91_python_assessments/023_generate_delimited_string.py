#!/usr/bin/env python
# coding: utf-8

# ## Generate Delimited String
# 
# Develop a function which takes one collection of type `list` or `set` or `dict` or `tuple` as argument and build delimited string.
# * This is primarily to ensure to assess the capabilities around string manipulation functions, the concepts of delimited strings and also ability to create reusable user defined functions by eliminating the redundancy of the code.
# * Here are the details of the function.
#   * Function Name: **gen_delim_string**
#   * Arguments: **coll** and **delim**.
#   * The function should return a delimited string.

# In[26]:


def gen_delim_string(coll, delim):
    return delim_string


# * Here are the steps to validate. Pass list, set, tuple and dict as below and ensure it matches desired output.

# In[16]:


order_list = [1, '2013-07-25 00:00:00.0', 11599, 'CLOSED']


# In[17]:


gen_delim_string(order_list, ',') # Desired Output: '1,2013-07-25 00:00:00.0,11599,CLOSED'


# In[18]:


order_set = {1, '2013-07-25 00:00:00.0', 11599, 'CLOSED'}


# In[19]:


gen_delim_string(order_set, '|') # Desired Output: '1,2013-07-25 00:00:00.0,11599,CLOSED'


# In[27]:


order_dict = {
    'order_id': 1,
    'order_date': '2013-07-25 00:00:00.0',
    'order_customer_id': 11599,
    'order_status': 'CLOSED'
}


# In[28]:


type(order_dict) == dict


# In[29]:


gen_delim_string(order_dict, ';') # Desired Output: '1;2013-07-25 00:00:00.0;11599;CLOSED'


# In[30]:


student_tuple = (1, 'Scott', 'Tiger', 'Python')


# In[31]:


gen_delim_string(student_tuple, ',') # Desired Output: '1,Scott,Tiger,Python'


# In[ ]:




