#!/usr/bin/env python
# coding: utf-8

# ## Get field list from election results
# 
# Develop a function to get the list of fields from tab delimited data.
# * This is primarily to assess the ability to read the delimited data and get metadata from it.
# * Use file I/O and collection libraries for this exercise.
# * Read the data from `/data/electionresults/ls2014.tsv`.
# * The first line in the file have the attribute names.
# * You need to read first line and then convert it to list of field names.

# In[ ]:


# Your code should go here

def get_field_names(file_name):
    # logic should go here
    return field_list


# In[ ]:


get_field_names('/data/electionresults/ls2014.tsv')


# * Here is the expected output.
# 
# ```python
# ['state',
#  'constituency',
#  'candidate_name',
#  'sex',
#  'age',
#  'category',
#  'partyname',
#  'partysymbol',
#  'general',
#  'postal',
#  'total',
#  'pct_of_total_votes',
#  'pct_of_polled_votes',
#  'totalvoters']
# ```

# In[ ]:




