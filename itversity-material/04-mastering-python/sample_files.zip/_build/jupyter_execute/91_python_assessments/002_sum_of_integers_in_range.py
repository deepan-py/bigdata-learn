#!/usr/bin/env python
# coding: utf-8

# ## Sum of Integers in Range
# 
# Develop a function to compute the sum of integers with in given range.
# * Name of the function: **sum_range**
# * Argument Names: **lb** and **ub**
# * Both arguments should be of type integers. If any of the arguments are not integers, then raise an exception saying **Either lb or ub are not integers**. You should display the values of lb and ub in the exception.
# * **lb** should be smaller than **ub**. If **lb** is not smaller than **ub**, you should raise an exception saying **lb is not smaller than ub**. You should display the values of lb and ub in the exception.

# In[1]:


# Your code with for loops should go in this cell


# In[ ]:


sum_range(1, 10) # It should return 55


# In[ ]:


sum_range(8, 10) # It should return 27


# In[2]:


# Your code with formula should go in this cell


# In[ ]:


sum_range(1, 10) # It should return 55


# In[ ]:


sum_range(8, 10) # It should return 27


# * Which of the two approaches is efficient?  Loops or Formula
# * Define order of complexity for both the approaches (if you are familiar with it)

# In[ ]:




