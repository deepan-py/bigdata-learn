#!/usr/bin/env python
# coding: utf-8

# ## Generate Table Of Contents
# 
# Develop the code to go through a directory and its first level subfolders to create table of contents with sub folder names and files with in them.
# * This is primarily to test the ability to handle files and also assess the ability to deal with collections.
# * For a given base directory, you should iterate through all the first level subfolders and then files with extension **.ipynb**.
# * You can run this below cell to get an idea. 

# In[ ]:


import getpass
username = getpass.getuser()


# In[ ]:


path = f'/home/{username}/itversity-material/mastering-python'


# ### Step 1: Check if path exists
# * Validate if path exists

# In[ ]:


# Code should go here


# ### Step 2: Get all the notebook names
# 
# Let us get absolute or fully qualified names of the notebooks.
# * Get all the names of the Python Notebooks in ascending order by the names.
# * Create a variable of type list with notebook names as strings in that list.
# * Name: **notebooks**

# In[ ]:


# Code should go here


# ### Step 3: Get Folder and Notebook names
# 
# We need to make sure that all the notebook names are used as topics while folder names are used as sections. A section can contain several topics.
# * Create list of tuples which contain first level of folder as first element and the notebook name as second element.
# * Use notebooks from the previous step and use map function to apply the transformation.
# * Assign the new list to a variable called as **sections_and_topics**
# * Make sure to discard the extension for the file.
# * Here is the sample output. It does not cover all the output.
# 
# ```python
# [('01_overview_of_windows_os', '01_overview_of_windows_os'),
#  ('01_overview_of_windows_os', '02_getting_system_details'),
#  ('01_overview_of_windows_os', '03_managing_windows_system'),
#  ('01_overview_of_windows_os', '04_overview_of_microsoft_office'),
#  ('01_overview_of_windows_os', '05_overview_of_editors_and_ides'),
#  ('01_overview_of_windows_os', '06_power_shell_and_command_prompt'),
#  ('01_overview_of_windows_os', '07_connecting_to_linux_servers'),
#  ('01_overview_of_windows_os', '08_folders_and_files'),
#  ('02_setup_ubuntu_vm_on_gcp', '01_setup_ubuntu_vm_on_gcp'),
#  ('02_setup_ubuntu_vm_on_gcp', '02_signing_up_for_gcp'),
#  ('02_setup_ubuntu_vm_on_gcp', '03_understanding_gcp_web_console'),
#  ('02_setup_ubuntu_vm_on_gcp', '04_overview_of_gcp_pricing'),
#  ('02_setup_ubuntu_vm_on_gcp', '05_provision_ubuntu_18'),
#  ('02_setup_ubuntu_vm_on_gcp', '06_setup_docker'),
# ```

# In[ ]:


# Code should go here


# ### Step 4: Group notebooks by folder
# 
# We can now group the notebook names by folder.
# * Create a new list of tuples using **sections_and_topics** created as part of the previous step.
# * Each tuple in the list should contain 2 elements.
# * First element should be the folder name and second element in the tuple should be the list of elements.
# * You can use `itertools`. It have a function to group the data by a given key.
# * The name of the variable should be **topics_grouped**

# In[ ]:


# Your code should go here


# In[ ]:


# You can use below code to validate whether data is grouped or not
for k, v in topics_grouped:
    print(f'{k} : {len(list(v))}')


# ### Step 5: Generate Table of Contents
# 
# Now let us use **topics_grouped** to generate table of contents.
# 
# * Develop the code to print the table of contents.
# * Here is the sample structure. You can also review **_toc.yml** under **mastering-python** folder.
# * Make sure to format the data as you see in the example. Spend sometime in understanding how the data is. You can also open the file **_toc.yml** of this course.
# 
# ```
# - file: 01_overview_of_windows_os/01_overview_of_windows_os
#   sections:
#   - file: 01_overview_of_windows_os/02_getting_system_details
#   - file: 01_overview_of_windows_os/03_managing_windows_system
#   - file: 01_overview_of_windows_os/04_overview_of_microsoft_office
#   - file: 01_overview_of_windows_os/05_overview_of_editors_and_ides
#   - file: 01_overview_of_windows_os/06_power_shell_and_command_prompt
#   - file: 01_overview_of_windows_os/07_connecting_to_linux_servers
#   - file: 01_overview_of_windows_os/08_folders_and_files
# 
# - file: 02_setup_ubuntu_vm_on_gcp/01_overview_of_gcp_and_provision_ubuntu_vm
#   sections:
#   - file: 02_setup_ubuntu_vm_on_gcp/02_signing_up_for_gcp
#   - file: 02_setup_ubuntu_vm_on_gcp/03_understanding_gcp_web_console
#   - file: 02_setup_ubuntu_vm_on_gcp/04_overview_of_gcp_pricing
#   - file: 02_setup_ubuntu_vm_on_gcp/05_provision_ubuntu_18
#   - file: 02_setup_ubuntu_vm_on_gcp/06_setup_docker
#   - file: 02_setup_ubuntu_vm_on_gcp/07_validating_python
#   - file: 02_setup_ubuntu_vm_on_gcp/08_setup_jupyter_lab
# ```

# In[ ]:


# Your code should go here

