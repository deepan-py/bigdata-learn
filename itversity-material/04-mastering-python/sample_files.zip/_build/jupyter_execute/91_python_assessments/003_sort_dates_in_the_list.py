#!/usr/bin/env python
# coding: utf-8

# ## Sort Dates in the list
# 
# Develop a program to sort the dates in the list. You should use appropriate sort function for the same. This is primarily to test the comfort level on sorting the data as well as manipulating dates.
# 
# **Hint: Use datetime library to format the dates**
# * Here are the details for formatting date components such as year, month, day etc.
#   * `%b`: Returns the first three characters of the month name. For example, September will be considered as "Sep"
#   * `%m`: Returns the the month in two-digit format. In our example, Septermber will be considered as 09
#   * `%d`: Returns day of the month, from 1 to 31. In our example, 5th of the month will be considered as 05
#   * `%Y`: Returns the year in four-digit format.
#   * `%H`: Returns the hour, from 00 to 23.
#   * `%M`: Returns the minute, from 00 to 59.
#   * `%S`: Returns the second, from 00 to 59. 
# * Here is the list of dates

# In[2]:


dates = [
    '13-Nov-2020', '20-Jul-2020', '14-Nov-2020', '21-Apr-2021',
    '03-May-2021', '01-Jan-2021', '26-Jan-2021', '15-Nov-2020',
    '12-Mar-2021', '12-Nov-2020'
]


# In[ ]:


# Your code should go here


# * Here is the desired output
# 
# ```python
# ['20-Jul-2020',
#  '12-Nov-2020',
#  '13-Nov-2020',
#  '14-Nov-2020',
#  '15-Nov-2020',
#  '01-Jan-2021',
#  '26-Jan-2021',
#  '12-Mar-2021',
#  '21-Apr-2021',
#  '03-May-2021']
#  ```

# In[ ]:




