#!/usr/bin/env python
# coding: utf-8

# ## Convert Players JSON to CSV List
# 
# Develop a function which will convert the contents of a JSON file into list of CSV elements.
# * This exercise is primarily to test the abilities to read the data from file, process json using **json** module and also manipulate collections.
# * First understand how the data is structured.
# * Develop the function which takes the string as argument. We will pass the path of the json file with famous players to it.
# * Read the json data from **/data/sports/famous_players.json**
# * Sort the data by country and then by name.
# * The function should return the sorted list.
# * You should use **json** module to process data. Do not use **pandas** for this problem.

# * Run this command to confirm whether file exists or not.

# In[2]:


get_ipython().system('ls -ltr /data/sports/famous_players.json')


# * Run this command to preview the data.

# In[3]:


get_ipython().system('cat /data/sports/famous_players.json')


# * Develop the function using the below cell.

# In[ ]:


# Your solution should go here
import json
def get_players_csv_list(file_path):
    # Develop the logic here
    return players_csv_list


# * You can run the below cell to validate the function

# In[ ]:


for player in get_players_csv_list('/data/sports/famous_players.json'):
    print(player)


# * Here is the expected output.
# 
# ```
# Diego Maradona,Argentina,Soccer
# Ian Thorpe,Australia,Swimming
# Shane Warne,Australia,Cricket
# Ronaldo,Brazil,Soccer
# David Beckham,England,Cricket
# P. V. Sindhu,India,Badminton
# Sachin Tendulkar,India,Cricket
# Usain Bolt,Jamaica,Running
# Roger Federer,Switzerland,Tennis
# Michael Phelps,USA,Swimming
# Pete Sampras,USA,Tennis
# Brian Lara,West Indies,Cricket
# ```

# In[ ]:




