#!/usr/bin/env python
# coding: utf-8

# ## Date and Time Objects
# 
# As part of this exercise, perform multiple tasks to create date and time objects.
# * It is primarily to test the ability to convert date values in  different data types to dates and vice versa.
# 
# **Hint: Use datetime library to format the dates**
# * Here are the details for formatting date components such as year, month, day etc.
#   * `%b`: Returns the first three characters of the month name. For example, September will be considered as "Sep"
#   * `%m`: Returns the the month in two-digit format. In our example, Septermber will be considered as 09
#   * `%d`: Returns day of the month, from 1 to 31. In our example, 5th of the month will be considered as 05
#   * `%Y`: Returns the year in four-digit format.
#   * `%H`: Returns the hour, from 00 to 23.
#   * `%M`: Returns the minute, from 00 to 59.
#   * `%S`: Returns the second, from 00 to 59. 
# * Feel free to use google to use for other formats.

# * Get today's date using **yyyy-MM-dd** format (2021-05-24)

# In[14]:


# Your code snippet should go here


# * Convert the below integer into date object.

# In[13]:


dt_int = 20210524


# In[21]:


# Your code snippet should go here
print(datetime.strptime(str(dt_int), '%Y%m%d'))


# * Convert date and time to a string to this format **yyyy-MM-dd HH24:mm:ss**
#   * yyyy - 4 digit year
#   * MM - 2 digit month
#   * dd - 2 digit day
#   * HH24 - 2 digit 24 hour format
#   * mm - 2 digit minute
#   * ss - 2 digit second
# * Expected output - **2021-01-01 23:50:55**

# In[15]:


import datetime


# In[16]:


from datetime import datetime


# In[18]:


dt = datetime(2021, 1, 1, 23, 50, 55)


# In[ ]:




