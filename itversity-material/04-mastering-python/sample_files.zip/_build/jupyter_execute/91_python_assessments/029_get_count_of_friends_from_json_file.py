#!/usr/bin/env python
# coding: utf-8

# ## Get count of friends from json file
# 
# Develop the logic to get the count of friends for each user.
# * Data is in **./data/users/user_data.json**.
# * The exercise is to get the count of friends for each user using list of dicts.
# * Output should contain user_id and count and data should be descending order by count. If the count is same, then data should be further sorted in ascending order by user_id.

# In[ ]:


get_ipython().system('ls -ltr ./data/users/user_data.json')


# In[ ]:


get_ipython().system('cat ./data/users/user_data.json')


# * Using **file_path**, get the count by friends.

# In[ ]:


# Your logic should go here

def get_friend_count(file_path):

    return friend_count


# * You can validate by running below cells. Here is the desired output.
# 
# ```python
# [{'user_id': 'CX3zVZCP6_TO9c-AHkDG0Q', 'friend_count': 5},
#  {'user_id': 'dMtkqy7SpggEFAGFkCbyDQ', 'friend_count': 5},
#  {'user_id': '7pIUGJ224G589mfGZaUJmg', 'friend_count': 4},
#  {'user_id': 'RdGxKWUqrkqmnSEhzBgiig', 'friend_count': 4},
#  {'user_id': '_6CTDWsw4Fdr6R9ZzKvLZQ', 'friend_count': 4},
#  {'user_id': 'a7QBKnU1ygMoxFmJKoiR3g', 'friend_count': 4},
#  {'user_id': 'KLgBbAHOWumaXjEQwUDpmA', 'friend_count': 3},
#  {'user_id': 'vNx3FrO1zRkXTKGkypcDEA', 'friend_count': 3},
#  {'user_id': 'PA2MNztWmRx9JBvbz9wd4A', 'friend_count': 1},
#  {'user_id': 'V0b6qQt_mF21xg_--BFw5Q', 'friend_count': 1}]
# ```

# In[ ]:


friend_count = get_friend_count('./data/users/user_data.json')


# In[ ]:


friend_count


# In[ ]:




