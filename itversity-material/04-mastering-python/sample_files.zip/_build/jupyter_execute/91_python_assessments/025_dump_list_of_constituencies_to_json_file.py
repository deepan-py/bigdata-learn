#!/usr/bin/env python
# coding: utf-8

# ## Dump list of constituencies to JSON File
# 
# Develop a function to dump list of constituencies from election results to JSON File using Pandas.
# * This is primarily to assess the ability to read the delimited data and convert into different format.
# * This is helpful in reading CSV data, convert to dict and then write to databases such as MongoDB.
# * Solve this problem using **Pandas** library.
# * Read the data from `/data/electionresults/ls2014.tsv`.
# * Write the data to `/home/${USER}/output/electionresults/constituencies.json`
# * The first line in the file have the attribute names.
# * Use Pandas to read the data with field names, get distinct constituencies (state name and constituency) and then write to JSON file.
# * The output should be sorted in ascending order by state and then by constituency.
# * The file should contain one JSON document per line. Here is example.
# 
# ```json
# {'state': 'Andaman & Nicobar Islands', 'constituency': 'Andaman & Nicobar Islands'}
# {'state': 'Andhra Pradesh', 'constituency': 'Adilabad'}
# ```

# * Confirm whether file exists.

# In[ ]:


get_ipython().system('ls -ltr /data/electionresults/ls2014.tsv')


# * Get first five lines of the file to understand how the data look like. You can understand details about field names.

# In[ ]:


get_ipython().system('head -5 /data/electionresults/ls2014.tsv')


# * Get the count of unique constituencies. It will be useful for us to validate the number of elements in list of dicts.

# In[ ]:


get_ipython().system('awk -F"\\t" \'{ print $1 ":" $2}\' /data/electionresults/ls2014.tsv|grep -wv "constituency"|sort|uniq|wc -l')


# In[ ]:


# Your code should go here
import pandas as pd
def save_unique_constituencies(input_file_name, output_file_name):
    # read from input_file_name
    # process and write to output_file_name

    return


# In[ ]:


get_ipython().system('mkdir -p /home/${USER}/output/electionresults')


# In[ ]:


import getpass
username = getpass.getuser()

input_file_name = '/data/electionresults/ls2014.tsv'
output_file_name = f'/home/{username}/output/electionresults/constituencies.json'
save_unique_constituencies(input_file_name, output_file_name)


# * Validation - Check if the file is created or not

# In[ ]:


get_ipython().system('ls -ltr /home/${USER}/output/electionresults # You should see the constituencies.json file as part of the output')


# * Validation - Get first five records using head command
# * Expected output
# 
# ```json
# {"state":"Andaman & Nicobar Islands","constituency":"Andaman & Nicobar Islands"}
# {"state":"Andhra Pradesh","constituency":"Adilabad "}
# {"state":"Andhra Pradesh","constituency":"Amalapuram "}
# {"state":"Andhra Pradesh","constituency":"Anakapalli"}
# {"state":"Andhra Pradesh","constituency":"Anantapur"}
# ```

# In[ ]:


get_ipython().system('head -5 /home/${USER}/output/electionresults/constituencies.json')


# * You can also run this code to validate. Here is the expected output.
# 
# ```python
# {'state': 'Andaman & Nicobar Islands', 'constituency': 'Andaman & Nicobar Islands'}
# {'state': 'Andhra Pradesh', 'constituency': 'Adilabad '}
# {'state': 'Andhra Pradesh', 'constituency': 'Amalapuram '}
# {'state': 'Andhra Pradesh', 'constituency': 'Anakapalli'}
# {'state': 'Andhra Pradesh', 'constituency': 'Anantapur'}
# ```

# In[ ]:


import json, getpass

username = getpass.getuser()
data = open(f'/home/{username}/output/electionresults/constituencies.json').read().splitlines()

for rec in data[:5]:
    print(json.loads(rec))


# In[ ]:




