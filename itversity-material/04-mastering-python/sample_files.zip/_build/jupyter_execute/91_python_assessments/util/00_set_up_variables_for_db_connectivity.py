#!/usr/bin/env python
# coding: utf-8

# ## Set up variables for DB Connectivity
# 
# This notebook will be run from other notebooks. We are going to set up variables required for database connectivity.
# 
# We will provide the required information. You can use the labs password which is assigned to you.

# In[ ]:


import getpass


# In[2]:


username = getpass.getuser()


# In[3]:


# Paste your password between the single quotes


# In[4]:


password = ''


# In[5]:


postgres_host = 'm01.itversity.com'


# In[6]:


postgres_port = 5433

