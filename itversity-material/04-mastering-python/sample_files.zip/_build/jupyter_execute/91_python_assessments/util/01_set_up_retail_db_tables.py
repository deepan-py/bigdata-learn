#!/usr/bin/env python
# coding: utf-8

# ## Set up retail_db tables
# 
# Let us set up retail_db tables for the assessments. This notebook will be executed from other notebooks that are part of the assessment scenarios.

# In[1]:


get_ipython().run_line_magic('run', '00_set_up_variables_for_db_connectivity.ipynb')


# In[2]:


get_ipython().run_line_magic('load_ext', 'sql')


# In[3]:


get_ipython().run_line_magic('env', 'DATABASE_URL=postgresql://{username}_sms_user:{password}@{postgres_host}:{postgres_port}/{username}_sms_db')


# In[6]:


get_ipython().run_cell_magic('sql', '', "\nSELECT len('Hello')")


# In[7]:


get_ipython().run_cell_magic('sql', '', "\nSELECT length('Hello')")


# In[ ]:


get_ipython().run_cell_magic('sql', '', '\nDROP TABLE departments;\nDROP TABLE categories;\nDROP TABLE products;\nDROP TABLE customers;\nDROP TABLE orders;\nDROP TABLE order_items;')


# In[ ]:


get_ipython().run_cell_magic('sql', '', '\n-- Postgres Table Creation Script\n--\n\n--\n-- Table structure for table departments\n--\n\nCREATE TABLE departments (\n  department_id INT NOT NULL,\n  department_name VARCHAR(45) NOT NULL,\n  PRIMARY KEY (department_id)\n);\n\n--\n-- Table structure for table categories\n--\n\nCREATE TABLE categories (\n  category_id INT NOT NULL,\n  category_department_id INT NOT NULL,\n  category_name VARCHAR(45) NOT NULL,\n  PRIMARY KEY (category_id)\n);\n\n--\n-- Table structure for table products\n--\n\nCREATE TABLE products (\n  product_id INT NOT NULL,\n  product_category_id INT NOT NULL,\n  product_name VARCHAR(45) NOT NULL,\n  product_description VARCHAR(255) NOT NULL,\n  product_price FLOAT NOT NULL,\n  product_image VARCHAR(255) NOT NULL,\n  PRIMARY KEY (product_id)\n);\n\n--\n-- Table structure for table customers\n--\n\nCREATE TABLE customers (\n  customer_id INT NOT NULL,\n  customer_fname VARCHAR(45) NOT NULL,\n  customer_lname VARCHAR(45) NOT NULL,\n  customer_email VARCHAR(45) NOT NULL,\n  customer_password VARCHAR(45) NOT NULL,\n  customer_street VARCHAR(255) NOT NULL,\n  customer_city VARCHAR(45) NOT NULL,\n  customer_state VARCHAR(45) NOT NULL,\n  customer_zipcode VARCHAR(45) NOT NULL,\n  PRIMARY KEY (customer_id)\n);\n\n--\n-- Table structure for table orders\n--\n\nCREATE TABLE orders (\n  order_id INT NOT NULL,\n  order_date TIMESTAMP NOT NULL,\n  order_customer_id INT NOT NULL,\n  order_status VARCHAR(45) NOT NULL,\n  PRIMARY KEY (order_id)\n);\n\n--\n-- Table structure for table order_items\n--\n\nCREATE TABLE order_items (\n  order_item_id INT NOT NULL,\n  order_item_order_id INT NOT NULL,\n  order_item_product_id INT NOT NULL,\n  order_item_quantity INT NOT NULL,\n  order_item_subtotal FLOAT NOT NULL,\n  order_item_product_price FLOAT NOT NULL,\n  PRIMARY KEY (order_item_id)\n);')


# In[3]:


import psycopg2
import sqlalchemy as db
from sqlalchemy.ext.declarative import declarative_base
Base = declarative_base()

engine = db.create_engine(f'postgresql://{username}_sms_user:{password}@{postgres_host}:{postgres_port}/{username}_sms_db')


# In[ ]:


statements = open('/data/retail_db/load_db_tables_pg.sql').read().splitlines()


# In[ ]:


statements_no_empty = list(filter(lambda stmt: stmt != '', statements))


# In[ ]:


for statement in statements_no_empty:
    engine.execute(db.text(statement))


# In[4]:


help(engine.execute)


# In[ ]:




