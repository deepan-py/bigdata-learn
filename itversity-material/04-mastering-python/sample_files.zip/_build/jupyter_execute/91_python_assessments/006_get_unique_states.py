#!/usr/bin/env python
# coding: utf-8

# ## Get unique states
# 
# Develop a function which process the list of strings which contain addresses. It should return the list of unique states from these addresses.
# * This is primarily to test the understanding of string manipulation functions as well as map reduce functions such as `map`.
# * Each address contain street address, optional number, city and state. All these are comma seperated.
# * The function should return the states from the address.
# * States should be sorted in ascending order.
# 
# **Restriction: The code should not contain the loops**

# In[9]:


def get_unique_states(addresses):
    # Logic should go here

    return states


# * You can run below cells to validate the code

# In[10]:


addresses = [
    '67 Bobwhite Avenue,Suite 20,Washington,District of Columbia',
    '9 Stoughton Place,Orlando,Florida',
    '5940 Kedzie Terrace,#316,New York City,New York',
    '4519 7th Street,NA,Rochester,New York',
    '3 Truax Pass,Apt 400,Louisville,Kentucky',
    '8 Hauk Street,Indianapolis,Indiana',
    '10 Spaight Street,San Francisco,California',
    '042 Tennyson Way,#18,Columbus,Georgia',
    '6957 Crescent Oaks Park,Topeka,Kansas',
    '94 Talmadge Circle,San Antonio,Texas'
]


# In[11]:


get_unique_states(addresses)


# * Here is the desired output
# 
# ```python
# ['California',
#  'District of Columbia',
#  'Florida',
#  'Georgia',
#  'Indiana',
#  'Kansas',
#  'Kentucky',
#  'New York',
#  'Texas']
# ```

# In[ ]:




