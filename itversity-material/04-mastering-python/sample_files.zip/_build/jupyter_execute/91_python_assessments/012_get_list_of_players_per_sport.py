#!/usr/bin/env python
# coding: utf-8

# ## Get list of players per sport
# 
# Develop a function to get list of players per sport using the dict which contain player name and the sport he plays.
# * This is primarily to assess the abilities to manipulate lists.
# * You can solve this problem either by using loops or itertools or any alternative library.
# * The input dictionary will contain name of the player as the key and the sport he plays as the value.
# * The output dictionary should contain the sport as key and the players per sport as value. The player names should be part of a list for that sport.

# In[ ]:


famous_players = {
    'Pete Sampras': 'Tennis',
    'Sachin Tendulkar': 'Cricket',
    'Brian Lara': 'Cricket',
    'Diego Maradona': 'Soccer',
    'Roger Federer': 'Tennis',
    'Ian Thorpe': 'Swimming',
    'Ronaldo': 'Soccer',
    'Usain Bolt': 'Running',
    'P. V. Sindhu': 'Badminton',
    'Shane Warne': 'Cricket',
    'David Beckham': 'Cricket',
    'Michael Phelps': 'Swimming'
}


# In[ ]:


def get_players_per_sport(famous_players):
    # Code should go here
    return player_per_support


# * You can run the below cell to validate.

# In[ ]:


get_players_per_sport(famous_players)


# * Here is the desired output.
# 
# ```python
# {'Badminton': ['P. V. Sindhu'],
#  'Cricket': ['Brian Lara', 'David Beckham', 'Sachin Tendulkar', 'Shane Warne'],
#  'Running': ['Usain Bolt'],
#  'Soccer': ['Diego Maradona', 'Ronaldo'],
#  'Swimming': ['Ian Thorpe', 'Michael Phelps'],
#  'Tennis': ['Pete Sampras', 'Roger Federer']}
# ```

# In[ ]:




