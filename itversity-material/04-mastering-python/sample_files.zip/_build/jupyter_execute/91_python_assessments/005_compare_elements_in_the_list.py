#!/usr/bin/env python
# coding: utf-8

# ## Compare elements in the list
# 
# Develop a function which takes 2 lists as arguments and compare corresponding elements in the list. The output should contain boolean values with `True` or `False`. If the element in the first list is greater than the corresponding element in the second list, then it should be `True` otherwise it should be `False`.
# 
# The function should return the list which contain the boolean values.

# In[ ]:


def compare_lists(l1, l2):
    # comparison logic should go here
    
    return l3


# * You can run below cells to validate the code

# In[ ]:


l1 = [5, 1, 7, 3]


# In[ ]:


l2 = [3, 6, 5, 8]


# In[ ]:


compare_lists(l1, l2)


# * Here is the desired output
# 
# ```python
# [True, False, True, False]
# ```
