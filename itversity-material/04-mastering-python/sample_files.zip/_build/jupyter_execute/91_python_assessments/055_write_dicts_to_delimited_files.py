#!/usr/bin/env python
# coding: utf-8

# ## Write dicts to delimited files
# 
# Develop a function to write the list of dicts to delimited files. The function should take the list of dicts, delimiter, and file name as argument.
# * The output should contain header.
# * Attribute values in each record should be delimited by the delimiter passed.
# * Keep in mind that `csv` need not be comma separated. We can use any delimiter. Some of the commonly used delimiters are `,` (comma), `|` (pipe), `;` (semicolon), `:` (colon),  `\t` (tab), etc.
# 
# **Restriction: You need to use `pandas` to write data to files. Also, by default `pandas` writes index to the file. Make sure to not to write index of each record to the file.**

# In[ ]:


import pandas as pd
def write_dicts(dicts, delim, file_name):
    return


# * Run below cells to validate. You should see the data with header and pipe as delimiter between attribute values. Make sure to see only 4 attribute values in each line. The index of each row in Dataframe should not be written to the file.
# 
# ```shell
# order_id|order_date|order_customer_id|order_status
# 1|2013-07-25 00:00:00.0|11599|CLOSED
# 2|2013-07-25 00:00:00.0|256|PENDING_PAYMENT
# 3|2013-07-25 00:00:00.0|12111|COMPLETE
# 4|2013-07-25 00:00:00.0|8827|CLOSED
# 5|2013-07-25 00:00:00.0|11318|COMPLETE
# ```

# In[ ]:


orders = [{'order_id': 1,
  'order_date': '2013-07-25 00:00:00.0',
  'order_customer_id': 11599,
  'order_status': 'CLOSED'},
 {'order_id': 2,
  'order_date': '2013-07-25 00:00:00.0',
  'order_customer_id': 256,
  'order_status': 'PENDING_PAYMENT'},
 {'order_id': 3,
  'order_date': '2013-07-25 00:00:00.0',
  'order_customer_id': 12111,
  'order_status': 'COMPLETE'},
 {'order_id': 4,
  'order_date': '2013-07-25 00:00:00.0',
  'order_customer_id': 8827,
  'order_status': 'CLOSED'},
 {'order_id': 5,
  'order_date': '2013-07-25 00:00:00.0',
  'order_customer_id': 11318,
  'order_status': 'COMPLETE'}]


# In[ ]:


get_ipython().system('mkdir -p /home/${USER}/output')


# In[ ]:


import getpass
username = getpass.getuser()
write_dicts(orders, '|', f'/home/{username}/output/orders.csv')


# In[ ]:


get_ipython().system('cat /home/${USER}/output/orders.csv # The output should not have Pandas Data Frame Index')


# * Run below cells to validate. You should see the data with header and `\t` as delimiter between attribute values.
# 
# ```text
# course_name	course_author	course_status	course_publised_dt
# Programming using Python	Bob Dillon	published	2020-09-30
# Data Engineering using Python	Bob Dillon	published	2020-07-15
# Data Engineering using Scala	Elvis Presley	draft	
# Programming using Scala	Elvis Presley	published	2020-05-12
# Programming using Java	Mike Jack	inactive	2020-08-10
# Web Applications - Python Flask	Bob Dillon	inactive	2020-07-20
# Web Applications - Java Spring	Mike Jack	draft	
# Pipeline Orchestration - Python	Bob Dillon	draft	
# Streaming Pipelines - Python	Bob Dillon	published	2020-10-05
# Web Applications - Scala Play	Elvis Presley	inactive	2020-09-30
# Web Applications - Python Django	Bob Dillon	published	2020-06-23
# Server Automation - Ansible	Uncle Sam	published	2020-07-05
# ```

# In[ ]:


courses = [{'course_name': 'Programming using Python',
  'course_author': 'Bob Dillon',
  'course_status': 'published',
  'course_publised_dt': '2020-09-30'},
 {'course_name': 'Data Engineering using Python',
  'course_author': 'Bob Dillon',
  'course_status': 'published',
  'course_publised_dt': '2020-07-15'},
 {'course_name': 'Data Engineering using Scala',
  'course_author': 'Elvis Presley',
  'course_status': 'draft',
  'course_publised_dt': None},
 {'course_name': 'Programming using Scala',
  'course_author': 'Elvis Presley',
  'course_status': 'published',
  'course_publised_dt': '2020-05-12'},
 {'course_name': 'Programming using Java',
  'course_author': 'Mike Jack',
  'course_status': 'inactive',
  'course_publised_dt': '2020-08-10'},
 {'course_name': 'Web Applications - Python Flask',
  'course_author': 'Bob Dillon',
  'course_status': 'inactive',
  'course_publised_dt': '2020-07-20'},
 {'course_name': 'Web Applications - Java Spring',
  'course_author': 'Mike Jack',
  'course_status': 'draft',
  'course_publised_dt': None},
 {'course_name': 'Pipeline Orchestration - Python',
  'course_author': 'Bob Dillon',
  'course_status': 'draft',
  'course_publised_dt': None},
 {'course_name': 'Streaming Pipelines - Python',
  'course_author': 'Bob Dillon',
  'course_status': 'published',
  'course_publised_dt': '2020-10-05'},
 {'course_name': 'Web Applications - Scala Play',
  'course_author': 'Elvis Presley',
  'course_status': 'inactive',
  'course_publised_dt': '2020-09-30'},
 {'course_name': 'Web Applications - Python Django',
  'course_author': 'Bob Dillon',
  'course_status': 'published',
  'course_publised_dt': '2020-06-23'},
 {'course_name': 'Server Automation - Ansible',
  'course_author': 'Uncle Sam',
  'course_status': 'published',
  'course_publised_dt': '2020-07-05'}]


# In[ ]:


import getpass
username = getpass.getuser()
write_dicts(courses, '\t', f'/home/{username}/output/courses.tsv')


# In[ ]:


get_ipython().system('cat /home/${USER}/output/courses.tsv')


# In[ ]:




