#!/usr/bin/env python
# coding: utf-8

# ## Filter the course data
# 
# Develop logic to filter for published courses and sort the output by date in descending order.
# * We will provide courses data which will be of type list of dicts.
# * Get the courses which are published.
# * Sort the output by course_published_dt in descendig order.

# In[ ]:


courses = [{'course_name': 'Programming using Python',
  'course_author': 'Bob Dillon',
  'course_status': 'published',
  'course_published_dt': '2020-09-30'},
 {'course_name': 'Data Engineering using Python',
  'course_author': 'Bob Dillon',
  'course_status': 'published',
  'course_published_dt': '2020-07-15'},
 {'course_name': 'Data Engineering using Scala',
  'course_author': 'Elvis Presley',
  'course_status': 'draft',
  'course_published_dt': None},
 {'course_name': 'Programming using Scala',
  'course_author': 'Elvis Presley',
  'course_status': 'published',
  'course_published_dt': '2020-05-12'},
 {'course_name': 'Programming using Java',
  'course_author': 'Mike Jack',
  'course_status': 'inactive',
  'course_published_dt': '2020-08-10'},
 {'course_name': 'Web Applications - Python Flask',
  'course_author': 'Bob Dillon',
  'course_status': 'inactive',
  'course_published_dt': '2020-07-20'},
 {'course_name': 'Web Applications - Java Spring',
  'course_author': 'Mike Jack',
  'course_status': 'draft',
  'course_published_dt': None},
 {'course_name': 'Pipeline Orchestration - Python',
  'course_author': 'Bob Dillon',
  'course_status': 'draft',
  'course_published_dt': None},
 {'course_name': 'Streaming Pipelines - Python',
  'course_author': 'Bob Dillon',
  'course_status': 'published',
  'course_published_dt': '2020-10-05'},
 {'course_name': 'Web Applications - Scala Play',
  'course_author': 'Elvis Presley',
  'course_status': 'inactive',
  'course_published_dt': '2020-09-30'},
 {'course_name': 'Web Applications - Python Django',
  'course_author': 'Bob Dillon',
  'course_status': 'published',
  'course_published_dt': '2020-06-23'},
 {'course_name': 'Server Automation - Ansible',
  'course_author': 'Uncle Sam',
  'course_status': 'published',
  'course_published_dt': '2020-07-05'}]


# In[ ]:


# The logic should go here
def get_published_courses(courses):

    return published_courses


# In[ ]:


published_courses = get_published_courses(courses)


# In[ ]:


type(published_courses) # It should be list


# In[ ]:


len(published_courses) # It should be 6


# In[ ]:


type(published_courses[0]) # It should be dict


# * Here is the sample record
# 
# ```python
# {'course_name': 'Streaming Pipelines - Python',
#  'course_author': 'Bob Dillon',
#  'course_status': 'published',
#  'course_published_dt': '2020-10-05'}
# ```

# In[ ]:


published_courses[0]


# * Confirming that data is sorted in descending order. Run the below cell and compare.
# 
# ```python
# [{'course_name': 'Streaming Pipelines - Python',
#   'course_author': 'Bob Dillon',
#   'course_status': 'published',
#   'course_published_dt': '2020-10-05'},
#  {'course_name': 'Programming using Python',
#   'course_author': 'Bob Dillon',
#   'course_status': 'published',
#   'course_published_dt': '2020-09-30'},
#  {'course_name': 'Data Engineering using Python',
#   'course_author': 'Bob Dillon',
#   'course_status': 'published',
#   'course_published_dt': '2020-07-15'},
#  {'course_name': 'Server Automation - Ansible',
#   'course_author': 'Uncle Sam',
#   'course_status': 'published',
#   'course_published_dt': '2020-07-05'},
#  {'course_name': 'Web Applications - Python Django',
#   'course_author': 'Bob Dillon',
#   'course_status': 'published',
#   'course_published_dt': '2020-06-23'},
#  {'course_name': 'Programming using Scala',
#   'course_author': 'Elvis Presley',
#   'course_status': 'published',
#   'course_published_dt': '2020-05-12'}]
# ```

# In[ ]:


[course for course in published_courses]


# In[ ]:




