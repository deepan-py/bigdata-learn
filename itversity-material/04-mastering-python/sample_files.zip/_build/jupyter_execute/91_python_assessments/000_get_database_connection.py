#!/usr/bin/env python
# coding: utf-8

# ## Get Database Connection
# 
# This notebook will be run from other notebooks. It contains the logic for a function called as `get_pg_connection`. You will be invoking this function in other notebooks.
# 
# We will provide the required information. You can use the labs password which is assigned to you.

# In[1]:


import getpass


# In[2]:


username = getpass.getuser()


# In[3]:


# Paste your password between the single quotes


# In[4]:


password = 'Itv3rs1ty!23'


# In[5]:


postgres_host = 'm01.itversity.com'


# In[6]:


postgres_port = 5433


# In[7]:


import psycopg2

def get_pg_connection(host, port, database, user, password):
    connection = None
    try:
        connection = psycopg2.connect(
            host=host,
            port=port,
            database=database,
            user=user,
            password=password
        )
    except Exception as e:
        raise(e)
    
    return connection


# In[ ]:




