#!/usr/bin/env python
# coding: utf-8

# ## Generate List of Delimited Strings
# 
# Develop a function which takes a list of lists or list of tuples or list of dicts or list of sets and return list of delimited strings.
# * This is primarily to ensure to assess the capabilities around string manipulation functions, the concepts of delimited strings and also ability to create reusable user defined functions by eliminating the redundancy of the code.
# * This will also assess the abilities to process data in collections.
# * Here are the details of the function.
#   * Function Name: **gen_delim_list**
#   * Arguments: **coll** and **delim**.
#   * The function should return a delimited string.
#   
# **Restriction: You are not supposed to use `pandas` or `csv` modules**

# ### Step 1: Generate Delimited String
# 
# Create a function by name `gen_delim_string`. This is supposed to be called from another function which will process the main list.
# * It takes 2 arguments, `ele` and `delim`.
# * Irrespective of type of `ele`, we are supposed to return delimited string.

# In[ ]:


def gen_delim_string(ele, delim):
    return delim_string


# * Here are the steps to validate. Pass list, set, tuple and dict as below and ensure it matches desired output.

# In[ ]:


order_list = [1, '2013-07-25 00:00:00.0', 11599, 'CLOSED']


# In[ ]:


gen_delim_string(order_list, ',') # Desired Output: '1,2013-07-25 00:00:00.0,11599,CLOSED'


# In[ ]:


order_set = {1, '2013-07-25 00:00:00.0', 11599, 'CLOSED'}


# In[ ]:


gen_delim_string(order_set, '|') # Desired Output: '1,2013-07-25 00:00:00.0,11599,CLOSED'


# In[ ]:


order_dict = {
    'order_id': 1,
    'order_date': '2013-07-25 00:00:00.0',
    'order_customer_id': 11599,
    'order_status': 'CLOSED'
}


# In[ ]:


type(order_dict) == dict


# In[ ]:


gen_delim_string(order_dict, ';') # Desired Output: '1;2013-07-25 00:00:00.0;11599;CLOSED'


# In[ ]:


student_tuple = (1, 'Scott', 'Tiger', 'Python')


# In[ ]:


gen_delim_string(student_tuple, ',') # Desired Output: '1,Scott,Tiger,Python'


# ### Step 2: Generated Delimited List
# 
# Develop a function, which takes list of collection and return list of delimited strings.
# * Here are the details of the function.
#   * Function Name: **gen_delim_list**
#   * Arguments: **coll** and **delim**.
#   * The function should return a delimited string.
# * Make sure to call `gen_delim_string` while processing each element. You need to use `map` function to apply required transformation.

# In[ ]:


def gen_delim_list(coll, delim):
    return delim_list


# * Run below cells to validate with list of lists. The output should be as below.
# 
# ```python
# ['1,2013-07-25 00:00:00.0,11599,CLOSED',
#  '2,2013-07-25 00:00:00.0,256,PENDING_PAYMENT',
#  '3,2013-07-25 00:00:00.0,12111,COMPLETE',
#  '4,2013-07-25 00:00:00.0,8827,CLOSED',
#  '5,2013-07-25 00:00:00.0,11318,COMPLETE']
# ```

# In[ ]:


orders = [[1, '2013-07-25 00:00:00.0', 11599, 'CLOSED'],
 [2, '2013-07-25 00:00:00.0', 256, 'PENDING_PAYMENT'],
 [3, '2013-07-25 00:00:00.0', 12111, 'COMPLETE'],
 [4, '2013-07-25 00:00:00.0', 8827, 'CLOSED'],
 [5, '2013-07-25 00:00:00.0', 11318, 'COMPLETE']]


# In[ ]:


list(gen_delim_list(orders, ','))


# * Run below cells to validate with list of dicts. The output should be as below.
# 
# ```python
# ['1|2013-07-25 00:00:00.0|11599|CLOSED',
#  '2|2013-07-25 00:00:00.0|256|PENDING_PAYMENT',
#  '3|2013-07-25 00:00:00.0|12111|COMPLETE',
#  '4|2013-07-25 00:00:00.0|8827|CLOSED',
#  '5|2013-07-25 00:00:00.0|11318|COMPLETE']
# ```

# In[ ]:


orders = [{'order_id': 1,
  'order_date': '2013-07-25 00:00:00.0',
  'order_customer_id': 11599,
  'order_status': 'CLOSED'},
 {'order_id': 2,
  'order_date': '2013-07-25 00:00:00.0',
  'order_customer_id': 256,
  'order_status': 'PENDING_PAYMENT'},
 {'order_id': 3,
  'order_date': '2013-07-25 00:00:00.0',
  'order_customer_id': 12111,
  'order_status': 'COMPLETE'},
 {'order_id': 4,
  'order_date': '2013-07-25 00:00:00.0',
  'order_customer_id': 8827,
  'order_status': 'CLOSED'},
 {'order_id': 5,
  'order_date': '2013-07-25 00:00:00.0',
  'order_customer_id': 11318,
  'order_status': 'COMPLETE'}]


# In[ ]:


list(gen_delim_list(orders, '|'))


# In[ ]:




