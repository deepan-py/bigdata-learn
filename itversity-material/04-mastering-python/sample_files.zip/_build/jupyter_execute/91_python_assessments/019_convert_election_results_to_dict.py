#!/usr/bin/env python
# coding: utf-8

# ## Convert election results to dict
# 
# Develop a function to convert election results to dict.
# * This is primarily to assess the ability to read the delimited data and convert into different format.
# * This is helpful in reading CSV data, convert to dict and then write to databases such as MongoDB.
# * Use file I/O and collection libraries for this exercise. Don't use Pandas for this.
# * Read the data from `/data/electionresults/ls2014.tsv`.
# * The first line in the file have the attribute names.
# * You need to read first line and then convert it to list of field names.
# * For each row build the dict using the field names from the first row and data from respective row. The fields names should be used as keys in each of the dict.
# * Finally we should get list of dicts. The number of records in the list should be same as **number of records in the file - 1**.

# * Confirm whether file exists.

# In[ ]:


get_ipython().system('ls -ltr /data/electionresults/ls2014.tsv')


# * Get first five lines of the file to understand how the data look like. You can understand details about field names.

# In[ ]:


get_ipython().system('head -5 /data/electionresults/ls2014.tsv')


# * Get the number of records from the file. It will be useful for us to validate the number of elements in list of dicts.

# In[ ]:


get_ipython().system('wc -l /data/electionresults/ls2014.tsv')


# In[ ]:


# Your code should go here

def get_list_elec_results_dicts(file_name):
    # logic should go here
    return list_elec_results_dicts


# In[ ]:


list_elec_results_dicts = get_list_elec_results_dicts('/data/electionresults/ls2014.tsv')


# * Validation - Get the count of the list. It should be 8355

# In[ ]:


len(list_elec_results_dicts)


# * Validation - Get first 2 records. Here is the sample output.
# 
# ```python
# [{'state': 'Andhra Pradesh',
#   'constituency': 'Adilabad ',
#   'candidate_name': 'GODAM NAGESH',
#   'sex': 'M',
#   'age': '49',
#   'category': 'ST',
#   'partyname': 'TRS',
#   'partysymbol': 'Car',
#   'general': '425762',
#   'postal': '5085',
#   'total': '430847',
#   'pct_of_total_votes': '31.07931864',
#   'pct_of_polled_votes': '40.81807244',
#   'totalvoters': '1386282'},
#  {'state': 'Andhra Pradesh',
#   'constituency': 'Adilabad ',
#   'candidate_name': 'NARESH',
#   'sex': 'M',
#   'age': '37',
#   'category': 'ST',
#   'partyname': 'INC',
#   'partysymbol': 'Hand',
#   'general': '257994',
#   'postal': '1563',
#   'total': '259557',
#   'pct_of_total_votes': '18.72324679',
#   'pct_of_polled_votes': '24.59020587',
#   'totalvoters': '1386282'}]
# ```

# In[ ]:


list_elec_results_dicts[:2]

