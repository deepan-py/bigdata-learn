#!/usr/bin/env python
# coding: utf-8

# ## Create Missing Directories using os
# 
# Develop a function create missing directory structure. This is primarily to assess the understanding of managing directories using Python **os** module.
# * Here are the details about the data being sent.
#   * The source system will send activity data on regular basis.
#   * As we get the data, we need to see if the folders are created or not based on year, month and day.
#   * If the folder structure does not exists, it should be created.
# * Use your home directory as base folder.
# * Here is the base location: `/home/${USER}/output/activity/`
# * The function should take year, month and day as arguments and then create directory structure `/home/${USER}/output/activity/year=yyyy/month=MM/day=dd`.
#   * `yyyy` - 4 digit year
#   * `MM` - 2 digit month
#   * `dd` - 2 digit day
# * If the directory structure already exists, you can just ignore.

# In[ ]:


# Your code should go here
import os
def create_activity_dirs_os(base_dir, year, month, day):
    # Code to create directories should go here
    return


# * Run below cells to validate. Year, month and day should be passed as integers.

# In[ ]:


import getpass
username = getpass.getuser()
base_dir = f'/home/{username}/output/activity'


# In[ ]:


create_activity_dirs_os(base_dir, 2021, 2, 9)


# In[ ]:


get_ipython().system('find /home/${USER}/output/activity')


# * Here is the expected output.
# ```shell
# /home/itversity/output/activity/year=2021
# /home/itversity/output/activity/year=2021/month=02
# /home/itversity/output/activity/year=2021/month=02/day=09
# ```

# In[ ]:




