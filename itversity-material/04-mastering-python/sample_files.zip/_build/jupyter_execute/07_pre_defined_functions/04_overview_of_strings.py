#!/usr/bin/env python
# coding: utf-8

# ## Overview of Strings
# Let us get an overview of how strings are used in Python.

# In[1]:


get_ipython().run_cell_magic('HTML', '', '<iframe width="560" height="315" src="https://www.youtube.com/embed/eo7bI-ZXefI?rel=0&amp;controls=1&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>')


# * `str` is the class or type to represent a string.
# * A string is nothing but list of characters.
# * Python provides robust set of functions as part of `str` to manipulate strings.
# * As `str` object is nothing but list of characters, we can also use standard functions available on top of Python collections such as `list`, `set` etc.
# 
# ```{note}
# We have covered lists quite extensively in subsequent sections. Once you go through the lists, perform some of the operations on top of strings. Here are few examples.
# ```

# In[1]:


s = 'Hello World'


# In[2]:


type(s)


# In[3]:


print(s)


# In[4]:


s[:5]


# In[5]:


s[-5:]


# In[6]:


len(s)


# In[7]:


sorted(s)


# * String in Python can be represented in different ways
#   * Enclosed in single quotes - `'ITVersity"s World'`
#   * Enclosed in double quotes - `"ITVersity's World"`
#   * Enclosed in triple single quotes - `'''ITVersity"s World'''`
#   * Enclosed in triple double quotes - `"""ITVersity's World"""`
# * If your string itself have single quote, enclose the whole string in double quote.
# * If your string itself have double quote, enclose the whole string in single quote.
# * Triple single quotes or triple double quotes can be used for multi line strings

# In[8]:


s = 'Hello World'
s


# In[9]:


s = "Hello World"
s


# In[10]:


s = 'ITVersity"s World'
s


# In[11]:


s = "ITVersity's World"
s


# In[12]:


s = '''ITVersity's World'''
s


# In[13]:


s = '''ITVersity's 
World'''
s


# In[ ]:




