#!/usr/bin/env python
# coding: utf-8

# ## Special Functions
# 
# Python provides several special functions to get the metadata of the programs that are being executed.

# * `__name__` - to get the name of the program
# * All operators are typically nothing but functions. We have already seen `operator` which contain the functions.
# * All the standard classes have special functions called as `__str__` and `__repr__` to provide string representation.
# * As we explore collection is future, we will observe special functions for operators such as `in`, `not in`, `len` etc.
# * We can also use functions (constructors) such as `int`, `float`, `str` etc to convert the data types.

# In[1]:


print(__name__)


# In[2]:


import operator


# In[3]:


get_ipython().run_line_magic('pinfo', 'operator.add')


# In[4]:


get_ipython().run_line_magic('pinfo', 'int.__str__')


# In[5]:


get_ipython().run_line_magic('pinfo', 'int.__repr__')


# In[6]:


user =  '1,123 456 789,Scott,Tiger,1989-08-15,+1 415 891 9002,Forrest City,Texas,75063'


# In[7]:


user.split(',')[0]
# Even though user_id is integer, it will be treated as string
# split converts a string to list of strings


# In[8]:


type(user.split(',')[0])


# In[9]:


# We can use int to convert the data type of user_id
user_id = int(user.split(',')[0])
user_id


# In[10]:


type(user_id)


# In[11]:


get_ipython().run_line_magic('pinfo', 'int.__repr__')


# In[12]:


user =  '1,123 456 789,Scott,Tiger,1989-08-15,+1 415 891 9002,Forrest City,Texas,75063'


# In[13]:


user.split(',')[0]
# Even though user_id is integer, it will be treated as string
# split converts a string to list of strings


# In[14]:


type(user.split(',')[0])


# In[15]:


# We can use int to convert the data type of user_id
user_id = int(user.split(',')[0])
user_id


# In[16]:


type(user_id)

