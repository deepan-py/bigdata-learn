#!/usr/bin/env python
# coding: utf-8

# ## Date Manipulation Functions
# 
# As part of our application, we often need to deal with dates. Let us get an overview about dealing with dates in Python.

# In[1]:


get_ipython().run_cell_magic('HTML', '', '<iframe width="560" height="315" src="https://www.youtube.com/embed/A-c__y5RkDo?rel=0&amp;controls=1&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>')


# * `datetime` is the main library to deal with dates.
# * `datetime.datetime` and `datetime.date` are the classes as part of `datetime` library that can be used to deal with dates.
# * `datetime.datetime` is primarily used for date with timestamp and `datetime.date` can be used for date with out timestamp.
# * When we try to print the date it will print as below (for datetime). It is due to the implementation of string representation functions such as `__str__` or `__repr__`.
# ```
# datetime.datetime(2020, 10, 7, 21, 9, 1, 39414)
# ```
# * We need to format the date using format string to display the date the way we want. These are typically used along with functions such as `strptime` and `strftime`.
#   * `%Y` - 4 digit year
#   * `%m` - 2 digit month
#   * `%d` - 2 digit day with in month
#   * There are quite a few other format strings, but these are the most important ones to begin with.
# * Also, `datetime` library provides functions such as `strptime` to convert strings to date objects.
# * Other important modules to manipulate dates.
#   * `calendar` - to get the calendar related information for dates such as day name, month name etc.
#   * `datetime.timedelta` - to perform date arithmetic

# In[1]:


# Importing datetime
import datetime as dt


# In[2]:


# Getting Current date with timestamp
dt.datetime.now()


# In[3]:


# Getting Current date without timestamp
from datetime import date
date.today()


# In[4]:


# Converting date to a string in the form of yyyy-MM-dd (2020-10-07)
date.today().strftime('%Y-%m-%d')


# In[5]:


# Converting date to a string in the form of dd-MM-yyyy (07-10-2020)
date.today().strftime('%d-%m-%Y')


# In[6]:


# Converting date to a string in the form of yyyy/MM/dd (2020/10/07)
date.today().strftime('%Y/%m/%d')


# In[7]:


# Converting date to an integer in the form of yyyyMMdd (20201007)
int(date.today().strftime('%Y%m%d'))


# In[8]:


# Converting time to a string in the form of yyyy-MM-dd HH:mm:SS (2020-10-08 19:25:31)
dt.datetime.now().strftime('%Y-%m-%d %H:%M:%S')


# In[9]:


# Converting date to a string in the form yyyyMMdd (20201007)
# We can represent this date as integer and hence we can convert the data type
int(date.today().strftime('%Y%m%d'))


# In[10]:


# Converting string which contains date using format yyyy-MM-dd as date
dt.datetime.strptime('2020-10-07', '%Y-%m-%d')


# In[11]:


dt.datetime.strptime('2020-10-07', '%Y-%m-%d').date()


# In[12]:


# Converting number which contains date using format yyyyMMdd as date
# strptime expects first argument to be string which contain date
# so we need to convert datatype of number to string
dt.datetime.strptime(20201007, '%Y%m%d')


# In[13]:


# Converting number which contains date using format yyyyMMdd as date
# strptime expects first argument to be string which contain date
# so we need to convert datatype of number to string
dt.datetime.strptime(str(20201007), '%Y%m%d')


# In[14]:


# Converting string which contains timestamp using format yyyy-MM-dd HH:mm:ss as date
dt.datetime.strptime('2020-10-07 21:09:10', '%Y-%m-%d %H:%M:%S')


# In[15]:


import calendar, datetime as dt


# In[16]:


d = dt.date.today()


# In[17]:


d


# In[18]:


list(calendar.day_name)


# In[19]:


get_ipython().run_line_magic('pinfo', 'calendar.weekday')


# In[20]:


type(d)


# In[21]:


d.year


# In[22]:


d.month


# In[23]:


d.day


# In[24]:


calendar.weekday(d.year, d.month, d.day)


# In[25]:


calendar.day_name[calendar.weekday(d.year, d.month, d.day)]


# In[ ]:




