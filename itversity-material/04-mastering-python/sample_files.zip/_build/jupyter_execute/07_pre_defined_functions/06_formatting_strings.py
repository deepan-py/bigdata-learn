#!/usr/bin/env python
# coding: utf-8

# ## Formatting Strings
# 
# Let us understand how we can replace placeholders in Python using different variations of formatting strings.

# In[1]:


get_ipython().run_cell_magic('HTML', '', '<iframe width="560" height="315" src="https://www.youtube.com/embed/xDk6XkFXC5Y?rel=0&amp;controls=1&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>')


# * While we can concatenate strings, it will by default fail when we try to concatenate string with non string.
# * Conventionally we tend to use `str` to convert the data type of the non-string values that are being concatenated to string.
# * From Python 3, they have introduced placeholders using `{}` with in a string.
# * We can replace the placeholders either by name or by position.
# 
# Using placeholders will improve the readability of the code and it is highly recommended.

# In[1]:


print('Hello World')


# In[2]:


print('Hello' + ' ' + 'World')


# In[3]:


# This will fail as we are trying to concatenate 0 to a string
print('Hello' + 0 + 'World')


# In[4]:


print('Hello' + str(0) + 'World')


# In[5]:


i = 0
print('Hello' + str(i) + 'World')


# In[6]:


# Replacing placeholders by name
i = 0
print(f'Hello{i}World')


# In[7]:


# Replacing placeholders by name
print('Hello{i}World'.format(i=0))


# In[8]:


# Replacing placeholders by position
print('Hello{}World'.format(0))


# In[9]:


# Replacing placeholders by position
print('Hello{}World{}'.format(0, 1))


# In[10]:


# These are the approaches which are commonly used
i = 0
s1 = f'str1: Hello{i}World'
print(s1)
s2 = 'str2: Hello{j}World'.format(j=i)
print(s2)

