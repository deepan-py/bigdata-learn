#!/usr/bin/env python
# coding: utf-8

# ## Overview of Pre-defined Functions
# 
# Let us get an overview of Pre-defined Functions using Python. We will go through the details related to string manipulation, date manipulation, numeric functions etc.

# In[1]:


get_ipython().run_cell_magic('HTML', '', '<iframe width="560" height="315" src="https://www.youtube.com/embed/lhDnn_3VhVI?rel=0&amp;controls=1&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>')


# * All the programming languages have robust pre-defined functions.
# * Pre-defined function means the function which is available out of the box.
# * We can leverage these functions to add key functionalities required as part of our application.
# * As part of our applications, typically we read the data from databases or files. Also data is typically passed as part of requests (REST APIs)
# * Once data is read from databases or files, we process the data. This is where the pre-defined functions comes handy.
# * After data is processed, either we save the data back to database or files or provide responses to requests such as REST API requests.
# * Even though there are thousands of pre-defined functions as part of Python as well as Python based libraries, let us explore most common ones to begin with.
#   * Numeric Functions
#   * String Manipulation Functions
#   * Date Manipulation Functions
# * Here are the examples of users data that is read from files
#   * CSV (Text File) - '1,123 456 789,Scott,Tiger,1989-08-15,+1 415 891 9002,Forrest City,Texas,75063'
#   * JSON - {"id": 1, "uniq_id": "123 456 789", "first_name": "Scott", "last_name": "Tiger", "dob": "1989-08-15", "contact_no": "+1 415 891 9002", "city": "Forrest City", "state": "Texas", "zip": 75063}
# * We also use JSON as part of REST API requests and responses.
# * We will use above data to explore the functions that are available as part of Python.

# In[ ]:




