#!/usr/bin/env python
# coding: utf-8

# # Pre-defined Functions
# 
# Let us go through the list of commonly used Pre-defined Functions.
# * Overview of Pre-defined Functions
# * Numeric Functions
# * Overview of Strings
# * String Manipulation Functions
# * Formatting Strings
# * Print and Input Functions
# * Date Manipulation Functions
# * Special Functions
