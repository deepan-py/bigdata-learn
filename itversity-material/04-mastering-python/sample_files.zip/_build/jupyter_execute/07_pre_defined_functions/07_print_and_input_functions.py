#!/usr/bin/env python
# coding: utf-8

# ## Print and Input Functions
# 
# Let us understand details related to `print` and `input` functions. These functions will help us in enhancing our learning experience.

# In[1]:


get_ipython().run_cell_magic('HTML', '', '<iframe width="560" height="315" src="https://www.youtube.com/embed/0e-J9hqFQ04?rel=0&amp;controls=1&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>')


# * `print` is primarily used to print the strings on the console while `input` is used to accept the input from console.
# * `input` will typically prompts the user to enter the value and we can assign to a variable and use it further.
# * By default, the value passed for `input` is of type `str` and hence we need to convert the data type of the values entered before processing.

# In[1]:


get_ipython().run_line_magic('pinfo', 'input')


# In[2]:


a = int(input('Enter first value: '))
b = int(input('Enter second value: '))
print(f'Sum of first value {a} and second value {b} is {a + b}')


# * When we use `print` with one string, by default it will have new line character at the end of the srring.
# * We can also pass multiple strings **(varrying arguments)** and space will be used as delimiter
# * We can change the end of the string character, by passing argument
# * `print` can accept 2 keyword arguments `sep` and `end` to support the above mentioned features.
# 
# You will understand more about keyword arguments and varrying arguments in **User Defined Functions**.

# In[ ]:


get_ipython().run_line_magic('pinfo', 'print')


# In[3]:


# Default print by using one string as argument
print('Hello')
print('World')


# In[4]:


# Default print by using multiple arguments. Each argument is of type string
print('Hello', 'World')


# In[5]:


# Changing end of line character - empty string
print('Hello', end='')
print('World')


# In[6]:


# Changing separater to empty string
print('Hello', 'World', sep='')


# In[7]:


print('Hello', 'World', sep=', ', end=' - ')
print('How', 'are', 'you?')


# In[ ]:




