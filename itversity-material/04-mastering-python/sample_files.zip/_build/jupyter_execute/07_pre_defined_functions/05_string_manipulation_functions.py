#!/usr/bin/env python
# coding: utf-8

# ## String Manipulation Functions
# 
# Let us go through some of the important string manipulation functions using Python as programming language.

# In[1]:


get_ipython().run_cell_magic('HTML', '', '<iframe width="560" height="315" src="https://www.youtube.com/embed/dPsVVYZyUlM?rel=0&amp;controls=1&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>')


# * Splitting Strings
# * Converting Case
# * Concatenating Strings
# * Getting Sub String
# * Data Type Conversion
# 
# Let's use below string to explore string manipulation functions.
# 
# ```
# '1,123 456 789,Scott,Tiger,1989-08-15,+1 415 891 9002,Forrest City,Texas,75063'
# ```

# In[2]:


user = '1,123 456 789,Scott,Tiger,1989-08-15,+1 415 891 9002,Forrest City,Texas,75063'


# In[3]:


type(user)


# In[4]:


get_ipython().run_line_magic('pinfo', 'user.split')


# In[5]:


user.split()


# In[6]:


# Splitting String
user.split(',')


# In[ ]:


# Once data is splitted, we can access elements in the result using index
first_name = user.split(',')[2]
first_name


# In[ ]:


# Once data is splitted, we can access elements in the result using index
last_name = user.split(',')[3]
last_name


# In[ ]:


# Converting to upper case
first_name.upper()


# In[ ]:


# Converting to lower case
first_name.lower()


# In[ ]:


# Concatenate strings and capitalize
full_name = (first_name + ' ' + last_name).capitalize()
full_name


# In[ ]:


# Getting year part of the date (substring)
dob = user.split(',')[4]
dob


# In[ ]:


dob[0:4]


# In[ ]:


dob[:4]


# In[ ]:


# Getting day part
dob[-2:]


# In[ ]:


# Convert year part to integer
int(dob[0:4])


# In[ ]:


# Convert date to date type
import datetime
datetime.datetime.strptime(user.split(',')[4], '%Y-%m-%d')


# In[ ]:


d = datetime.datetime.strptime(user.split(',')[4], '%Y-%m-%d')


# In[ ]:


type(d)


# In[ ]:


help(str)


# In[ ]:




