#!/usr/bin/env python
# coding: utf-8

# ## Process JSON String
# 
# Let us understand how to process JSON strings using Python as programming language. Later we will see different ways of storing JSON data in files.
# 
# We will see following examples of processing JSON strings.
# * Single JSON document.
# * Multiple JSON documents, with one JSON per line.
# * Multiple JSON documents as an Array under one attribute. Most of the REST APIs which return multiple elements follow this approach.
# * We can process JSON Strings either by using `json` module or `pandas`.
# * As part of developing backend for web or mobile applications we use `json` or some high level wrappers. For bulk data processing typically we fall back on modules such as `pandas`.
# * You should be familiar with both. For now, we will focus on `json`.
# * We should first import `json` module to process the JSON strings using it.
# * We have a function called as `loads` which takes a JSON in string and returns `dict`.

# ### Single JSON document
# 
# Let us go through the details of processing Single JSON document. 
# * Import `json` module.
# * Create JSON String.
# * Pass the string to `json.loads`. It will return `dict`.
# * Assign it to a variable and use it further.

# In[ ]:


import json


# In[ ]:


person = '{"id":1,"first_name":"Frasco","last_name":"Necolds","email":"fnecolds0@vk.com","gender":"Male","ip_address":"243.67.63.34"}'


# In[ ]:


type(person)


# In[ ]:


get_ipython().run_line_magic('pinfo', 'json.loads')


# In[ ]:


person_dict = json.loads(person)


# In[ ]:


type(person_dict)


# In[ ]:


print(person_dict)


# In[ ]:


person_dict['id']


# In[ ]:


person_dict['first_name']


# In[ ]:


person_dict.keys()


# In[ ]:


person_dict.items()


# * Here is an example of a single JSON as string that is part of multiple lines.

# In[ ]:


import json


# In[ ]:


person = '''{
    "id":1,
    "first_name":"Frasco",
    "last_name":"Necolds",
    "email":"fnecolds0@vk.com",
    "gender":"Male",
    "ip_address":"243.67.63.34"
}'''


# In[ ]:


type(person)


# In[ ]:


person_dict = json.loads(person)


# In[ ]:


type(person_dict)


# In[ ]:


print(person_dict)


# ### Multiple JSON Documents - One per line
# 
# Let us go through the steps involved in processing a string which contain one JSON per line.
# * We should convert the string into list of JSON strings and then use `json.loads` to process each JSON.
# * Import `json` module.
# * Split the string into multiple strings using new line character (`\n`) as delimiter. String have a function called as `splitlines` and we should be able to leverage it.
# * Use `for` loop or `map` function to convert list of JSON Strings into list of dicts. We should use `json.loads` to convert each JSON String as dict.

# In[ ]:


persons = '''{"id":1,"first_name":"Frasco","last_name":"Necolds","email":"fnecolds0@vk.com","gender":"Male","ip_address":"243.67.63.34"}
{"id":2,"first_name":"Dulce","last_name":"Santos","email":"dsantos1@mashable.com","gender":"Female","ip_address":"60.30.246.227"}
{"id":3,"first_name":"Prissie","last_name":"Tebbett","email":"ptebbett2@infoseek.co.jp","gender":"Genderfluid","ip_address":"22.21.162.56"}
{"id":4,"first_name":"Schuyler","last_name":"Coppledike","email":"scoppledike3@gnu.org","gender":"Agender","ip_address":"120.35.186.161"}
{"id":5,"first_name":"Leopold","last_name":"Jarred","email":"ljarred4@wp.com","gender":"Agender","ip_address":"30.119.34.4"}
{"id":6,"first_name":"Joanna","last_name":"Teager","email":"jteager5@apache.org","gender":"Bigender","ip_address":"245.221.176.34"}
{"id":7,"first_name":"Lion","last_name":"Beere","email":"lbeere6@bloomberg.com","gender":"Polygender","ip_address":"105.54.139.46"}
{"id":8,"first_name":"Marabel","last_name":"Wornum","email":"mwornum7@posterous.com","gender":"Polygender","ip_address":"247.229.14.25"}
{"id":9,"first_name":"Helenka","last_name":"Mullender","email":"hmullender8@cloudflare.com","gender":"Non-binary","ip_address":"133.216.118.88"}
{"id":10,"first_name":"Christine","last_name":"Swane","email":"cswane9@shop-pro.jp","gender":"Polygender","ip_address":"86.16.210.164"}'''


# In[ ]:


type(persons)


# In[ ]:


get_ipython().run_line_magic('pinfo', 'persons.splitlines')


# In[ ]:


# Using for loop
import json


# In[ ]:


persons_list = persons.splitlines()


# In[ ]:


type(persons_list)


# In[ ]:


type(persons_list[0])


# In[ ]:


persons_list[1]


# In[ ]:


json.loads(persons_list[0])


# In[ ]:


persons_dict_list = []

for person in persons_list:
    persons_dict_list.append(json.loads(person))


# In[ ]:


type(persons_dict_list)


# In[ ]:


type(persons_dict_list[0])


# In[ ]:


persons_dict_list[0]['first_name']


# In[ ]:


persons_dict_list = [json.loads(person) for person in persons_list]


# In[ ]:


persons_dict_list = list(map(json.loads, persons_list))


# In[ ]:


list(map(lambda person: person['first_name'], persons_dict_list))


# In[ ]:


list(filter(lambda person: person['gender'] == 'Female', persons_dict_list))


# ### Multiple JSON Documents - Array
# 
# Let us go through the details of processing multiple JSON Documents as an array.
# * We should be able to use `json.loads`. For the below string it will return Python list.
# * Steps are same as processing single JSON document.
#   * Import `json` module.
#   * Use `json.loads` to convert to Python list.
#   * Process using Python capabilities.

# In[ ]:


persons = '''[{"id":1,"first_name":"Frasco","last_name":"Necolds","email":"fnecolds0@vk.com","gender":"Male","ip_address":"243.67.63.34"},
{"id":2,"first_name":"Dulce","last_name":"Santos","email":"dsantos1@mashable.com","gender":"Female","ip_address":"60.30.246.227"},
{"id":3,"first_name":"Prissie","last_name":"Tebbett","email":"ptebbett2@infoseek.co.jp","gender":"Genderfluid","ip_address":"22.21.162.56"},
{"id":4,"first_name":"Schuyler","last_name":"Coppledike","email":"scoppledike3@gnu.org","gender":"Agender","ip_address":"120.35.186.161"},
{"id":5,"first_name":"Leopold","last_name":"Jarred","email":"ljarred4@wp.com","gender":"Agender","ip_address":"30.119.34.4"},
{"id":6,"first_name":"Joanna","last_name":"Teager","email":"jteager5@apache.org","gender":"Bigender","ip_address":"245.221.176.34"},
{"id":7,"first_name":"Lion","last_name":"Beere","email":"lbeere6@bloomberg.com","gender":"Polygender","ip_address":"105.54.139.46"},
{"id":8,"first_name":"Marabel","last_name":"Wornum","email":"mwornum7@posterous.com","gender":"Polygender","ip_address":"247.229.14.25"},
{"id":9,"first_name":"Helenka","last_name":"Mullender","email":"hmullender8@cloudflare.com","gender":"Non-binary","ip_address":"133.216.118.88"},
{"id":10,"first_name":"Christine","last_name":"Swane","email":"cswane9@shop-pro.jp","gender":"Polygender","ip_address":"86.16.210.164"}]'''


# In[ ]:


persons_dict_list = json.loads(persons)


# In[ ]:


type(persons_dict_list)


# In[ ]:


type(persons_dict_list[0])


# In[ ]:


persons_dict_list[0]


# * When we use `json.loads` on below string, it will create a dict where value will be a list.

# In[ ]:


persons = '''{
    "results": [
        {
            "id": 1,
            "first_name": "Frasco",
            "last_name": "Necolds",
            "email": "fnecolds0@vk.com",
            "gender": "Male",
            "ip_address": "243.67.63.34"
        },
        {
            "id": 2,
            "first_name": "Dulce",
            "last_name": "Santos",
            "email": "dsantos1@mashable.com",
            "gender": "Female",
            "ip_address": "60.30.246.227"
        },
        {
            "id": 3,
            "first_name": "Prissie",
            "last_name": "Tebbett",
            "email": "ptebbett2@infoseek.co.jp",
            "gender": "Genderfluid",
            "ip_address": "22.21.162.56"
        },
        {
            "id": 4,
            "first_name": "Schuyler",
            "last_name": "Coppledike",
            "email": "scoppledike3@gnu.org",
            "gender": "Agender",
            "ip_address": "120.35.186.161"
        },
        {
            "id": 5,
            "first_name": "Leopold",
            "last_name": "Jarred",
            "email": "ljarred4@wp.com",
            "gender": "Agender",
            "ip_address": "30.119.34.4"
        },
        {
            "id": 6,
            "first_name": "Joanna",
            "last_name": "Teager",
            "email": "jteager5@apache.org",
            "gender": "Bigender",
            "ip_address": "245.221.176.34"
        },
        {
            "id": 7,
            "first_name": "Lion",
            "last_name": "Beere",
            "email": "lbeere6@bloomberg.com",
            "gender": "Polygender",
            "ip_address": "105.54.139.46"
        },
        {
            "id": 8,
            "first_name": "Marabel",
            "last_name": "Wornum",
            "email": "mwornum7@posterous.com",
            "gender": "Polygender",
            "ip_address": "247.229.14.25"
        },
        {
            "id": 9,
            "first_name": "Helenka",
            "last_name": "Mullender",
            "email": "hmullender8@cloudflare.com",
            "gender": "Non-binary",
            "ip_address": "133.216.118.88"
        },
        {
            "id": 10,
            "first_name": "Christine",
            "last_name": "Swane",
            "email": "cswane9@shop-pro.jp",
            "gender": "Polygender",
            "ip_address": "86.16.210.164"
        }
    ]
}'''


# In[ ]:


import json


# In[ ]:


person_results = json.loads(persons)


# In[ ]:


type(person_results)


# In[ ]:


person_results.keys()


# In[ ]:


type(person_results['results'])


# In[ ]:


type(person_results['results'][0])


# In[ ]:


person_results['results'][0]


# In[ ]:


results = person_results['results']


# In[ ]:


type(results)


# In[ ]:


results[0]


# ### Exercise on processing collections
# 
# Take person_results and get list of dicts where each dict contain id, first_name and email. We would like to send an offer for all the persons in the form of email.
# * You should use `map` function for the same.
# * Do not use loops.

# In[ ]:




