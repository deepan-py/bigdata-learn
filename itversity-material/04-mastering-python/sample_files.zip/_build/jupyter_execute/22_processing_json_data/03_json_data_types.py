#!/usr/bin/env python
# coding: utf-8

# ## JSON Data Types
# 
# Let us understand the data types that are used while representing objects in the form of JSON.
# 
# Here are the basic data types of JSON.
# * Number
# * String
# * Boolean
# * Array (Similar to Python list)
# * Object (Nested JSON)
# * null (empty value)
# 
# Here is an example for JSON representation of a Person object.
# 
# ```json
# {
#   "firstName": "John",
#   "lastName": "Smith",
#   "isAlive": true,
#   "age": 27,
#   "address": {
#     "streetAddress": "21 2nd Street",
#     "city": "New York",
#     "state": "NY",
#     "postalCode": "10021-3100"
#   },
#   "phoneNumbers": [
#     {
#       "type": "home",
#       "number": "212 555-1234"
#     },
#     {
#       "type": "office",
#       "number": "646 555-4567"
#     }
#   ],
#   "children": [],
#   "spouse": null
# }
# ```
# 
# Here are the details of data types of values in the above JSON.
# * **age** is of type **Number**.
# * **isAlive** is of type **Boolean**.
# * **spouse** is of type **null**.
# * **address** is of type **Object**.
# * **children** is of type **Array**. In the example above, children array is empty.
# * **phoneNumbers** is of type **Array of Objects**.

# In[ ]:




