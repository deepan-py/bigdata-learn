#!/usr/bin/env python
# coding: utf-8

# ## Process JSON using Pandas
# 
# Let us understand how to process JSON using Pandas.
# * We can use `read_json` to read JSON documents from file into a Data Frame.
# * It works well with **customers.json** where we have one valid JSON document per line.

# In[ ]:


import pandas as pd


# In[ ]:


get_ipython().run_line_magic('pinfo', 'pd.read_json')


# In[ ]:


pd.read_json('customers.json', lines=True)


# * It is not straight forward to create data frame using **youtube_playlist_items.json** where we have one single JSON document with multiple attributes.
# * We can extract **items** and create data frame using `pd.DataFrame` by passing the list of dicts to it.

# In[ ]:


import json


# In[ ]:


type(open('youtube_playlist_items.json'))


# In[ ]:


json.load(open('youtube_playlist_items.json'))['items'][0]


# In[ ]:


yt_items = json.load(open('youtube_playlist_items.json'))['items']


# In[ ]:


pd.DataFrame(yt_items)


# In[ ]:


pd.json_normalize(json.load(open('youtube_playlist_items.json'))['items']) # nested jsons are flattened


# * Other standard formats supported by Pandas.
# * We can use `to_json` to display the output from buffer. We can also write to files using `to_json`.
# * Here are examples with different supported JSON formats.

# In[ ]:


df = pd.read_json('customers.json', lines=True)


# In[ ]:


df


# In[ ]:


df.to_json(orient='split') # columns, index and data are separated


# In[ ]:


pd.read_json(_, orient='split') # Creating data frame by using data from buffer


# In[ ]:


df.to_json(orient='records') # array of json documents


# In[ ]:


pd.read_json(_) # the default for orient is None which is similar to records


# In[ ]:


df.to_json(orient='records', lines=True) # Multiple jsons with one json per line


# In[ ]:


pd.read_json(_, lines=True) # the default for orient is records


# In[ ]:




