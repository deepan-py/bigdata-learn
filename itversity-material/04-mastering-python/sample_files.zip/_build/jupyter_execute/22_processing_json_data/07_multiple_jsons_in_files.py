#!/usr/bin/env python
# coding: utf-8

# ## Multiple jsons in files
# 
# At times we might have multiple JSON documents in a text file. Typically, we will have one valid JSON per line. Let us understand the process of reading a file where there are multiple JSON documents one per line.
# * If you use `pandas`, it is straight forward. However, we will talk about using `pandas` later.
# * We cannot use `json` module directly. Here are the steps to use JSON module.
#   * Create file type object by passing the path to `open`.
#   * Use `read` to read the content in the file into a string.
#   * Once string object is created, we can use `splitlines` to convert these lines into list of strings. Here each element is of type string which contain json.
#   * Now we can iterate through the elements and convert each string with JSON to dict using `json.loads`.

# In[ ]:


import json


# In[ ]:


get_ipython().run_line_magic('pinfo', 'json.load')


# In[ ]:


json.load(open('customers.json'))


# * Create file type object by passing the path to `open`.

# In[ ]:


type(open('customers.json'))


# * Use `read` to read the content in the file into a string.

# In[ ]:


type(open('customers.json').read())


# In[ ]:


open('customers.json').read()


# * Once string object is created, we can use `splitlines` to convert these lines into list of strings. Here each element is of type string which contain json.

# In[ ]:


customers_str_list = open('customers.json').read().splitlines()


# In[ ]:


type(customers_str_list)


# * Each element in the list is of type string.

# In[ ]:


type(customers_str_list[0])


# In[ ]:


len(customers_str_list)


# In[ ]:


customers_str_list[0]


# In[ ]:


customers_str_list[:3]


# * Now we can iterate through the elements and convert each string with JSON to dict using `json.loads`.

# In[ ]:


customers_dict_list = [json.loads(customer) for customer in customers_str_list]


# In[ ]:


type(customers_dict_list)


# In[ ]:


type(customers_dict_list[0])


# In[ ]:


customers_dict_list[0]


# * Here is the logic to convert list of strings to list of dicts using `map` function.

# In[ ]:


customers_dict_list = list(map(json.loads, customers_str_list))


# In[ ]:


type(customers_dict_list)


# In[ ]:


type(customers_dict_list[0])


# In[ ]:


customers_dict_list[0]


# In[ ]:




