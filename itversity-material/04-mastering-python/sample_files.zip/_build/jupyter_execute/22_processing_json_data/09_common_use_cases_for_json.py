#!/usr/bin/env python
# coding: utf-8

# ## Common Use Cases for JSON
# 
# Here are some of the common use cases for JSON.
# * Read data from JSON files.
# * Write data to JSON files.
# * We can use either `json` or `pandas` modules to read data from JSON files or write data to JSON files. One need to be familiar with both the approaches as each of them have different use cases and capabilities.
# * Read JSON based response payloads on REST API Calls. We use `requests` module to process the REST API response Payloads.
# * Once the payload is returned, we can use appropriate modules to process the data further.

# ### Read Data from JSON files
# 
# Here are the steps involved in reading data from JSON files.
# * Using `json` module
#   * Create file object using `open` in read only mode.
#   * Pass the the `file` object to `json.load`.
#   * `json.load` will return `dict`. We can process the data further using appropriate modules.
# * Using `pandas` module
#   * Use the path for the file to invoke `read_json`.
#   * A Pandas Data Frame will be created.
#   * We can process data further using rich APIs available in `pandas` module.

# In[ ]:


# Using json module
import json

yt_file = open('youtube_playlist_items.json')
yt_items = json.load(yt_file)

type(yt_items)


# In[ ]:


yt_items.keys()


# In[ ]:


yt_items['items']


# In[ ]:


# Further data processing (get video id and published time)
list(map(lambda rec: rec['contentDetails'], yt_items['items']))


# In[ ]:


# Using Pandas Module
# As youtube items are part of nested json, we need to use both json and pandas

import json
import pandas as pd

yt_file = open('youtube_playlist_items.json')
yt_items = json.load(yt_file)


# In[ ]:


yt_items.keys()


# In[ ]:


yt_items


# In[ ]:


get_ipython().run_line_magic('pinfo', 'pd.json_normalize')


# In[ ]:


yt_df = pd.json_normalize(yt_items, 'items')


# In[ ]:


yt_df


# In[ ]:


yt_df[['contentDetails.videoId', 'contentDetails.videoPublishedAt']]


# In[ ]:


# Using json to process customers data
# We have one customer per line
# We need to read the data as string then use json.loads to convert each string to dict.

import json

customers_file = open('customers.json')
customers_list = customers_file.read().splitlines()

# Converting the records in the file into list of dicts
# We are processing each element in customers_list
customers = list(map(json.loads, customers_list))


# In[ ]:


customers


# In[ ]:


# Using Pandas only to process customers data
# For customers where we have one json per line, we can use Pandas directly

import pandas as pd

customers = pd.read_json('customers.json', lines=True)


# In[ ]:


customers


# ### Write Data to JSON files
# 
# Here are the steps involved in writing data to JSON files.
# * Using `json` module
#   * Make sure the `dict` object is ready with processed data as per requirements before writing to the file.
#   * Create file object using `open` in write mode.
#   * Pass the the `file` object to `json.dump`.
#   * The `dict` will be dumped in the form of JSON in the file.
# * Using `pandas` module
#   * Make sure the Data Frame is ready with processed data as per requirements before writing to the file.
#   * Use the path for the file to invoke `write_json`. It can be invoked using Data Frame object which have the processed data.
#   * The Pandas Data Frame will be written in the form of JSON in the file.
#   * We can leverage additional keyword arguments to control the behavior. For example `orient=records` can be used to write the data frame in the form one JSON document per line.
