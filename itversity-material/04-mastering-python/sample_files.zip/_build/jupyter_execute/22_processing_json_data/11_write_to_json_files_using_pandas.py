#!/usr/bin/env python
# coding: utf-8

# ## Write to JSON files using pandas
# 
# Let us understand how to write to JSON files using `pandas` module.
# * We can use `to_json` to write to JSON file using `pandas`.

# In[1]:


import pandas as pd


# In[2]:


courses = [{'course_name': 'Programming using Python',
  'course_author': 'Bob Dillon',
  'course_status': 'published',
  'course_published_dt': '2020-09-30'},
 {'course_name': 'Data Engineering using Python',
  'course_author': 'Bob Dillon',
  'course_status': 'published',
  'course_published_dt': '2020-07-15'}]


# In[3]:


df = pd.DataFrame(courses)


# In[ ]:


get_ipython().run_line_magic('pinfo', 'df.to_json')


# * Dumping a JSON documents into a file with one JSON document per line.

# In[5]:


courses = [{'course_name': 'Programming using Python',
  'course_author': 'Bob Dillon',
  'course_status': 'published',
  'course_published_dt': '2020-09-30'},
 {'course_name': 'Data Engineering using Python',
  'course_author': 'Bob Dillon',
  'course_status': 'published',
  'course_published_dt': '2020-07-15'},
 {'course_name': 'Data Engineering using Scala',
  'course_author': 'Elvis Presley',
  'course_status': 'draft',
  'course_published_dt': None},
 {'course_name': 'Programming using Scala',
  'course_author': 'Elvis Presley',
  'course_status': 'published',
  'course_published_dt': '2020-05-12'},
 {'course_name': 'Programming using Java',
  'course_author': 'Mike Jack',
  'course_status': 'inactive',
  'course_published_dt': '2020-08-10'},
 {'course_name': 'Web Applications - Python Flask',
  'course_author': 'Bob Dillon',
  'course_status': 'inactive',
  'course_published_dt': '2020-07-20'},
 {'course_name': 'Web Applications - Java Spring',
  'course_author': 'Mike Jack',
  'course_status': 'draft',
  'course_published_dt': None},
 {'course_name': 'Pipeline Orchestration - Python',
  'course_author': 'Bob Dillon',
  'course_status': 'draft',
  'course_published_dt': None},
 {'course_name': 'Streaming Pipelines - Python',
  'course_author': 'Bob Dillon',
  'course_status': 'published',
  'course_published_dt': '2020-10-05'},
 {'course_name': 'Web Applications - Scala Play',
  'course_author': 'Elvis Presley',
  'course_status': 'inactive',
  'course_published_dt': '2020-09-30'},
 {'course_name': 'Web Applications - Python Django',
  'course_author': 'Bob Dillon',
  'course_status': 'published',
  'course_published_dt': '2020-06-23'},
 {'course_name': 'Server Automation - Ansible',
  'course_author': 'Uncle Sam',
  'course_status': 'published',
  'course_published_dt': '2020-07-05'}]


# In[6]:


get_ipython().system('rm courses.json')


# In[7]:


import pandas as pd


# In[8]:


courses_df = pd.DataFrame(courses)


# In[9]:


courses_df


# In[11]:


courses_df.to_json('courses.json', orient='records', lines=True)


# In[12]:


get_ipython().system('ls -ltr courses.json')


# In[13]:


get_ipython().system('cat courses.json')


# * We can also write Pandas dataframe to json file with orient split.

# In[14]:


courses_df.to_json('courses.json', orient='split')


# In[15]:


get_ipython().system('ls -ltr courses.json')


# In[16]:


get_ipython().system('cat courses.json')


# * We can also write Pandas dataframe to json file with orient records. It wil generate string with valid JSON array.

# In[17]:


courses_df.to_json('courses.json', orient='records')


# In[18]:


get_ipython().system('ls -ltr courses.json')


# In[19]:


get_ipython().system('cat courses.json')

