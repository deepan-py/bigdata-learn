#!/usr/bin/env python
# coding: utf-8

# ## Overview of JSON
# 
# Let us get an overview of JSON.
# * JSON stands for JavaScript Object Notation.
# * It is group of Key Value Pairs.
# * Keys are unique and values need not be unique.
# * Both Keys as well as Values can be of any type.
# * Strings should be enclosed in double quotes.
# * Here is an example of a simple JSON.
# 
# ```json
# {"id": 1, "first_name": "Scott", "last_name": "Tiger"}
# ```
# 
# * Here are the characteristics of the above json.
#   * All keys are of type strings.
#   * The value for id is of numeric type.
#   * The values for first_name and last_name are of type strings.
# * Here is an example for complex JSON.
# 
# ```json
# {
#     "id": 1, 
#     "first_name": "Scott", 
#     "last_name": "Tiger",
#     "phone_numbers": ["+1 123 456 7890", "+1 215 801 7000"],
#     "address": {
#         "street": "1234 Special Street",
#         "city": "Round Rock",
#         "state": "Texas"
#     }
# }
# ```
# 
# * Here are the characteristics of the above complex json.
#   * The value for phone_numbers is of type list. All the elements in the list are of type strings. We can also have elements of different types in the list.
#   * The value for address is of type nested JSON (JSON within JSON). All keys and values in the nested JSON are of type strings. As part of nested JSON we can have keys and values of different types.
# 

# In[ ]:




