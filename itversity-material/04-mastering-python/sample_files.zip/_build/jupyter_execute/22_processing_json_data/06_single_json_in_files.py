#!/usr/bin/env python
# coding: utf-8

# ## Single JSON in Files
# 
# Let us understand how to process single JSON in Files. We can leverage `json` or `pandas` modules for the same. For now, we will focus on `json` module.
# * Here are the files used for the demo.
#   * **single_document.json**
#   * **youtube_playlist_items.json** - This is an example for REST API calls which return results in the form of list. The list will be part of one of the attributes in response JSON.
# * Here are the steps you need to follow to review these documents using Jupyter Environment.
#   * Go to the sidebar and select the file.
#   * Right click on the file and click on **Open With -> Editor**
#   * It will open the json file as a plain text file or raw text file.
# * Both the documents have the data in single json.

# Here are the steps to process a file which contain a simple JSON. You need to use `json.load` by passing file object (`_io.TextIOWrapper`).
# * Pass the path of the file and create a File Object.
# * Invoke `json.load` by passing the file object as argument.
# * It will return `dict`.
# * We can leverage dict operations to process the data further.

# In[ ]:


import json


# In[ ]:


type('single_document.json')


# In[ ]:


get_ipython().run_line_magic('pinfo', 'json.load')


# In[ ]:


type(open('single_document.json'))


# In[ ]:


single_json = json.load(open('single_document.json'))


# In[ ]:


single_json


# In[ ]:


type(single_json)


# In[ ]:


single_json.keys()


# In[ ]:


single_json.values()


# In[ ]:


single_json.items()


# In[ ]:


single_json['first_name']


# The file **youtube_playlist_items.json** is an example for YouTube Data API response. It contain complex JSON structure.
# 
# * First let us understand the definition of YouTube Playlist.
#   * A YouTube Playlist is nothing but series of videos.
#   * Playlist also have name, URL as well as description.
#   * Each video will have video id and its attributes.
#   * The result for YouTube Playlist Items contain both Playlist level details as well as the details about videos that are part of the playlist.
#   * The details of videos are made available as part of attribute called as **items**. The value for **items** is of type JSON Array.
# * You can follow the same steps as above to read the JSON in the file **youtube_playlist_items.json** into a dict.
# * However, the dict will be of complex structure. You can see **items** as of type `list`.

# In[ ]:


results_json = json.load(open('youtube_playlist_items.json'))


# In[ ]:


results_json


# In[ ]:


# Reading items. It contain details of videos in the playlist.
results_json['items']


# In[ ]:


results_json['items'][0]['contentDetails']


# In[ ]:


# Here is an example of printing item details.
for playlist_item in results_json['items']:
    print(playlist_item)


# In[ ]:


# Here is an example of gettig only contentDetails for each item.
for playlist_item in results_json['items']:
    print(playlist_item['contentDetails'])


# In[ ]:


# Here is how you can get video ids (using map function)
list(
    map(
        lambda playlist_item: playlist_item['contentDetails']['videoId'],
        results_json['items']
    )
)


# In[ ]:


list(
    map(
        lambda playlist_item: playlist_item['contentDetails'],
        results_json['items']
    )
)


# In[ ]:




