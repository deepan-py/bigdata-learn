#!/usr/bin/env python
# coding: utf-8

# In[ ]:


get_ipython().run_line_magic('run', '02_function_get_database_connection.ipynb')


# In[ ]:


get_ipython().run_line_magic('load_ext', 'sql')


# In[ ]:


get_ipython().run_line_magic('env', 'DATABASE_URL=postgresql://{username}_sms_user:{password}@{postgres_host}:{postgres_port}/{username}_sms_db')


# In[ ]:


get_ipython().run_cell_magic('sql', '', '\nDROP TABLE IF EXISTS courses')


# In[ ]:


get_ipython().run_cell_magic('sql', '', "\nCREATE TABLE courses (\n    course_id SERIAL PRIMARY KEY,\n    course_name VARCHAR(60),\n    course_author VARCHAR(40),\n    course_status VARCHAR(9) CHECK (course_status IN ('published', 'inactive', 'draft')),\n    course_published_dt DATE\n)")


# In[7]:


courses = [{'course_name': 'Programming using Python',
  'course_author': 'Bob Dillon',
  'course_status': 'published',
  'course_publised_dt': '2020-09-30'},
 {'course_name': 'Data Engineering using Python',
  'course_author': 'Bob Dillon',
  'course_status': 'published',
  'course_publised_dt': '2020-07-15'},
 {'course_name': 'Data Engineering using Scala',
  'course_author': 'Elvis Presley',
  'course_status': 'draft',
  'course_publised_dt': None},
 {'course_name': 'Programming using Scala',
  'course_author': 'Elvis Presley',
  'course_status': 'published',
  'course_publised_dt': '2020-05-12'},
 {'course_name': 'Programming using Java',
  'course_author': 'Mike Jack',
  'course_status': 'inactive',
  'course_publised_dt': '2020-08-10'},
 {'course_name': 'Web Applications - Python Flask',
  'course_author': 'Bob Dillon',
  'course_status': 'inactive',
  'course_publised_dt': '2020-07-20'},
 {'course_name': 'Web Applications - Java Spring',
  'course_author': 'Mike Jack',
  'course_status': 'draft',
  'course_publised_dt': None},
 {'course_name': 'Pipeline Orchestration - Python',
  'course_author': 'Bob Dillon',
  'course_status': 'draft',
  'course_publised_dt': None},
 {'course_name': 'Streaming Pipelines - Python',
  'course_author': 'Bob Dillon',
  'course_status': 'published',
  'course_publised_dt': '2020-10-05'},
 {'course_name': 'Web Applications - Scala Play',
  'course_author': 'Elvis Presley',
  'course_status': 'inactive',
  'course_publised_dt': '2020-09-30'},
 {'course_name': 'Web Applications - Python Django',
  'course_author': 'Bob Dillon',
  'course_status': 'published',
  'course_publised_dt': '2020-06-23'},
 {'course_name': 'Server Automation - Ansible',
  'course_author': 'Uncle Sam',
  'course_status': 'published',
  'course_publised_dt': '2020-07-05'}]


# In[3]:


import psycopg2
from psycopg2.extras import execute_values


# In[4]:


columns = courses[0].keys()
query = "INSERT INTO courses ({}) VALUES %s".format(','.join(columns))


# In[5]:


query


# In[9]:


values = [[value for value in course.values()] for course in courses]


# In[10]:


values


# In[ ]:


execute_values(cursor, query, values)


# In[ ]:


conn.commit()

