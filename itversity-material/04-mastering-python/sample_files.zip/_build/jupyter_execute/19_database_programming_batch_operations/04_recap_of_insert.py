#!/usr/bin/env python
# coding: utf-8

# ## Recap of Insert
# 
# Let us recap about `INSERT` statement as we are going to use it for batch loading.
# * We can either insert one record at a time or multiple records.
# * Inserting one record at a time is typically used to insert records for transaction based use cases.
# * For batch processing we typically try to insert multiple records at a time.
# * At times we even might consider native database utilities for batch loading into table. This process is also known as direct path load.

# In[2]:


get_ipython().run_cell_magic('HTML', '', '<iframe width="560" height="315" src="https://www.youtube.com/embed/i1tVHNAEvRQ?rel=0&amp;controls=1&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>')


# In[1]:


get_ipython().run_line_magic('run', '02_function_get_database_connection.ipynb')


# In[2]:


get_ipython().run_line_magic('run', '03_creating_database_table.ipynb')


# In[3]:


# Here is the insert statement to insert one record
# INSERT INTO users 
#     (user_first_name, user_last_name, user_email_id, user_password, user_role, is_active) 
# VALUES 
#     ('Gordan', 'Bradock', 'gbradock0@barnesandnoble.com', 'h9LAz7p7ub', 'U', true),
#     ('Tobe', 'Lyness', 'tlyness1@paginegialle.it', 'oEofndp', 'U', true),
#     ('Addie', 'Mesias', 'amesias2@twitpic.com', 'ih7Y69u56', 'U', true)

cursor = sms_connection.cursor()
query = ("""
    INSERT INTO users 
        (user_first_name, user_last_name, user_email_id, user_password, user_role, is_active)
    VALUES 
        (%s, %s, %s, %s, %s, %s)
""")

users = [
    ('Gordan', 'Bradock', 'gbradock0@barnesandnoble.com', 'h9LAz7p7ub', 'U', True),
    ('Tobe', 'Lyness', 'tlyness1@paginegialle.it', 'oEofndp', 'U', True),
    ('Addie', 'Mesias', 'amesias2@twitpic.com', 'ih7Y69u56', 'U', True)
]

cursor.executemany(query, users)
sms_connection.commit()

cursor.close()
sms_connection.close()


# In[4]:


get_ipython().run_line_magic('load_ext', 'sql')


# In[5]:


get_ipython().run_line_magic('env', 'DATABASE_URL=postgresql://itversity_sms_user:sms_password@localhost:5432/itversity_sms_db')


# In[6]:


get_ipython().run_line_magic('sql', 'SELECT * FROM users')


# In[ ]:




