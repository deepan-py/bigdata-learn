#!/usr/bin/env python
# coding: utf-8

# ## Batch Loading of Data
# 
# Let us understand how we should take care of loading data in batches. We will perform load using multiple approaches to understand which one is better.
# * Approach 1: Insert and commit each record. Whenever there is a commit in database, there is considerable amount of overhead.
# * Approach 2: Insert one record at a time, but commit at the end.
# * Approach 3: Insert all records at once and commit at the end.
# * Approach 4: Insert records in chunks or batches and commit per chunk or batch.
# 
# We should follow the fourth approach while dealing with huge amounts of data. It will facilitate us to restartability or recoverability. 

# In[1]:


get_ipython().run_cell_magic('HTML', '', '<iframe width="560" height="315" src="https://www.youtube.com/embed/LPeuy38Ihoo?rel=0&amp;controls=1&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>')


# In[1]:


get_ipython().run_line_magic('run', '02_function_get_database_connection.ipynb')


# In[2]:


def get_cursor(connection):
    return connection.cursor()


# In[3]:


get_ipython().run_line_magic('run', '06_reading_data_from_file.ipynb')


# In[4]:


orders.head(3)


# In[5]:


order_items.head(3)


# In[6]:


query = ("""INSERT INTO orders
         (order_id, order_date, order_customer_id, order_status)
         VALUES
         (%s, %s, %s, %s)""")


# ```{note}
# Inserting and committing one row in each iteration. Commit is quite expensive as it result in database checkpoint.
# ```

# In[7]:


def load_orders(connection, cursor, query, data):
    for rec in data:
        cursor.execute(query, rec)
        connection.commit()


# In[8]:


cursor = get_cursor(retail_connection)


# In[9]:


get_ipython().run_cell_magic('time', '', 'load_orders(retail_connection, cursor, query, orders.values.tolist()[:10000])')


# In[10]:


cursor.execute('TRUNCATE TABLE orders')


# In[11]:


retail_connection.commit()


# ```{note}
# Inserting one row at a time but committing at the end. Even though it is much faster than previous approach, it is transferring one record at a time between Python Engine and Database Engine.
# 
# We can further tune by leveraging batch insert.
# ```

# In[12]:


def load_orders(connection, cursor, query, data):
    for rec in data:
        cursor.execute(query, rec)
    connection.commit()


# In[13]:


cursor = get_cursor(retail_connection)


# In[14]:


get_ipython().run_cell_magic('time', '', '# Inserting all orders\nload_orders(retail_connection, cursor, query, orders.values.tolist())')


# In[15]:


cursor.execute('TRUNCATE TABLE orders')


# ```{note}
# All the records will be inserted as part of one batch insert operation. If there is lot of data to be inserted, then this might start running into issues such as out of memory.
# 
# Also, if the job fails in the middle then all the data that is transferred thus far will be lost. Hence it is better to batch with manageable size and then insert as well as commit.
# ```

# In[16]:


def load_orders(connection, cursor, query, data):
    cursor.executemany(query, data)
    connection.commit()


# In[17]:


cursor = get_cursor(retail_connection)


# In[18]:


get_ipython().run_cell_magic('time', '', '# Inserting all orders\nload_orders(retail_connection, cursor, query, orders.values.tolist())')


# ```{note}
# You might not see significant difference in performance as our database is running in the same server from where the code is running to insert the data.
# ```

# In[25]:


cursor.execute('TRUNCATE TABLE orders')


# In[20]:


len(orders.values.tolist())


# In[21]:


list(range(0, len(orders.values.tolist()), 10000))


# In[22]:


def load_orders(connection, cursor, query, data, batch_size=10000):
    for i in range(0, len(data), batch_size):
        cursor.executemany(query, data[i:i+batch_size])
        connection.commit()


# In[26]:


cursor = get_cursor(retail_connection)


# In[27]:


get_ipython().run_cell_magic('time', '', '# Inserting all orders\nload_orders(retail_connection, cursor, query, orders.values.tolist())')


# In[28]:


get_ipython().run_line_magic('load_ext', 'sql')


# In[29]:


get_ipython().run_line_magic('env', 'DATABASE_URL=postgresql://itversity_retail_user:retail_password@localhost:5432/itversity_retail_db')


# In[30]:


get_ipython().run_cell_magic('sql', '', '\nSELECT count(1) FROM orders')


# In[ ]:




