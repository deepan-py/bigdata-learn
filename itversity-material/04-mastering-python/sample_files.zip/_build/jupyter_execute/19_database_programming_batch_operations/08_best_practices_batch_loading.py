#!/usr/bin/env python
# coding: utf-8

# ## Best Practices - Batch Loading
# 
# Let us go through some of the best practices to perform batch load.
# * We should minimize the number of connections to database.
# * We should avoid executing queries using hard coded values. Rather, we should prefer bind variables.
# * Too much committing is bad as commit incurs overhead.
# * If we have to load considerable amount of data, we should consider committing every 1,000 records or 10,000 records or even more based up on the capacity of the database.
# * Most of the mainstream databases perform direct path I/O or batch load which might perform better compare to looping, inserting and committing data. In some cases, we can use those features.

# In[1]:


get_ipython().run_cell_magic('HTML', '', '<iframe width="560" height="315" src="https://www.youtube.com/embed/rlf39J0PyQo?rel=0&amp;controls=1&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>')


# In[ ]:




