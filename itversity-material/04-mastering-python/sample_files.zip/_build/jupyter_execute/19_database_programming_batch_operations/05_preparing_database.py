#!/usr/bin/env python
# coding: utf-8

# ## Preparing Database
# 
# Let us setup the database along with tables to see how the batch loads are typically done.
# 
# * We have scripts and data set available in our [GitHub repository](https://github.com/dgadiraju/retail_db.git). If you are using our environment the repository is already cloned under **/data/retail_db**.
# * It have scripts to create tables with primary keys. Those scripts are generated from MySQL tables and refactored for Postgres. We will create the tables and load the data from the files.
#   * Script to create tables: **create_db_tables_pg.sql**
# * Here are the commands to launch `psql` and run scripts to create tables as well as load data into tables.
# 
# ```sql
# psql -U itversity_retail_user \
#   -h localhost \
#   -p 5432 \
#   -d itversity_retail_db \
#   -W
# 
# \i /data/retail_db/create_db_tables_pg.sql
# ```

# In[1]:


get_ipython().run_cell_magic('HTML', '', '<iframe width="560" height="315" src="https://www.youtube.com/embed/3LTPIMnNMZI?rel=0&amp;controls=1&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>')


# In[1]:


get_ipython().run_line_magic('run', '02_function_get_database_connection.ipynb')


# In[2]:


retail_connection


# In[3]:


get_ipython().run_line_magic('load_ext', 'sql')


# In[4]:


get_ipython().run_line_magic('env', 'DATABASE_URL=postgresql://itversity_retail_user:retail_password@localhost:5432/itversity_retail_db')


# In[5]:


get_ipython().run_cell_magic('sql', '', '\nSELECT * FROM orders LIMIT 10')


# In[6]:


get_ipython().run_cell_magic('sql', '', '\nSELECT * FROM order_items LIMIT 10')


# In[ ]:




