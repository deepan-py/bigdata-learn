#!/usr/bin/env python
# coding: utf-8

# ## Creating Database Table
# 
# Before getting into action with respect to CRUD operations, we need to prepare tables.
# 
# * We can either use `psql` or **SQL Workbench** to connect to the database and create table directly.
# * Let us drop and create the table `users` if it already exists. 
# * I am using Jupyter based environment for demo - feel free to use what ever is relevant to your project or comfortable for you.
# 
# > One need to have decent database and SQL skills to be comfortable with all types of application development. Feel free to **Master SQL using Postgresql** as target database using [this course](https://postgresql.itversity.com) or [playlist](https://www.youtube.com/playlist?list=PLf0swTFhTI8p2yirPMTUhJ2xzuQhhUTwY).
# 

# In[1]:


get_ipython().run_line_magic('load_ext', 'sql')


# In[2]:


get_ipython().run_line_magic('env', 'DATABASE_URL=postgresql://itversity_sms_user:sms_password@localhost:5432/itversity_sms_db')


# In[3]:


get_ipython().run_cell_magic('sql', '', "\nSELECT * FROM information_schema.tables \nWHERE table_catalog = 'itversity_sms_db' AND table_schema = 'public'\nLIMIT 10")


# In[4]:


get_ipython().run_cell_magic('sql', '', '\nDROP TABLE IF EXISTS users CASCADE;')


# In[5]:


get_ipython().run_cell_magic('sql', '', "\nSELECT * FROM information_schema.tables \nWHERE table_catalog = 'itversity_sms_db' AND table_schema = 'public'\nAND table_name = 'users'\nLIMIT 10")


# In[6]:


get_ipython().run_cell_magic('sql', '', "\nCREATE TABLE users (\n    user_id SERIAL PRIMARY KEY,\n    user_first_name VARCHAR(30) NOT NULL,\n    user_last_name VARCHAR(30) NOT NULL,\n    user_email_id VARCHAR(50) NOT NULL,\n    user_email_validated BOOLEAN DEFAULT FALSE,\n    user_password VARCHAR(200),\n    user_role VARCHAR(1) NOT NULL DEFAULT 'U', --U and A\n    is_active BOOLEAN DEFAULT FALSE,\n    create_ts TIMESTAMP DEFAULT CURRENT_TIMESTAMP,\n    last_updated_ts TIMESTAMP DEFAULT CURRENT_TIMESTAMP\n)")


# * Let us validate the objects that are created in the underlying database. We can either run query against **information_schema** or use Database Explorer in **SQL Workbench** or even `psql`.

# In[12]:


get_ipython().run_cell_magic('sql', '', "\nSELECT * FROM information_schema.tables \nWHERE table_catalog = 'itversity_sms_db' AND table_schema = 'public'\nAND table_name = 'users'\nLIMIT 10")


# In[13]:


get_ipython().run_cell_magic('sql', '', "\nSELECT * FROM information_schema.columns \nWHERE table_name = 'users'\nLIMIT 10")


# In[14]:


get_ipython().run_line_magic('sql', 'SELECT * FROM users')


# In[ ]:




