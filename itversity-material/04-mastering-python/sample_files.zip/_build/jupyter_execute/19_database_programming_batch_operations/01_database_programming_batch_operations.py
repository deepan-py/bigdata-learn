#!/usr/bin/env python
# coding: utf-8

# # Database Programming – Batch Operations
# 
# As part of this section, we will talk about how we can perform batch operations against database tables using Python.
# 
# * Recap of Insert
# * Preparing Database
# * Reading Data from File
# * Processing Data using Pandas
# * Writing Data to Table
# * Batch Loading of Data
# * Best Practices - Batch Loading
# * Read Process Write Pattern
