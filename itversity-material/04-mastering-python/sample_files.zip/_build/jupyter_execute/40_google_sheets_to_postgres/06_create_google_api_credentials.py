#!/usr/bin/env python
# coding: utf-8

# ## Create Google API Credentials
# 
# Let us understand how to create Google API Credentials.
# * You need to have a valid GCP account with a valid billing account.
# * Go to https://console.developers.google.com
# * Create new project or choose existing one.
# * I will be demonstrating using new project.
# * Here are the instructions to create a project.
#   * Click on the project select drop down.
#   * Click on New Project
#   * Give the project name - **googlesheetsdemo**
#   * Make sure to select the billing account.
#   * Click on **Create**. You will be redirected to **Credentials** page.
# * Here are the instructions to add credentials.
#   * Click on **ENABLE APIS AND SERVICES** to enable Google Sheets API.
#   * Search for **Google Sheets** and enable the API.
#   * Go to **Credentials** on the left side bar.
# * Configure the OAuth consent screen
#   * Click on **CONFIGURE CONSENT SCREEN**
#   * Choose User Type as **Internal**
#   * Click on Create button
#   * Enter App Name: **GSheets Demo**. Make sure you do not have **Google** in the App Name. It might throw some generic error.
#   * Select Appropriate Email under **User Support Email**
#   * Enter your email id under **Developer Contact Information**
#   * Click on **Save and Continue**
# * Add OAuth 2.0 Client ID
#   * Click on **CREATE CRDENTIALS** and then on **Create OAuth client ID**
#   * Select the **Application Type** as **Desktop Application**
#   * Provide a client name: **Google Sheets Demo Client**
#   * It will generate the credentials. You can download it using the GCP Console.
#   

# In[ ]:




