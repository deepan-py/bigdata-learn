#!/usr/bin/env python
# coding: utf-8

# ## Understanding Google Sheets
# 
# Let us spend some time to understand some of the metadata of Google Sheet.
# * Every Google sheet will have name or title as well as id.
# * Google sheet id is unique.
# * The main document is also known as Spreadsheet and it can have more than one sheet or tab.
# * The names of the sheets with in the main sheet will be at bottom. They have to be unique.
# * Each sheet with in main sheet will contain cells, rows and columns. It is like a matrix.
# * Cells can be referred using the combination of column id and row id such as A1, B2, C1 etc.
# * We can access the range of cells either by using row or column or both.
#   * A1:A10 (all the cells in column A from row 1 to row 10)
#   * A1:D1 (all the cells in row 1 from column A to column D)
#   * A1:D4 (all the cells from A1 to A4, B1 to B4, C1 to C4 and then D1 to D4).
