#!/usr/bin/env python
# coding: utf-8

# ## Reading Google Sheet Metadata
# 
# Let us understand how to read Google Sheet Metadata such as Title.
# * Use credentials and also make sure that picke file is generated.
# * Open the Google Sheet and get the sheet id from the URL.
# * Create sheet object and invoke `get` by passing sheet id. It will generate **HTTP Request** object.
# * Use `execute` to get the metadata of the Google Sheet.

# In[1]:


get_ipython().run_line_magic('run', '05_overview_of_google_sheets_api.ipynb')


# In[ ]:


SPREADSHEET_ID = '1lgyVuw6nVyRnmKtCPbXF4kYcop5HMJ8H3eeNsArAlVk'


# In[ ]:


def get_credentials():
    SCOPES = ['https://www.googleapis.com/auth/spreadsheets.readonly']
    creds = None
    # The file token.pickle stores the user's access and refresh tokens, and is
    # created automatically when the authorization flow completes for the first
    # time.
    if os.path.exists('token.pickle'):
        with open('token.pickle', 'rb') as token:
            creds = pickle.load(token)

    # If there are no (valid) credentials available, let the user log in.
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(
                'credentials.json', SCOPES)
            creds = flow.run_local_server(port=0)
        # Save the credentials for the next run
        with open('token.pickle', 'wb') as token:
            pickle.dump(creds, token)
            
    return creds


# In[ ]:


creds = get_credentials()


# In[ ]:


service = build('sheets', 'v4', credentials=creds)


# In[ ]:


type(service)


# In[ ]:


sheet = service.spreadsheets()


# In[ ]:


type(sheet)


# In[ ]:


sheet_request = sheet.get(spreadsheetId=SPREADSHEET_ID)


# In[ ]:


type(sheet_request)


# In[ ]:


sheet_details = sheet_request.execute()


# In[ ]:


type(sheet_details)


# In[ ]:


sheet_details


# In[ ]:


sheet_details['properties']['title']


# In[ ]:


sheet_details['sheets']


# In[ ]:


sheet_details['sheets'][0]['properties']


# In[ ]:


form_name = sheet_details['properties']['title']


# In[ ]:


form_name


# In[ ]:


def get_sheet_name_and_id(service, spreadsheetId):
    sheet = service.spreadsheets()
    sheet_metadata = sheet.get(spreadsheetId=spreadsheetId).execute()
    return {
        'id': spreadsheetId,
        'title': sheet_metadata['properties']['title']
    }


# In[ ]:


get_sheet_name_and_id(service, SPREADSHEET_ID)


# In[ ]:




