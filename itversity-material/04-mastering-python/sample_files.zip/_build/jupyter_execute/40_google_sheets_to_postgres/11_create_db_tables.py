#!/usr/bin/env python
# coding: utf-8

# In[ ]:


get_ipython().run_line_magic('load_ext', 'sql')


# In[ ]:


get_ipython().run_line_magic('env', 'DATABASE_URL=postgresql://itversity_sms_user:sms_password@localhost:5432/itversity_sms_db')


# In[ ]:


get_ipython().run_cell_magic('sql', '', '\nDROP TABLE IF EXISTS users')


# In[ ]:


get_ipython().run_cell_magic('sql', '', '\nCREATE TABLE users (\n    user_id SERIAL PRIMARY KEY,\n    email_id VARCHAR(100) NOT NULL UNIQUE,\n    first_name VARCHAR(100),\n    last_name VARCHAR(100),\n    last_updated_ts TIMESTAMP DEFAULT CURRENT_TIMESTAMP\n)')


# In[ ]:


get_ipython().run_cell_magic('sql', '', '\nDROP TABLE form_submissions')


# In[ ]:


get_ipython().run_cell_magic('sql', '', '\nCREATE TABLE form_submissions (\n    submission_id SERIAL PRIMARY KEY,\n    user_id INT NOT NULL,\n    form_id VARCHAR(100) NOT NULL,\n    form_title VARCHAR(100) NOT NULL,\n    submitted_ts TIMESTAMP NOT NULL,\n    last_updated_ts TIMESTAMP DEFAULT CURRENT_TIMESTAMP,\n    UNIQUE (user_id, form_id)\n)')


# In[ ]:


get_ipython().run_cell_magic('sql', '', '\nALTER TABLE form_submissions\nADD FOREIGN KEY (user_id) \n    REFERENCES users(user_id)')


# In[ ]:


get_ipython().run_cell_magic('sql', '', '\nCREATE INDEX form_submissions_user_id_idx\nON form_submissions(user_id)')


# In[ ]:


get_ipython().run_cell_magic('sql', '', '\nSELECT * FROM users')


# In[ ]:


get_ipython().run_cell_magic('sql', '', '\nSELECT * FROM form_submissions')


# In[ ]:




