#!/usr/bin/env python
# coding: utf-8

# ## Overview of Google Sheets API
# 
# Let us understand how we can leverage Google Sheets API to read the data from the sheet generated using the form. You can use [Python Quickstart for Google Sheets API](https://developers.google.com/sheets/api/quickstart/python) provided by Google for reference.
# * Import all relevant classes or functions.
# * Define Scopes - `readonly` is sufficient for us.
# * Make sure authentication flow is successful.
# * Define variables for spreadsheet id and data range.
# * Create sheet object and get title.
# * Read the data from the range of your choice using the sheet name.
# 
# Let us import all the libraries and then get on to the authentication.

# In[ ]:


import pickle
import os.path
from googleapiclient.discovery import build
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request

