#!/usr/bin/env python
# coding: utf-8

# ## Google form to Postgres
# 
# Here are the high level steps to get the email data from Google form to Dynamodb.
# * Make sure to have table created in Dynamodb.
# * Create the form with all the relevant questions.
# * Convert the form to Google sheet.
# * Setup Project in Google Developer Console and download credentials.
# * Install required Python libraries
# * Read the data from Google Sheet
# * Apply all the transformations as per your requirements.
# * Make sure to have a target table in Postgres database.
# * Populate data to Postgres table.
