#!/usr/bin/env python
# coding: utf-8

# ## Install required libraries
# 
# We need to read the data from Google sheet and write to Postgres database. Here are the libraries we need to install.
# * We need following libraries to read the data from Google sheet we need to have the libraries provided by Google.
#   * google-api-python-client
#   * google-auth-httplib2
#   * google-auth-oauthlib
# * We will be using `pandas` to process the data.
# * We need `psycopg2` to write data to Postgres Database.

# In[ ]:


get_ipython().system('pip install --upgrade     google-api-python-client     google-auth-httplib2     google-auth-oauthlib')


# In[ ]:


get_ipython().system('pip install --upgrade pandas')


# In[ ]:


get_ipython().system('pip install --upgrade psycopg2')

