#!/usr/bin/env python
# coding: utf-8

# ## Running SQL Queries using Pandas
# 
# Let us understand how to run SQL Queries using Pandas. Here are the steps that need to be followed to run SQL Queries against Postgres database.
# * Make sure Pandas, Psycopg2 as well as SQL Alchemy are installed.
# * Create database engine object using SQL Alchemy.
# * Make sure to build the query that is required to process the data as per the requirements.
# * Use Pandas `read_sql` using query and engine objects.
# * Even though we can run any query using `read_sql`, it will throw exceptions if the query or command does not return the data. For example, DML statements like `DELETE` throw exceptions as it does not return the rows even though data is successfully deleted satisfying the condition.
# 
# **Note: We are going to see the demo using Postgres. Similar steps can be followed for database of any type that is supported using SQL Alchemy**.

# In[ ]:


get_ipython().system('pip list|grep pandas')


# In[ ]:


get_ipython().system('pip list|grep psycopg2')


# In[4]:


get_ipython().system('pip list|grep -i sqlalchemy')


# In[1]:


get_ipython().run_line_magic('run', '13_set_up_variables_for_db_connectivity.ipynb')


# In[5]:


import pandas as pd


# In[6]:


import psycopg2
import sqlalchemy as db
from sqlalchemy.ext.declarative import declarative_base
Base = declarative_base()

engine = db.create_engine(f'postgresql://{username}_sms_user:{password}@{postgres_host}:{postgres_port}/{username}_sms_db')


# In[7]:


type(engine)


# In[8]:


courses_query = 'SELECT * FROM courses'


# In[9]:


pd.read_sql(courses_query, engine)


# In[ ]:




