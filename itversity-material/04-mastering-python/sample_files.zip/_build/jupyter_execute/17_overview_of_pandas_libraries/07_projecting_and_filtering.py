#!/usr/bin/env python
# coding: utf-8

# ## Projecting and Filtering
# 
# Let us understand how to project as well as filter data in Data Frames.

# In[1]:


get_ipython().run_cell_magic('HTML', '', '<iframe width="560" height="315" src="https://www.youtube.com/embed/wdugcckiUm8?rel=0&amp;controls=1&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>')


# In[1]:


get_ipython().run_line_magic('run', '06_csv_to_pandas_data_frame.ipynb')


# In[2]:


orders


# In[3]:


order_items


# * Projecting data

# In[4]:


orders.order_date


# In[5]:


orders['order_date']


# In[6]:


# Project order_item_order_id and order_item_subtotal
order_items[['order_item_order_id', 'order_item_subtotal']]


# * Filter for order_item_order_id 2

# In[7]:


order_items.columns


# In[8]:


order_items.order_item_order_id == 2


# In[9]:


order_items[order_items.order_item_order_id == 2]


# In[ ]:


order_items['order_item_order_id'] == 2


# In[ ]:


order_items[order_items['order_item_order_id'] == 2]


# In[ ]:


order_items.query('order_item_order_id == 2')


# In[ ]:


order_items[
    (order_items.order_item_order_id == 2) &
    ((order_items.order_item_subtotal >= 150) &
     (order_items.order_item_subtotal <= 250)
    )]


# ```{note}
# String passed to `query` API is broken into multiple lines for readability purposes.
# ```

# In[ ]:


order_items.query('order_item_order_id == 2 and ' +
                  'order_item_subtotal >= 150 and ' +
                  'order_item_subtotal <= 250')


# In[ ]:


orders[orders.order_date == '2013-08-01 00:00:00.0']


# In[ ]:


orders.query('order_date == "2013-08-01 00:00:00.0"')


# ```{note}
# We can use the functions available as part of `str` usng `python` as engine.
# ```

# In[ ]:


order_date = '2013-08-01 00:00:00.0'


# In[ ]:


get_ipython().run_line_magic('pinfo', 'order_date.startswith')


# In[ ]:


order_date.startswith('2013-08')


# In[ ]:


orders.query('order_date.str.startswith("2013-08")', engine='python')


# ### Task 1
# Get all the orders placed by customer_id

# In[ ]:


orders[:10]


# In[ ]:


orders.query('order_customer_id == 12431')


# In[ ]:


orders[orders.order_customer_id == 12431]


# In[ ]:


orders[orders['order_customer_id'] == 12431]


# ### Task 2
# 
# Get all the orders placed by customer_id for a given month. Month is passed as **yyyy-MM** format.

# In[ ]:


orders.query('order_customer_id == 12431 and order_date.str.startswith("2014-01")', engine='python')


# In[ ]:


orders[(orders.order_customer_id == 12431) & (orders.order_date.str.startswith('2014-01'))]


# ### Task 3
# Get all the orders which are placed by customer with id 12431 in January 2014 and status is in PENDING_PAYMENT or PROCESSING

# In[ ]:


orders.query('order_customer_id == 12431 and ' +
             'order_date.str.startswith("2014-01") and ' +
             'order_status in ("PROCESSING", "PENDING_PAYMENT")', 
             engine='python'
            )


# In[ ]:


orders[(orders.order_customer_id == 12431) & 
       (orders.order_date.str.startswith('2014-01')) &
       (orders.order_status.isin(['PROCESSING', 'PENDING_PAYMENT']))
      ]


# In[ ]:




