#!/usr/bin/env python
# coding: utf-8

# # Overview of Pandas Libraries
# 
# * Pandas Data Structures – Overview
# * Overview of Series
# * Creating Data Frames from lists
# * Data Frames - Basic Operations
# * CSV to Pandas Data Frame
# * Projecting and Filtering
# * Performing Total Aggregations
# * Performing Global Aggregations
# * Writing Data Frames to Files
# * Joining Data Frames

# In[ ]:




