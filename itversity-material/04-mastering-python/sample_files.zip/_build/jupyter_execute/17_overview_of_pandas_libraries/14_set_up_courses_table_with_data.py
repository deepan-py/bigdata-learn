#!/usr/bin/env python
# coding: utf-8

# ## Set up courses table with Data
# 
# Let us set up courses table with data, so that we understand how to run SQL queries using Pandas as part of the next topic.
# * Connect to database
# * Create table
# * Load collection into the table.

# In[11]:


get_ipython().run_line_magic('run', '13_set_up_variables_for_db_connectivity.ipynb')


# In[6]:


get_ipython().run_line_magic('load_ext', 'sql')


# In[7]:


get_ipython().run_line_magic('env', 'DATABASE_URL=postgresql://{username}_sms_user:{password}@{postgres_host}:{postgres_port}/{username}_sms_db')


# In[8]:


get_ipython().run_cell_magic('sql', '', '\nDROP TABLE IF EXISTS courses')


# In[9]:


get_ipython().run_cell_magic('sql', '', "\nCREATE TABLE courses (\n    course_id SERIAL PRIMARY KEY,\n    course_name VARCHAR(60),\n    course_author VARCHAR(40),\n    course_status VARCHAR(9) CHECK (course_status IN ('published', 'inactive', 'draft')),\n    course_published_dt DATE\n)")


# In[10]:


get_ipython().run_cell_magic('sql', '', "\nINSERT INTO courses \n    (course_name, course_author, course_status, course_published_dt) \nVALUES \n    ('Programming using Python', 'Bob Dillon', 'published', '2020-09-30'),\n    ('Data Engineering using Python', 'Bob Dillon', 'published', '2020-07-15'),\n    ('Data Engineering using Scala', 'Elvis Presley', 'draft', NULL),\n    ('Programming using Scala', 'Elvis Presley', 'published', '2020-05-12'),\n    ('Programming using Java', 'Mike Jack' , 'inactive', '2020-08-10'),\n    ('Web Applications - Python Flask', 'Bob Dillon', 'inactive', '2020-07-20'),\n    ('Web Applications - Java Spring', 'Mike Jack', 'draft', NULL),\n    ('Pipeline Orchestration - Python', 'Bob Dillon', 'draft', NULL),\n    ('Streaming Pipelines - Python', 'Bob Dillon', 'published', '2020-10-05'),\n    ('Web Applications - Scala Play', 'Elvis Presley', 'inactive', '2020-09-30'),\n    ('Web Applications - Python Django', 'Bob Dillon', 'published', '2020-06-23'),\n    ('Server Automation - Ansible', 'Uncle Sam' , 'published', '2020-07-05');")


# In[ ]:




