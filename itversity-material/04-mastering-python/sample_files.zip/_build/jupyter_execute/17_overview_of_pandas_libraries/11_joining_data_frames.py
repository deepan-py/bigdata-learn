#!/usr/bin/env python
# coding: utf-8

# ## Joining Data Frames
# 
# Let us understand how to join Data Frames using Pandas.

# In[2]:


get_ipython().run_cell_magic('HTML', '', '<iframe width="560" height="315" src="https://www.youtube.com/embed/CheC4SzfqoQ?rel=0&amp;controls=1&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>')


# In[1]:


get_ipython().run_line_magic('run', '06_csv_to_pandas_data_frame.ipynb')


# In[2]:


orders


# In[3]:


order_items


# * Join orders and order_items using orders.order_id and order_items.order_item_order_id.

# In[4]:


get_ipython().run_line_magic('pinfo', 'orders.join')


# In[5]:


orders.set_index('order_id')


# In[6]:


order_items.set_index('order_item_order_id')


# In[7]:


# Join orders and order_items using order_id (order_item_order_id from order_items)
orders.set_index('order_id').     join(order_items.set_index('order_item_order_id'))


# In[8]:


orders.set_index('order_id').     join(order_items.set_index('order_item_order_id'), how='inner')


# In[9]:


orders.set_index('order_id').     join(order_items.set_index('order_item_order_id'), how='inner').     reset_index()


# In[10]:


orders.set_index('order_id').     join(order_items.set_index('order_item_order_id'), how='inner').     reset_index().     rename(columns={'index': 'order_id'})


# ### Task 1
# Compute Daily Revenue using orders.order_date and order_items.order_item_order_subtotal considering only COMPLETE and CLOSED orders.
# * Here are the steps to join orders and order_items and get daily revenue.
#   * Create Data Frames for both orders and order_items using data in files.
#   * Filter for orders which are either in **COMPLETE** or **CLOSED** status.
#   * Set the join index for both the Data Frames.
#   * Join both the Data Frames using `inner`.
#   * Group the join results using **order_date** and get daily revenue by using `sum` on top of **order_item_subtotal**.

# In[11]:


orders_considered = orders.query("order_status in ('COMPLETE', 'CLOSED')")


# In[12]:


orders_filtered = orders[orders.order_status.isin(["COMPLETE", "CLOSED"])]


# In[13]:


orders_considered.     set_index('order_id').     join(order_items.set_index('order_item_order_id'), how='inner').     groupby('order_date')['order_item_subtotal'].     agg(['sum']).     rename(columns={'sum': 'revenue'})


# ### Task 2
# Get all the orders for which there are no corresponding order items.
# * We can use default join (`left`) to get orders with out corresponding order items.

# In[14]:


orders.set_index('order_id').     join(order_items.set_index('order_item_order_id'))


# In[15]:


orders.set_index('order_id').     join(order_items.set_index('order_item_order_id')).     query('order_item_id.isna()')


# In[18]:


orders_joined = orders.set_index('order_id').     join(order_items.set_index('order_item_order_id'))


# In[20]:


orders_joined[orders_joined['order_item_id'].isna()]


# ### Task 3
# Compute Daily Product Revenue using orders.order_date as well as order_items.order_item_product_id and order_items.order_item_order_subtotal considering only COMPLETE and CLOSED orders.

# In[21]:


orders_considered = orders.query("order_status in ('COMPLETE', 'CLOSED')")


# In[22]:


orders_filtered = orders[orders.order_status.isin(["COMPLETE", "CLOSED"])]


# In[23]:


orders_considered.     set_index('order_id').     join(order_items.set_index('order_item_order_id'), how='inner')


# In[24]:


orders_considered.     set_index('order_id').     join(order_items.set_index('order_item_order_id'), how='inner').     groupby(['order_date', 'order_item_product_id'])['order_item_subtotal']


# In[26]:


list(orders_considered.     set_index('order_id').     join(order_items.set_index('order_item_order_id'), how='inner').     groupby(['order_date', 'order_item_product_id'])['order_item_subtotal'])[:10]


# In[27]:


orders_considered.     set_index('order_id').     join(order_items.set_index('order_item_order_id'), how='inner').     groupby(['order_date', 'order_item_product_id'])['order_item_subtotal'].     agg(['sum']).     rename(columns={'sum': 'revenue'})


# In[28]:


orders_considered.     set_index('order_id').     join(order_items.set_index('order_item_order_id'), how='inner').     groupby(['order_date', 'order_item_product_id'])['order_item_subtotal'].     agg(['sum']).     rename(columns={'sum': 'revenue'}).     reset_index()


# In[ ]:




