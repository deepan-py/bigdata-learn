#!/usr/bin/env python
# coding: utf-8

# ## Performing Total Aggregations
# 
# Let us understand how to perform total or global aggregations using Pandas.

# In[1]:


get_ipython().run_cell_magic('HTML', '', '<iframe width="560" height="315" src="https://www.youtube.com/embed/7hOpn5-8ArY?rel=0&amp;controls=1&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>')


# In[1]:


get_ipython().run_line_magic('run', '06_csv_to_pandas_data_frame.ipynb')


# * Getting number of records in the Data Frame.

# In[2]:


orders.shape


# In[3]:


orders.shape[0]


# In[4]:


order_items.shape[0]


# * Getting number of non np.NaN values in each attribute in a Data Frame

# In[5]:


orders.count()


# In[7]:


type(orders.count())


# In[6]:


orders.count()['order_id']


# In[8]:


orders.order_id.count()


# In[9]:


orders['order_id'].count()


# * Getting basic statistics of numeric fields of a Data Frame

# In[10]:


orders.describe()


# * Get revenue for order id 2 from order_items

# In[11]:


order_items[order_items.order_item_order_id == 2]


# In[12]:


order_items[order_items.order_item_order_id == 2].order_item_subtotal


# In[13]:


order_items[order_items.order_item_order_id == 2].order_item_subtotal.sum()


# In[14]:


order_items[order_items.order_item_order_id == 2]['order_item_subtotal'].sum()


# ### Task 1
# Use orders and get total number of records for a given month (201401). 

# In[15]:


orders


# In[16]:


orders.order_date


# In[17]:


orders['order_date'].str.slice(0, 7)


# In[18]:


orders['order_date'].str.slice(0, 7).str.replace('-', '').astype('int64')


# In[19]:


orders['order_date'].str.slice(0, 7).str.replace('-', '').astype('int64') == 201401


# In[20]:


orders[orders['order_date'].str.slice(0, 7).str.replace('-', '').astype('int64') == 201401]


# In[21]:


orders[orders['order_date'].str.slice(0, 7).str.replace('-', '').astype('int64') == 201401]['order_id'].count()


# ### Task 2
# 
# Use order_items data set and compute total revenue generated for a given product_id.

# In[22]:


order_items


# In[23]:


order_items.query('order_item_product_id == 502')


# In[24]:


order_items.query('order_item_product_id == 502')['order_item_subtotal'].sum()


# In[25]:


order_items.query('order_item_product_id == 502').order_item_subtotal.sum()


# ### Task 3
# 
# Use order_items data set and get total number of items sold as well as total revenue generated for a given product_id.

# In[26]:


order_items


# In[28]:


order_items_for_product_id = order_items.query('order_item_product_id == 502')
order_items_for_product_id


# In[29]:


order_items_for_product_id[['order_item_quantity', 'order_item_subtotal']]


# In[30]:


order_items_for_product_id[['order_item_quantity', 'order_item_subtotal']].sum()


# In[31]:


tuple(order_items_for_product_id[['order_item_quantity', 'order_item_subtotal']].sum())


# In[32]:


dict(order_items_for_product_id[['order_item_quantity', 'order_item_subtotal']].sum())


# ### Task 4
# 
# Create a collection with sales and commission percentage. Using that collection compute total commission amount. If the commission percent is None or not present, treat it as 0.
# * Each element in the collection should be a tuple.
# * First element is the sales amount and second element is commission percentage.
# * Commission for each sale can be computed by multiplying commission percentage with sales (make sure to divide commission percentage by 100).
# * Some of the records does not have commission percentage, in that case commission amount for that sale shall be 0

# In[33]:


transactions = [(376.0, 8),
(548.23, 14),
(107.93, 8),
(838.22, 14),
(846.85, 21),
(234.84,),
(850.2, 21),
(992.2, 21),
(267.01,),
(958.91, 21),
(412.59,),
(283.14,),
(350.01, 14),
(226.95,),
(132.7, 14)]


# In[34]:


sales = pd.DataFrame(transactions, columns=['sale_amount', 'commission_pct'])


# In[35]:


sales


# In[37]:


sales_filled = sales.fillna(0.0)
sales_filled


# In[39]:


(sales_filled['sale_amount'] * (sales_filled['commission_pct'] / 100))


# In[41]:


(sales_filled['sale_amount'] * (sales_filled['commission_pct'] / 100)).sum()


# In[42]:


(sales_filled['sale_amount'] * (sales_filled['commission_pct'] / 100)).sum().round(2)


# In[ ]:




