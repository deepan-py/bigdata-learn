#!/usr/bin/env python
# coding: utf-8

# ## Creating Data Frames from lists
# 
# Let us go through the details of creating Data Frames using collections.
# * Pandas Data Frame is a two-dimensional labeled array capable of holding attributes of any data type.
# * It is similar to multi column excel spreadsheet or a database table.
# * We can create Data Frame using list of tuples or list of dicts.
# * We can also create Data Frames using data from files. We will have a look at it later.

# In[1]:


get_ipython().run_cell_magic('HTML', '', '<iframe width="560" height="315" src="https://www.youtube.com/embed/qAZLWbpwPqo?rel=0&amp;controls=1&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>')


# In[1]:


import pandas as pd


# ```{note}
# Creating Pandas Data Frame using list of tuples.
# ```

# In[2]:


sals_ld = [(1, 1500.0), (2, 2000.0, 10.0), (3, 2200.00)]


# In[3]:


sals_df = pd.DataFrame(sals_ld)


# In[4]:


sals_df


# In[5]:


sals_df = pd.DataFrame(sals_ld, columns=['id', 'sal', 'comm'])


# In[6]:


sals_df


# In[7]:


sals_df['id']


# In[8]:


sals_df[['id', 'sal']]


# ```{note}
# Creating Pandas Data Frame using list of dicts.
# ```

# In[9]:


sals_ld = [
    {'id': 1, 'sal': 1500.0},
    {'id': 2, 'sal': 2000.0},
    {'id': 3, 'sal': 2200.0}
]


# ```{note}
# Column names will be inherited automatically using keys from the dict.
# ```

# In[10]:


sals_df = pd.DataFrame(sals_ld)


# In[11]:


sals_df


# In[12]:


sals_df['id']


# In[13]:


sals_ld = [
    {'id': 1, 'sal': 1500.0},
    {'id': 2, 'sal': 2000.0, 'comm': 10},
    {'id': 3, 'sal': 2200.0}
]


# In[14]:


get_ipython().run_line_magic('pinfo', 'pd.DataFrame')


# In[15]:


sals_ld


# In[16]:


sals_df = pd.DataFrame(sals_ld)


# In[17]:


sals_df


# In[ ]:




