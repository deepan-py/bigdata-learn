#!/usr/bin/env python
# coding: utf-8

# ## Overview of Series
# 
# Let us quickly go through one of the Pandas Data Structure - Series.
# * Pandas Series is a one-dimensional labeled array capable of holding any data type.
# * It is similar to one column in an excel spreadsheet or a database table.
# * We can create Series by using dict.

# In[1]:


get_ipython().run_cell_magic('HTML', '', '<iframe width="560" height="315" src="https://www.youtube.com/embed/AvCbDkC16bk?rel=0&amp;controls=1&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>')


# In[19]:


d = {"JAN": 10, "FEB": 15, "MAR": 12, "APR": 16}


# In[20]:


type(d)


# In[21]:


d


# In[22]:


import pandas as pd
s = pd.Series(d)


# In[23]:


s


# In[24]:


import pandas as pd
s = pd.Series(d, name='val')


# In[25]:


s


# In[26]:


s['FEB']


# In[27]:


s[0]


# In[28]:


s[1:3]


# In[29]:


type(s)


# In[30]:


s.sum()


# In[31]:


l = [10, 15, 12, 16]


# In[32]:


l_s = pd.Series(l)


# In[33]:


l_s


# In[34]:


l_s[0]


# * When we fetch only one column from a Pandas Dataframe, it will be returned as Series.
# 
# ```{note}
# Don’t worry too much about creating Data Frames yet, we are trying to understand how Data Frame and Series are related.
# ```

# In[35]:


orders_path = "/data/retail_db/orders/part-00000"


# In[36]:


orders_schema = [
  "order_id",
  "order_date",
  "order_customer_id",
  "order_status"
]


# In[37]:


orders = pd.read_csv(orders_path,
  header=None,
  names=orders_schema
)


# In[38]:


orders


# In[39]:


type(orders)


# In[40]:


orders.order_date


# In[41]:


type(orders.order_date)


# In[42]:


order_dates = orders.order_date
order_dates


# In[43]:


type(order_dates)


# In[ ]:




