#!/usr/bin/env python
# coding: utf-8

# ## Data Frames - Basic Operations
# 
# Here are some of the basic operations we typically perform on top of Pandas Data Frame.
# * Getting number of records and columns.
# * Getting data types of the columns.
# * Replacing `NaN` with some standard values.
# * Dropping a column from the Data Frame.
# * Getting or updating column names.
# * Sorting by index or values.

# In[1]:


get_ipython().run_cell_magic('HTML', '', '<iframe width="560" height="315" src="https://www.youtube.com/embed/HKKJ51dmpEA?rel=0&amp;controls=1&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>')


# In[1]:


import pandas as pd


# ```{note}
# Creating Pandas Data Frame using list of dicts.
# ```

# In[2]:


sals_ld = [
    {'id': 1, 'sal': 1500.0},
    {'id': 2, 'sal': 2000.0, 'comm': 10.0},
    {'id': 3, 'sal': 2200.0, 'active': False}
]


# ```{note}
# Column names will be inherited automatically using keys from the dict.
# ```

# In[3]:


sals_df = pd.DataFrame(sals_ld)


# In[4]:


sals_df


# In[5]:


sals_df['id']


# In[6]:


sals_df[['id', 'sal']]


# In[7]:


sals_df.shape


# In[8]:


sals_df.shape[0]


# In[9]:


sals_df.count()


# In[10]:


sals_df.count()[:2]


# In[11]:


sals_df.count()['id']


# In[12]:


sals_df


# In[13]:


sals_df.dtypes


# In[14]:


get_ipython().run_line_magic('pinfo', 'sals_df.fillna')


# In[15]:


sals_df.fillna(0.0)


# In[16]:


sals_df.fillna({'comm': 0.0})


# In[17]:


sals_df.fillna({'comm': 0.0, 'active': True})


# ```{note}
# Original Data Frame will be untouched, instead a new Data Frame will be created. Original Data Frame still contain `NaN`. We typically assign the output of most of the Data Frame functions to another variable or object.
# ```

# In[18]:


sals_df


# In[19]:


sals_df = sals_df.fillna({'comm': 0.0, 'active': True})
sals_df


# In[24]:


get_ipython().run_line_magic('pinfo', 'sals_df.drop')


# In[25]:


sals_df.drop(columns='comm')


# ```{note}
# We can also drop multiple columns by passing column names as list.
# ```

# In[26]:


sals_df.drop(columns=['comm', 'active'])


# In[29]:


sals_df.drop(['comm', 'active'], axis=1)


# In[30]:


sals_df = sals_df.drop(columns='comm')


# In[31]:


sals_df.columns


# In[33]:


sals_df.columns = ['employee_id', 'salary', 'commission']


# In[34]:


sals_df


# In[35]:


get_ipython().run_line_magic('pinfo', 'sals_df.sort_index')


# In[37]:


sals_df.sort_index(ascending=False)


# In[38]:


get_ipython().run_line_magic('pinfo', 'sals_df.sort_values')


# In[39]:


sals_df.sort_values(by='employee_id', ascending=False)


# In[40]:


sals_df.sort_values(by='salary')


# In[41]:


sals_df.sort_values(by='salary', ascending=False)


# In[42]:


sals_ld = [
    {'id': 1, 'sal': 1500.0},
    {'id': 2, 'sal': 2000.0, 'comm': 10.0},
    {'id': 3, 'sal': 2200.0, 'active': False},
    {'id': 4, 'sal': 2000.0}
]


# In[43]:


sals_df = pd.DataFrame(sals_ld)


# In[45]:


sals_df.sort_values(by=['sal', 'id'])


# In[49]:


sals_df.sort_values(by=['sal', 'id'], ascending=[False, True])


# In[ ]:




