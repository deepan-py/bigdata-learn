#!/usr/bin/env python
# coding: utf-8

# ## Exercises - Pandas Data Frames
# 
# Here are some of the Exercises related to Pandas.
# * Get all the orders which belong to the month of 2013 August
# * Get all the orders which belong to the months of August, September and October in 2013.
# * Get count of orders by status for the month of 2014 January
# * Get all the records from orders where there are no corresponding records in order_items
# * Get all the customers who have not placed any orders
# * Get the revenue by status

# In[ ]:




