#!/usr/bin/env python
# coding: utf-8

# ## Writing Data Frames to Files
# 
# Pandas also provides simple APIs to write the data back to files.
# * Let us write the revenue per order along with order_id to a file.
# 
# Here are the steps which you need to follow before writing Data Frame to a file.
# * Make sure you have the Data Frame that is supposed to be written to file.
# * You need to ensure that you have write permissions on the folder under which files are supposed to be written.
# * Make sure to use appropriate key word arguments to write the Data Frame into file as per the requirements.

# In[1]:


get_ipython().run_cell_magic('HTML', '', '<iframe width="560" height="315" src="https://www.youtube.com/embed/aMn3EWTVptI?rel=0&amp;controls=1&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>')


# In[1]:


get_ipython().run_line_magic('run', '06_csv_to_pandas_data_frame.ipynb')


# In[2]:


get_ipython().run_line_magic('pinfo', 'order_items.to_csv')


# In[3]:


import getpass
username = getpass.getuser()


# In[4]:


username


# In[5]:


base_dir = f"/home/{username}/data/retail_db"
base_dir


# In[6]:


output_dir = f'{base_dir}/revenue_per_order'
output_dir


# In[8]:


get_ipython().run_cell_magic('sh', '', '\nrm -rf /home/`whoami`/data/retail_db/revenue_per_order')


# In[9]:


get_ipython().run_cell_magic('sh', '', '\nls -ltr /home/`whoami`/data/retail_db')


# In[10]:


import subprocess

subprocess.call(['rm', '-rf', output_dir])


# In[11]:


import subprocess

subprocess.call(['mkdir', '-p', output_dir])


# In[12]:


import subprocess
#ls -ltr /Users/itversity/Research/data/retail_db/revenue_per_order
subprocess.check_output(['ls', '-ltr', output_dir])


# In[13]:


get_ipython().run_cell_magic('sh', '', 'ls -ltr /data/retail_db')


# In[14]:


orders


# In[15]:


order_items


# In[16]:


order_items.     groupby('order_item_order_id')['order_item_subtotal'].     agg(['sum', 'min', 'max', 'count'])


# In[18]:


order_items


# In[17]:


order_items.     groupby('order_item_order_id')['order_item_subtotal'].     agg(['sum', 'min', 'max', 'count']).     reset_index()


# In[19]:


order_items.     groupby('order_item_order_id')['order_item_subtotal'].     agg(['sum', 'min', 'max', 'count']).     rename(columns={'count': 'item_count', 'sum': 'revenue'}).     to_json(f'{output_dir}/revenue_per_order.json', orient='table')


# In[20]:


get_ipython().run_cell_magic('sh', '', 'ls -ltr /home/`whoami`/data/retail_db/revenue_per_order')


# In[21]:


get_ipython().run_cell_magic('sh', '', 'head -10 /home/`whoami`/data/retail_db/revenue_per_order/revenue_per_order.json')


# In[22]:


order_items.     groupby('order_item_order_id')['order_item_subtotal'].     agg(['sum', 'min', 'max', 'count']).     rename(columns={'count': 'item_count', 'sum': 'revenue'})


# In[23]:


order_items.     groupby('order_item_order_id')['order_item_subtotal'].     agg(['sum', 'min', 'max', 'count']).     rename(columns={'count': 'item_count', 'sum': 'revenue'}).     round(2).     to_csv(output_dir + '/revenue_per_order.csv')


# In[24]:


get_ipython().run_cell_magic('sh', '', 'ls -ltr /home/`whoami`/data/retail_db/revenue_per_order')


# In[25]:


get_ipython().run_cell_magic('sh', '', 'head /home/`whoami`/data/retail_db/revenue_per_order/revenue_per_order.csv')


# In[ ]:




