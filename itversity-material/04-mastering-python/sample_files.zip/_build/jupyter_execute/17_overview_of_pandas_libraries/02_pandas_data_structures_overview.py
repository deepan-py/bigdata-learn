#!/usr/bin/env python
# coding: utf-8

# ## Pandas Data Structures – Overview
# 
# Let us understand the details with respect to Pandas.
# * Pandas is not a core Python module and hence we need to install using pip - `pip install pandas`.
# * It has 2 types of data structures - `Series` and `DataFrame`.
# * `Series` is a one dimension array while `DataFrame` is a two dimension array.
# * `Series` only contains index for each row and one attribute or column.
# * `DataFrame` contains index for each row and multiple columns.
# * Each attribute in the DataFrame is nothing but a Series.
# * We can perform all standard transformations using Pandas APIs
# * We also have SQL based wrappers on top of Pandas where we can write queries.

# In[1]:


get_ipython().run_cell_magic('HTML', '', '<iframe width="560" height="315" src="https://www.youtube.com/embed/BQM2W5HFIG8?rel=0&amp;controls=1&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>')


# Here are the steps to get started with Pandas Data Structures:
# * Make sure Pandas library is installed using `pip`.
# * Import Pandas library - `import pandas as pd`
# * We need to have a collection or data in a file to create Pandas Data Structures.
# * Use appropriate APIs on the data to create Pandas Data Structures.
#   * `Series` for single dimension array.
#   * `DataFrame` for two dimension array.
# 
# ```{note}
# Typically we use `Series` for list of regular objects or dict and `DataFrame` for list of tuples or list of dicts. Let us use list for `Series` and list of dicts for `DataFrame`.
# ```

# In[1]:


get_ipython().system('pip install pandas')


# In[2]:


import pandas as pd


# In[3]:


sals_l = [1500.0, 2000.0, 2200.00]


# In[4]:


get_ipython().run_line_magic('pinfo', 'pd.Series')


# In[5]:


sals_s = pd.Series(sals_l, name='sal')


# In[6]:


sals_s


# In[8]:


sals_s[:2]


# In[13]:


sals_ld = [(1, 1500.0), (2, 2000.0), (3, 2200.00)]


# In[14]:


get_ipython().run_line_magic('pinfo', 'pd.DataFrame')


# In[15]:


sals_df = pd.DataFrame(sals_ld, columns=['id', 'sal'])


# In[16]:


sals_df


# In[20]:


sals_df['id']


# In[ ]:




