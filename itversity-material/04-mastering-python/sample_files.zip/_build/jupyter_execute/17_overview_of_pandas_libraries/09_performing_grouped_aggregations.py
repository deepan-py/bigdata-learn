#!/usr/bin/env python
# coding: utf-8

# ## Performing Grouped Aggregations
# 
# Let us understand how to perform grouped or by key aggregations using Pandas.
# * Here are the steps we need to follow:
#   * Make sure data is read into Data Frame.
#   * Identify the key on which data should be aggregated. If the data has to be aggregated on derived field which is not available as part of the Data Frame, then first we need to update data frame with the derived field.
#   * Using the key group the values using `groupby` function on data frame. We can only pass column names from Data Frame as part of `groupby`.
#   * Apply required aggregate functions to get aggregated results based up on the key.
# * We can apply multiple aggregate functions at a time after creating grouped data frame.
# * Pandas Data Frame exposes a function called as `rename` to provide aliases to the aggregated fields.

# In[1]:


get_ipython().run_cell_magic('HTML', '', '<iframe width="560" height="315" src="https://www.youtube.com/embed/GEn5-9D38FM?rel=0&amp;controls=1&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>')


# In[23]:


get_ipython().run_line_magic('run', '06_csv_to_pandas_data_frame.ipynb')


# * Getting number of orders per day

# In[2]:


orders


# In[6]:


orders.groupby(orders['order_date'])


# In[9]:


list(orders.groupby(orders['order_date'])['order_id'])[:3]


# In[10]:


orders.groupby(orders['order_date'])['order_id'].count()


# * Getting number of orders per status

# In[11]:


orders.groupby('order_status')['order_status'].count()


# * Computing revenue per order

# In[12]:


order_items


# In[13]:


list(order_items.     groupby('order_item_order_id')['order_item_subtotal'])[:5]


# In[14]:


order_items.     groupby('order_item_order_id')['order_item_subtotal'].     sum()


# In[15]:


order_items.     groupby('order_item_order_id')['order_item_subtotal'].     agg(['sum', 'min', 'max', 'count'])


# In[16]:


order_items.     groupby('order_item_order_id')['order_item_subtotal'].     agg(['sum', 'min', 'max', 'count']).     rename(columns={'count': 'item_count', 'sum': 'revenue'})


# In[17]:


order_items.rename(columns={'order_item_order_id': 'order_id'})


# ### Task 1
# 
# Get order_item_count and order_revenue for each order_id.

# In[18]:


order_items


# In[20]:


order_items.     groupby('order_item_order_id')['order_item_subtotal'].     agg(['sum', 'count']).     rename(columns={'sum': 'order_revenue', 'count': 'order_item_count'}).     reset_index()


# ### Task 2
# 
# Get order count by month using orders data for specific order_status.

# In[24]:


orders


# In[25]:


orders.order_date.str.slice(0, 7)


# In[26]:


orders['order_month'] = orders.order_date.str.slice(0, 7)


# In[27]:


orders


# In[30]:


orders.query('order_status == "COMPLETE"').     groupby('order_month')['order_id'].     count().     sort_index()


# ### Task 3
# 
# Get order_revenue and order_quantity for each order_id. Add quantity of all items for each order_id to get order_quantity.

# In[36]:


order_metrics = order_items.     groupby('order_item_order_id')[['order_item_subtotal', 'order_item_quantity']].     agg(['sum'])


# In[38]:


order_metrics.columns = ['order_revenue', 'order_quantity']


# In[39]:


order_metrics


# In[ ]:




