#!/usr/bin/env python
# coding: utf-8

# In[1]:


get_ipython().run_line_magic('run', '00_setup_database_variables.ipynb')


# In[2]:


get_ipython().run_line_magic('load_ext', 'sql')


# In[3]:


get_ipython().run_line_magic('env', 'DATABASE_URL=postgresql://{username}_sms_user:{password}@{postgres_host}:{postgres_port}/{username}_sms_db')


# In[4]:


get_ipython().run_cell_magic('sql', '', '\nTRUNCATE TABLE stations')


# In[5]:


get_ipython().run_cell_magic('sql', '', '\nTRUNCATE TABLE station_rental_types')


# In[6]:


get_ipython().run_cell_magic('sql', '', '\nCOMMIT')


# In[7]:


get_ipython().run_cell_magic('sql', '', '\nSELECT * FROM station_rental_types')


# In[8]:


import requests
import pandas as pd
def read_from_rest_api(url):
    content_dict = requests.get(url).json()
    df = pd.json_normalize(content_dict, ['data', 'stations'])
    return df


# In[9]:


import psycopg2
def get_pg_connection(host, port, database, user, password):
    connection = None
    try:
        connection = psycopg2.connect(
            host=host,
            port=port,
            database=database,
            user=user,
            password=password
        )
    except Exception as e:
        raise(e)
    
    return connection


# In[10]:


def load_df_to_table(conn, df, table_name):
    cursor = connection.cursor()
    data = [tuple(value) for value in df.values]
    columns = ', '.join(df.columns)
    values_clause = ', '.join(['%s'] * len(df.columns))
    query = f"""
        INSERT INTO 
        {table_name} ({columns})
        VALUES ({values_clause})
        """
    cursor.executemany(query, data)
    connection.commit()
    cursor.close()


# In[11]:


url = "https://gbfs.citibikenyc.com/gbfs/en/station_information.json"
df = read_from_rest_api(url)

stations_df = df[['station_id',
'station_type',
'name',
'short_name',
'capacity',
'external_id',
'has_kiosk',
'legacy_id',
'region_id',
'electric_bike_surcharge_waiver']]

station_rental_types_df = df[['station_id', 'rental_methods']].     explode('rental_methods').     rename(columns={'rental_methods': 'rental_type'})

connection = get_pg_connection(
    host=postgres_host,
    port=postgres_port,
    database=f'{username}_sms_db',
    user=f'{username}_sms_user',
    password=password
)

load_df_to_table(connection, stations_df, 'stations')
load_df_to_table(connection, station_rental_types_df, 'station_rental_types')


# In[12]:


get_ipython().run_cell_magic('sql', '', '\nSELECT * FROM stations LIMIT 5')


# In[13]:


get_ipython().run_cell_magic('sql', '', '\nSELECT * FROM station_rental_types LIMIT 5')


# In[ ]:




