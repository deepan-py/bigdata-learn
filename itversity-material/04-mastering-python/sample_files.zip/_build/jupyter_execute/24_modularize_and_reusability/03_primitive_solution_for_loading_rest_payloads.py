#!/usr/bin/env python
# coding: utf-8

# ## Primitive Solution for loading REST payloads
# 
# Let us see how the solution is typically provided by the learners. There is nothing wrong with it as a learner, but this solution is not following software engineering principles such as modularizing the code or reusability of the code.

# In[ ]:


get_ipython().run_line_magic('run', '00_setup_database_variables.ipynb')


# In[ ]:


get_ipython().run_line_magic('load_ext', 'sql')


# In[ ]:


get_ipython().run_line_magic('env', 'DATABASE_URL=postgresql://{username}_sms_user:{password}@{postgres_host}:{postgres_port}/{username}_sms_db')


# In[ ]:


get_ipython().run_cell_magic('sql', '', "SELECT * FROM information_schema.tables \nWHERE table_catalog = '{username}_sms_db' AND table_schema = 'public'\nLIMIT 10")


# In[ ]:


get_ipython().run_cell_magic('sql', '', '\nDROP TABLE IF EXISTS stations;\nCREATE TABLE stations (\n    id SERIAL PRIMARY KEY,\n    station_id INT UNIQUE ,\n    station_type VARCHAR(200),\n    name VARCHAR(200),\n    short_name VARCHAR(200),\n    capacity VARCHAR(100),\n    external_id varchar(300),\n    has_kiosk varchar(100),\n    legacy_id varchar(100),\n    region_id varchar(100),\n    electric_bike_surcharge_waiver varchar(100),\n    eightd_station_services varchar(300)\n);')


# In[ ]:


get_ipython().run_cell_magic('sql', '', 'SELECT * FROM stations LIMIT 5')


# In[ ]:


import psycopg2
def get_pg_connection(host, port, database, user, password):
    connection = None
    try:
        connection = psycopg2.connect(
            host=host,
            port=port,
            database=database,
            user=user,
            password=password
        )
    except Exception as e:
        raise(e)
    
    return connection


# In[ ]:


connection = get_pg_connection(
    host=postgres_host,
    port=postgres_port,
    database=f'{username}_sms_db',
    user=f'{username}_sms_user',
    password=password
)


# In[ ]:


import requests
url = "https://gbfs.citibikenyc.com/gbfs/en/station_information.json"
payload={}
headers = {}
response = requests.request("GET", url, headers=headers, data=payload)


# In[ ]:


import json
data = response.json()
data = data['data']['stations']


# In[ ]:


import pandas as pd
df = pd.json_normalize(data)


# In[ ]:


type(df)


# In[ ]:


stations_df = df[['station_id', 'station_type', 'name', 'short_name',
             'capacity', 'external_id', 'has_kiosk', 'legacy_id',
             'region_id', 'electric_bike_surcharge_waiver', 'eightd_station_services']]


# In[ ]:


stations = [tuple(station) for station in stations_df.values]


# In[ ]:


cursor = connection.cursor()
query = ("""
         INSERT INTO stations 
         (station_id, station_type, name, short_name, 
          capacity, external_id, has_kiosk, legacy_id, 
          region_id, electric_bike_surcharge_waiver, eightd_station_services
         )
         VALUES 
         (%s, %s, %s, %s, 
          %s, %s, %s, %s, 
          %s, %s, %s
         )
    """)
cursor.executemany(query, stations)
connection.commit()
cursor.close()


# In[ ]:


get_ipython().run_cell_magic('sql', '', '\nSELECT count(1) from stations')


# In[ ]:


get_ipython().run_cell_magic('sql', '', '\nDROP TABLE IF EXISTS station_rental_types;\nCREATE TABLE station_rental_types(\n    station_rental_type_id SERIAL PRIMARY KEY,\n    station_id INT ,\n    rental_type VARCHAR(100),\n    UNIQUE(station_id, rental_type)\n);')


# In[ ]:


get_ipython().run_cell_magic('sql', '', 'SELECT * FROM station_rental_types limit 5')


# In[ ]:


station_rental_types_df = df[['station_id', 'rental_methods']].explode('rental_methods')


# In[ ]:


station_rental_types = [tuple(station_rental_type) for station_rental_type in station_rental_types_df.values]


# In[ ]:


cursor = connection.cursor()
query = ("""
         INSERT INTO station_rental_types 
         (station_id,rental_type)
         VALUES 
         (%s, %s)
        """)
cursor.executemany(query, station_rental_types)
connection.commit()
cursor.close()
connection.close()


# In[ ]:


get_ipython().run_cell_magic('sql', '', '\nSELECT count(*) FROM station_rental_types')

