#!/usr/bin/env python
# coding: utf-8

# ## Set up variables for DB Connectivity
# 
# This notebook will be run from other notebooks. We are going to set up variables required for database connectivity.
# 
# We will provide the required information. You can use the labs password which is assigned to you.

# In[ ]:


import getpass


# In[ ]:


username = getpass.getuser()


# In[ ]:


# Paste your password between the single quotes


# In[ ]:


password = 'Itv3rs1ty!23'


# In[ ]:


postgres_host = 'm01.itversity.com'


# In[ ]:


postgres_port = 5433

