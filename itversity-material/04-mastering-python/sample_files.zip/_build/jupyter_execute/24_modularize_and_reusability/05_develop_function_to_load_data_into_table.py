#!/usr/bin/env python
# coding: utf-8

# ## Develop Function to Load Data into table
# 
# Let us develop a generic function to load data into any table. 
# * As part of the primitive solution there is redundant code for `stations` and `station_rental_types`.
# * Except for `INSERT` query, rest of the logic is same.
# * Here is the logic for `stations`.
# 
# ```python
# cursor = connection.cursor()
# query = ("""
#          INSERT INTO stations 
#          (station_id, station_type, name, short_name, 
#           capacity, external_id, has_kiosk, legacy_id, 
#           region_id, electric_bike_surcharge_waiver, eightd_station_services
#          )
#          VALUES 
#          (%s, %s, %s, %s, 
#           %s, %s, %s, %s, 
#           %s, %s, %s
#          )
#     """)
# cursor.executemany(query, stations)
# connection.commit()
# cursor.close()
# ```
# 
# * Here is the logic for `station_rental_types`.
# 
# ```python
# cursor = connection.cursor()
# query = ("""
#          INSERT INTO station_rental_types 
#          (station_id,rental_type)
#          VALUES 
#          (%s, %s)
#         """)
# cursor.executemany(query, station_rental_types)
# connection.commit()
# cursor.close()
# ```

# In[1]:


get_ipython().run_line_magic('run', '00_setup_database_variables.ipynb')


# In[2]:


get_ipython().run_line_magic('load_ext', 'sql')


# In[3]:


get_ipython().run_line_magic('env', 'DATABASE_URL=postgresql://{username}_sms_user:{password}@{postgres_host}:{postgres_port}/{username}_sms_db')


# In[4]:


get_ipython().run_cell_magic('sql', '', '\nTRUNCATE TABLE station_rental_types')


# In[5]:


get_ipython().run_cell_magic('sql', '', '\nCOMMIT')


# In[6]:


import psycopg2
def get_pg_connection(host, port, database, user, password):
    connection = None
    try:
        connection = psycopg2.connect(
            host=host,
            port=port,
            database=database,
            user=user,
            password=password
        )
    except Exception as e:
        raise(e)
    
    return connection


# In[7]:


def load_df_to_table(conn, df):
    cursor = connection.cursor()
    data = [tuple(value) for value in df.values]
    # query is still hardcoded with table name, column names and number of columns
    query = """
        INSERT INTO 
        station_rental_types (station_id, rental_type)
        VALUES (%s, %s)
        """
    cursor.executemany(query, data)
    connection.commit()
    cursor.close()


# In[8]:


# Creating dataframe to validate our function

import pandas as pd

df = pd.DataFrame([
    {'station_id': 1, 'rental_type': 'KEY'},
    {'station_id': 1, 'rental_type': 'CREDIT CARD'},
    {'station_id': 2, 'rental_type': 'KEY'},
    {'station_id': 2, 'rental_type': 'CREDIT CARD'}
])


# In[9]:


connection = get_pg_connection(
    host=postgres_host,
    port=postgres_port,
    database=f'{username}_sms_db',
    user=f'{username}_sms_user',
    password=password
)


# In[10]:


connection.commit()


# In[11]:


load_df_to_table(connection, df)


# In[12]:


get_ipython().run_cell_magic('sql', '', '\nSELECT * FROM station_rental_types')


# Let us improvise `load_df_to_table`.
# * The `query` is hard coded with details related to `station_rental_types`.
# * We need to pass `table_name` as argument.
# * Based upon the structure of `df` passed, we need to get the column names dynamically.
# * Also we need to update `VALUES` clause by placing `%s` dynamically based upon the number of columns in the `df` we are trying to load into the table.

# In[13]:


df = pd.DataFrame([
    {'station_id': 1, 'rental_type': 'KEY'},
    {'station_id': 1, 'rental_type': 'CREDIT CARD'},
    {'station_id': 2, 'rental_type': 'KEY'},
    {'station_id': 2, 'rental_type': 'CREDIT CARD'}
])


# In[14]:


df.columns


# In[15]:


# Get column names
columns = ', '.join(df.columns)


# In[16]:


columns


# In[17]:


['a']


# In[18]:


['a'] * 10


# In[19]:


len(df.columns)


# In[20]:


# Create list with %s based up on the number of the columns
['%s'] * len(df.columns)


# In[21]:


# Dynamically generate values clause
values_clause = ', '.join(['%s'] * len(df.columns))


# In[22]:


values_clause


# In[23]:


def load_df_to_table(conn, df, table_name):
    cursor = connection.cursor()
    data = [tuple(value) for value in df.values]
    columns = ', '.join(df.columns)
    values_clause = ', '.join(['%s'] * len(df.columns))
    query = f"""
        INSERT INTO 
        {table_name} ({columns})
        VALUES ({values_clause})
        """
    cursor.executemany(query, data)
    connection.commit()
    cursor.close()


# In[24]:


get_ipython().run_cell_magic('sql', '', '\nTRUNCATE TABLE station_rental_types')


# In[25]:


get_ipython().run_cell_magic('sql', '', '\nSELECT * FROM station_rental_types')


# In[26]:


# We do not need the original REST payload to validate.
# The function accepts connection, data frame and table name.
# We can validate by using connection, simple data frame 
  # and any valid table which is consistent with the data frame.
df = pd.DataFrame([
    {'station_id': 1, 'rental_type': 'KEY'},
    {'station_id': 1, 'rental_type': 'CREDIT CARD'},
    {'station_id': 2, 'rental_type': 'KEY'},
    {'station_id': 2, 'rental_type': 'CREDIT CARD'}
])

connection = get_pg_connection(
    host=postgres_host,
    port=postgres_port,
    database=f'{username}_sms_db',
    user=f'{username}_sms_user',
    password=password
)

load_df_to_table(connection, df, 'station_rental_types')


# In[27]:


get_ipython().run_cell_magic('sql', '', '\nSELECT * FROM station_rental_types')


# Here is the core logic to load a data frame into a table.
# 
# ```python
# def load_df_to_table(conn, df, table_name):
#     cursor = connection.cursor()
#     data = [tuple(value) for value in df.values]
#     columns = ', '.join(df.columns)
#     values_clause = ', '.join(['%s'] * len(df.columns))
#     query = f"""
#         INSERT INTO 
#         {table_name} ({columns})
#         VALUES ({values_clause})
#         """
#     cursor.executemany(query, data)
#     connection.commit()
#     cursor.close()
# ```
# 
# Here are some of the issues with the above logic.
# * We are not logging the progress of the process.
# * The code is not handling any exceptions.
# * Data is being inserted using `executemany` all at once. If we have to deal with a very large data set, this might not be the most effective solution. 
# * If you are not sure, please review our content related to database programming for batch operations as part of **18_database_programming_batch_operations**.
# * As we have only one function for all the tables, it will be easier to close those gaps in this function compared to primitive solution.

# In[ ]:




