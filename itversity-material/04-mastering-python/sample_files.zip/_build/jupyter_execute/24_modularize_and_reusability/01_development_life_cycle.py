#!/usr/bin/env python
# coding: utf-8

# ## Development Life Cycle
# 
# Let us get an overview of development life cycle. It typically starts after you are assigned a Jira story, if the project is implemented using agile methodology.
# 
# Here are the typical steps you need to follow for the development tasks given to you as part of the story.
# * Analyze and understand the requirements. You need to work with your lead or business, if the requirements are not clear.
# * Design the solution and get it reviewed or follow the design given to you. If the design is given to you, you need to make sure that it is clear to you. If not, you need to work with the lead who have given you the design.
# * Develop the code as per the given requirements and finalized design.
# * Perform unit testing or validations. In some cases, you have to do both.
# * Some of the stories will have acceptance criteria. You should include the scenarios highlighted in the acceptance criteria as part of unit testing or validations.
# 
# **Note that, modularizing and reusability is typically used in terms of developing the code. But they are applicable in almost all the phases**.

# In[ ]:




