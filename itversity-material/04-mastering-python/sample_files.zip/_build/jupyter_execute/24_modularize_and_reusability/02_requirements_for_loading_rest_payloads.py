#!/usr/bin/env python
# coding: utf-8

# ## Requirements for loading REST payloads
# 
# Let us perform an exercise to get the REST Payload into a database table.
# * REST API URL: https://gbfs.citibikenyc.com/gbfs/en/station_information.json
# * Database Name: **{username}_sms_db**
# * First Table Name: **stations**
# * Create table for following fields. Make sure to use appropriate data types
#   * id - Sequence generated primary key
#   * station_id - Uniqueness needs to be enforced.
#   * station_type
#   * name
#   * short_name
#   * capacity
#   * external_id
#   * has_kiosk
#   * legacy_id
#   * region_id
#   * electric_bike_surcharge_waiver
#   * eightd_station_services
# * Get the data from the REST payload into the table **stations** created.
# * Run queries for following scenarios.
#   * Get distinct station types.
#   * Get number of stations per region_id.
#   * Get top 10 stations by capacity.
#   * Get number of stations where there are no kiosks.
# * Second Table Name: **station_rental_types**
# * Create table with following fields
#   * station_id
#   * rental_type - the source field is of type list. The target column in the table should be of type VARCHAR.
#   * station_rental_type_id - sequence generated primary key.
#   * Combination of station_id and rental_type is supposed to be unique.
# * For all station ids where there is one or more rental_types, the data should be inserted into the table separately with rental_type.
# * Sample input record `{'station_id': 1, 'rental_types': ['KEY', 'CREDIT CARD]}`
# * Sample data in the table
# 
# |station_id|rental_type|
# |---|---|
# |1|KEY|
# |1|CREDIT CARD|
# 
# * Run queries for following scenarios.
#   * Get number of records from **station_rental_types**
#   * Get number of stations where rental_type is **KEY**
#   * Get number of stations where rental_type is **CREDIT CARD**
#   * Get number of stations by rental_type.
#   * Get the stations where there are no rental types available.

# ### Low level design
# 
# Here is the low level design for the problem.
# * Make sure that tables are created.
# * Read the data from REST API into a Dataframe.
# * Create list of tuples for stations and station_rental_types using the Dataframe created earlier.
# * Populate the tables using a common function.

# In[ ]:




