#!/usr/bin/env python
# coding: utf-8

# ## Common Issues with Primitive Solution
# 
# Here are some of the common issues with primitive solution.
# * The solution does not follow software engineerig principles such as modularizing the solution, reusability of the code, readability of the code to an extent and many more.
# * As code is not modularized properly, you can see redundancy of the code.
#   * The code related to loading data into stations and station_rental_types is almost similar except for the insert query string.
#   * If we want to change the logic for any performance reasons, we need to change the code separately for inserting data into stations as well as station_rental_types.
#   * Even the code which converts the dataframe into list of lists or list of tuples before loading into the database tables is same.
# * Here is what we are supposed to do.
#   * Analyze the complete problem statement.
#   * Map to what you are familiar with and what you are not familiar with.
#   * Divide the solution into manageable components. For Data Engineering problems, we can divide the problem into **read**, **process**, **write** at a high level. You can further divide into smaller components in a hierarchy.
#   * Solve those smaller components based upon your skills and past experience and tackle unknown stuff in parallel.
# * Let us assume that we are good in loading the data into the table. We are trying to load stations and station_rental_types.
# * By developing a generic function which takes data frame and table name as arguments, we are done with code related to loading both the tables.
# * As part of the next topic we will understand how we can develop common function which can be used to load a data frame into the table passed. As long as both data frame and table structure are consistent, it should work.

# In[ ]:




