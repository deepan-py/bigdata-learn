#!/usr/bin/env python
# coding: utf-8

# # Project – Web Scraping and loading into Database
# 
# * Define Problem Statement
# * Setup Project
# * Overview of Python Virtual Environments
# * Installing required libraries
# * Setup Logging
# * Modularizing the Project
# * Setup Database
# * Create required table
# * Reading the data
# * Validating data
# * Apply required transformations
# * Writing to Database
# * Run queries against data

# In[ ]:




