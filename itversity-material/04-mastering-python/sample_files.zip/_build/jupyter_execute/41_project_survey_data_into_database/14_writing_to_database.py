#!/usr/bin/env python
# coding: utf-8

# ## Writing to Database
