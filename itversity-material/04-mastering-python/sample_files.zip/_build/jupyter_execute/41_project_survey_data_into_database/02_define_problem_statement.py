#!/usr/bin/env python
# coding: utf-8

# ## Define Problem Statement
# 
# Let us get the data from Google sheet generated from Google form and store it in the database.
# * At ITVersity, we conduct surveys using Google Forms and we want to store the data in the database.
# 
