#!/usr/bin/env python
# coding: utf-8

# ## Reading the data
