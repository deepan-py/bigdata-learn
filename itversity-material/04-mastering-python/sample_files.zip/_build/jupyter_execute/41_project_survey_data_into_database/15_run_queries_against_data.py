#!/usr/bin/env python
# coding: utf-8

# ## Run queries against data
