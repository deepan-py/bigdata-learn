#!/usr/bin/env python
# coding: utf-8

# ## Validate myJoin
# 
# Let us perform a task to valiate myJoin. Join order_id and order_date from orders as well as order_id and order_item_subtotal from order_items as part of the join results.
# * Read orders data set
# * Create list of tuples using order_id and order_date with order_id as first element.
# * Read order_items data set
# * Create list of tuples using order_item_order_id and order_item_subtotal with order_item_order_id as first element.
# * Invoke myJoin function with these collections.

# In[1]:


get_ipython().run_line_magic('run', '04_develop_myMap.ipynb')


# In[3]:


orders_path = "/data/retail_db/orders/part-00000"
orders = open(orders_path).     read().     splitlines()


# In[4]:


orders[:10]


# In[5]:


orders_map = myMap(orders, 
                   lambda order: (int(order.split(',')[0]), order.split(',')[1])
                  )
orders_map[:10]


# In[6]:


order_items_path = "/data/retail_db/order_items/part-00000"
order_items = open(order_items_path).     read().     splitlines()


# In[7]:


order_items[:10]


# In[8]:


order_items_map = myMap(order_items,
                        lambda order_item: (int(order_item.split(',')[1]),
                                            float(order_item.split(',')[4])
                                           )
                       )


# In[9]:


get_ipython().run_line_magic('run', '10_develop_myJoin.ipynb')


# In[10]:


orders_join = myJoin(orders_map, order_items_map)


# In[11]:


orders_join[:10]


# In[ ]:




