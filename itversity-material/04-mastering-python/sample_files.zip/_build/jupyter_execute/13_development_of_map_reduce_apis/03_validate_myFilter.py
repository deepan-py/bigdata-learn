#!/usr/bin/env python
# coding: utf-8

# ## Validate myFilter
# 
# Use the same examples which were used before as part of Processing Collections using loops.

# In[1]:


get_ipython().run_line_magic('run', '02_develop_myFilter.ipynb')


# * Read orders data

# In[2]:


orders_path = "/data/retail_db/orders/part-00000"
orders = open(orders_path).     read().     splitlines()


# In[3]:


orders[:10]


# In[4]:


order = '1,2013-07-25 00:00:00.0,11599,CLOSED'
int(order.split(',')[2]) == 11599


# * Get orders placed by customer id 12431

# In[5]:


customer_orders = myFilter(orders, 
                           lambda order: int(order.split(',')[2]) == 12431
                          )


# In[6]:


customer_orders


# * Get orders placed by customer id 12431 in the month of 2014 January

# In[7]:


customer_orders_for_month = myFilter(orders, 
                           lambda order: int(order.split(',')[2]) == 12431
                                     and order.split(',')[1].startswith('2014-01')
                          )
customer_orders_for_month


# * Get orders placed by customer id 12431 in processing or pending_payment for the month of 2014 January

# In[8]:


customer_orders_for_month = myFilter(orders, 
                           lambda order: int(order.split(',')[2]) == 12431
                                     and order.split(',')[1].startswith('2014-01')
                                     and order.split(',')[3] in ('PENDING_PAYMENT', 'PROCESSING')
                          )


# In[9]:


customer_orders_for_month


# In[ ]:




