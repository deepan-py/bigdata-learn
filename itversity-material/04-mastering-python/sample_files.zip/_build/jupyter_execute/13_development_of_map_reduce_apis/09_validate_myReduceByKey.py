#!/usr/bin/env python
# coding: utf-8

# ## Validate myReduceByKey
# 
# Let us perform few tasks to validate myReduceKey Function.

# In[1]:


get_ipython().run_line_magic('run', '04_develop_myMap.ipynb')


# In[2]:


get_ipython().run_line_magic('run', '08_develop_myReduceByKey.ipynb')


# * Use the function to get the count by date from orders.

# In[3]:


orders_path = "/data/retail_db/orders/part-00000"
orders = open(orders_path).     read().     splitlines()


# In[4]:


orders[:10]


# In[5]:


orders_map = myMap(orders, 
                   lambda order: (order.split(',')[1], 1)
                  )
orders_map[:10]


# In[6]:


order_count_by_date = myReduceByKey(orders_map, 
                                    lambda t, e: t + e
                                   )


# In[7]:


order_count_by_date[:10]


# * Use the function to get the revenue for each order id.

# In[8]:


order_items_path = "/data/retail_db/order_items/part-00000"
order_items = open(order_items_path).     read().     splitlines()


# In[9]:


order_items[:10]


# In[10]:


order_items_map = myMap(order_items,
                        lambda order_item: (int(order_item.split(',')[1]),
                                            float(order_item.split(',')[4])
                                           )
                       )


# In[11]:


order_items_map[:10]


# In[12]:


revenue_per_order = myReduceByKey(order_items_map,
                                  lambda t, e: round(t + e, 2)
                                 )


# In[13]:


revenue_per_order[:10]


# In[14]:


myReduceByKey(order_items_map,
              lambda t, e: min(t, e)
             )[:10]


# * Use the function to get the revenue as well as the number of items for each order id.

# In[15]:


order_items_map = myMap(order_items,
                        lambda order_item: (int(order_item.split(',')[1]),
                                            (float(order_item.split(',')[4]), 1)
                                           )
                       )


# In[16]:


order_items_map[:10]


# In[17]:


[2, [(199.99, 1), (250.0, 1), (129.99, 1)]]


# In[18]:


t1 = (199.99, 1)
t2 = (250.0, 1)
(t1[0] + t2[0], t1[1] + t2[1])


# In[19]:


myReduceByKey(order_items_map,
              lambda t, e: (round(t[0] + e[0], 2), t[1] + e[1])
             )[:10]


# In[ ]:




