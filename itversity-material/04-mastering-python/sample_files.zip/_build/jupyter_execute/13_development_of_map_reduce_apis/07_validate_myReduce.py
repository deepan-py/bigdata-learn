#!/usr/bin/env python
# coding: utf-8

# ## Validate myReduce
# 
# Let us validate myReduce Function.
# * Compute order revenue for a given order id using order_items.
# * We will use myFilter to filter for the order items for the given order id.
# * Use myMap to extract order_item_subtotal. We will also convert data type of order_item_subtotal.
# * We can now compute order_revenue using myReduce Function.

# In[1]:


get_ipython().run_line_magic('run', '02_develop_myFilter.ipynb')


# In[2]:


get_ipython().run_line_magic('run', '04_develop_myMap.ipynb')


# In[3]:


get_ipython().run_line_magic('run', '06_develop_myReduce.ipynb')


# In[4]:


order_items_path = "/data/retail_db/order_items/part-00000"
order_items = open(order_items_path).     read().     splitlines()


# In[5]:


order_items[:10]


# In[6]:


order_item = '2,2,1073,1,199.99,199.99'
int(order_item.split(',')[1]) == 2


# In[7]:


order_items_filtered = myFilter(order_items,
                                lambda order_item: int(order_item.split(',')[1]) == 2
                               )


# In[8]:


order_items_filtered


# In[9]:


order_item = '2,2,1073,1,199.99,199.99'
float(order_item.split(',')[4])


# In[10]:


order_item_subtotals = myMap(order_items_filtered,
                             lambda order_item: float(order_item.split(',')[4])
                            )


# In[11]:


order_item_subtotals


# In[12]:


sum(order_item_subtotals)


# In[13]:


myReduce(order_item_subtotals, lambda t, e: t + e)


# In[14]:


myReduce(order_item_subtotals, lambda t, e: min(t, e))


# In[ ]:




