#!/usr/bin/env python
# coding: utf-8

# # Development of Map Reduce APIs
# 
# * Develop myFilter
# * Validate myFilter Function
# * Develop myMap
# * Validate myMap Function
# * Develop myReduce
# * Validate myReduce
# * Develop myReduceByKey
# * Validate myReduceByKey
# * Exercises
