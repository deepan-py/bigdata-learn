#!/usr/bin/env python
# coding: utf-8

# ## Develop myMap
# 
# Develop a function by name myMap which takes a collection and a function as arguments. Function should do the following:
# * Iterate through elements.
# * Apply the transformation logic using the argument passed. Append the transformed record to the list.
# * Return the collection with all the elements which are transformed based on the logic passed.
# * We will also validate the function using a simple list of integers.

# In[ ]:


def myMap(c, f):
    c_t = []
    for e in c:
        c_t.append(f(e))
    return c_t


# In[ ]:


l = list(range(1, 10))
l


# In[ ]:


myMap(l, lambda e: e * e)


# In[ ]:


def myMap(c, f):
    return [f(e) for e in c]


# In[ ]:


l = list(range(1, 10))
l


# In[ ]:


myMap(l, lambda e: e * e)

