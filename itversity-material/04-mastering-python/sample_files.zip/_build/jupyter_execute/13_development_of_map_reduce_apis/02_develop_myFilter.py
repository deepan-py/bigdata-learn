#!/usr/bin/env python
# coding: utf-8

# ## Develop myFilter
# 
# Develop a function by name myFilter which takes a collection and a function as arguments. Function should do the following:
# * Iterate through elements
# * Apply the condition using the argument passed. We might pass named function or lambda function.
# * Return the collection with all the elements satisfying the condition.
# 
# ```{note}
# This is how the original function look like.
# ```

# In[ ]:


def get_customer_orders(orders, customer_id):
    orders_filtered = []
    for order in orders:
        if int(order.split(',')[2]) == customer_id:
            orders_filtered.append(order)
    return orders_filtered


# ```{note}
# This is the example of implementation of generic libraries such as `filter`, `map`, `reduce` etc.
# ```

# In[ ]:


def myFilter(c, f):
    c_f = []
    for e in c:
        if f(e):
            c_f.append(e)
    return c_f

