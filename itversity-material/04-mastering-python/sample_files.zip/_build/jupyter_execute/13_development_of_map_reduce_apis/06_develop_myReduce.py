#!/usr/bin/env python
# coding: utf-8

# ## Develop myReduce
# 
# Develop a function by name myReduce which takes a collection and a function as arguments. Function should do the following:
# * Iterate through elements
# * Perform aggregation operation using the argument passed. Argument should have necessary arithmetic logic.
# * Return the aggregated result.

# In[ ]:


l = [1, 4, 6, 2, 5]


# In[ ]:


l[1:]


# In[ ]:


def myReduce(c, f):
    t = c[0]
    for e in c[1:]:
        t = f(t, e)
    return t


# In[ ]:


myReduce(l, lambda t, e: t + e)


# In[ ]:


myReduce(l, lambda t, e: t * e)


# In[ ]:


min(7, 5)


# In[ ]:


myReduce(l, lambda t, e: min(t, e))


# In[ ]:


myReduce(l, lambda t, e: max(t, e))

