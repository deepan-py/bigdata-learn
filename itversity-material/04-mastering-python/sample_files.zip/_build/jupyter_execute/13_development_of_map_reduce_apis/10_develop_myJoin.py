#!/usr/bin/env python
# coding: utf-8

# ## Develop myJoin
# Develop a function by name myJoin which takes two collections of tuples as arguments. Each element in each of the collection should have exactly 2 attributes. Function should do the following:
# * Build the dict for the first collction.
# * Iterate through the second collection and look up into the dict.
# * Return a collection of tuples, where first element is join key and second element is a nested tuple with values from the dict and the second collection.

# In[1]:


def myJoin(c1, c2):
    c1_dict = dict(c1) # dict with first element as key and second element as value
    results = [] # Initializing empty list
    for c2_item in c2: 
        if c2_item[0] in c1_dict:
            results.append((c2_item[0], (c1_dict[c2_item[0]], c2_item[1])))
    return results


# In[2]:


orders = [(1, 'COMPLETE'), (2, 'CLOSED')]


# In[4]:


order_items = [(1, 129.99), (1, 149.99), (2, 250.0), (3, 100.0)]


# In[5]:


myJoin(orders, order_items)


# In[ ]:




