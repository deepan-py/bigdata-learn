#!/usr/bin/env python
# coding: utf-8

# ## Validate myMap
# 
# Let us validate the function by using some realistic examples.

# In[1]:


get_ipython().run_line_magic('run', '04_develop_myMap.ipynb')


# * Use orders and extract order_dates. Also apply set and get only unique dates.

# In[2]:


orders_path = "/data/retail_db/orders/part-00000"
orders = open(orders_path).     read().     splitlines()


# In[3]:


orders[:10]


# In[4]:


order = '1,2013-07-25 00:00:00.0,11599,CLOSED'
order.split(',')[1]


# In[5]:


order_dates = myMap(orders,
                    lambda order: order.split(',')[1]
                   )
order_dates[:10]


# In[6]:


len(orders)


# In[7]:


len(order_dates)


# In[8]:


set(order_dates)


# In[9]:


len(set(order_dates))


# * Use orders and extract order_id as well as order_date from each element in the form of a tuple. Make sure that order_id is of type int.

# In[10]:


orders_path = "/data/retail_db/orders/part-00000"
orders = open(orders_path).     read().     splitlines()


# In[11]:


orders[:10]


# In[12]:


[(1, '2013-07-25 00:00:00.0'), (2, '2013-07-25 00:00:00.0')]


# In[13]:


[(1, '2013-07-25 00:00:00.0'), (2, '2013-07-25 00:00:00.0')]


# In[14]:


order_tuples = myMap(orders,
                     lambda order: (int(order.split(',')[0]), order.split(',')[1])
                    )


# In[15]:


order_tuples[:10]


# In[ ]:




