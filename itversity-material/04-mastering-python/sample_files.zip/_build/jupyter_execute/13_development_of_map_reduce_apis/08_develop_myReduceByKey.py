#!/usr/bin/env python
# coding: utf-8

# ## Develop myReduceByKey
# Develop a function by name myReduceByKey which takes a collection of tuples and a function as arguments. Each element in the collection should have exactly 2 attributes. Function should do the following:
# * Iterate through the collection of tuples.
# * Group the data by first element in the collection of tuples and apply the function using the argument passed. Argument should have necessary arithmetic logic.
# * Return a collection of tuples, where first element is unique and second element is aggregated result.

# In[ ]:


d = {}
d[2] = 199.99


# In[ ]:


d


# In[ ]:


if 2 in d: d[2] = d[2] + 250.0


# In[ ]:


if 4 in d: d[4] = d[4] + 100
else: d[4] = 100


# In[ ]:


d


# In[ ]:


def myReduceByKey(c_p, f):
    d = {}
    for e in c_p:
        if e[0] in d:
            d[e[0]] = f(d[e[0]], e[1])
        else:
            d[e[0]] = e[1]
    return list(d.items())

