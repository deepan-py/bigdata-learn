#!/usr/bin/env python
# coding: utf-8

# ## Function - Get Database Connection
# 
# Let us develop function to get Database Connection so that we can reuse in subsequent topics to perform CRUD Operations.
# * `get_connection` will take required paramters to establish a connection to the database and return connection object.
# * We can invoke that function and create required connection objects such as `sms_connection` so that we can perform database operations.
# * `sms_connection` is the connection object for our hypothetical **sms** database.
# * We can trigger this notebook from other notebooks by using `%run`.
# * The function as well as objects such as `sms_connection` can be used in the other notebooks from which this notebook is triggered.

# In[1]:


get_ipython().run_line_magic('run', '01_setup_database.ipynb')


# In[2]:


import psycopg2

def get_connection(host, port, database, user, password):
    connection = None
    try:
        connection = psycopg2.connect(
            host=host,
            port=port,
            database=database,
            user=user,
            password=password
        )
    except Exception as e:
        raise(e)
    
    return connection


# In[3]:


yt_connection = get_connection(
    host=db_host,
    port=db_port,
    database=db_name,
    user=db_user,
    password=db_pass
)


# In[ ]:




