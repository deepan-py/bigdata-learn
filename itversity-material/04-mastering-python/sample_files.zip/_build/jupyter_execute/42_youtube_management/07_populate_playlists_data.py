#!/usr/bin/env python
# coding: utf-8

# ## Populate Playlists Data
# 
# Let us populate playlists data into playlists table using Python as programming language.
# * Read playlists data using YouTube APIs. We will use the functions developed as part of the last topic.
# * Extract the data from the fields we are interested in.
#   * playlist_id
#   * playlist_title
#   * playlist_description
#   * playlist_video_count
#   * playlist_privacy_status
# * Load the data into the table.
# * Run queries to understand the following.
#   * Get number of playlists.
#   * Get number of playlists by privacy status.
#   * Get number of playlists where there is no description.
#   * Get top 10 playlists by video count.

# In[ ]:


get_ipython().run_line_magic('run', '04_function_get_database_connection.ipynb')


# In[ ]:


get_ipython().run_line_magic('run', '06_get_playlists_data.ipynb')


# ```{note}
# Reading playlists data using `get_playlists` function developed as part of the previous topic. The function returns only the fields we are interested in.
# ```

# In[ ]:


playlists_details = get_playlists(youtube, channel='UCakdSIPsJqiOLqylgoYmwQg')


# In[ ]:


playlists_details[0]


# In[ ]:


len(playlists_details)


# ```{note}
# Let us populate playlists data into the **playlists** table.
# ```

# In[ ]:


query = ("""
INSERT INTO playlists (
    playlist_id, playlist_title, 
    playlist_description, playlist_video_count,
    playlist_privacy_status
)
VALUES
    (%s, %s, %s, %s, %s)
""")


# In[ ]:


def load_data(connection, cursor, query, data):
    cursor.executemany(query, data)
    connection.commit()


# In[ ]:


load_data(
    yt_connection, yt_connection.cursor(), 
    query, playlist_details
)


# In[ ]:


yt_connection.commit()


# ```{note}
# Validating playlists data by running queries against **playlists** table.
# ```

# In[ ]:


get_ipython().run_line_magic('run', '01_setup_database.ipynb')


# In[ ]:


get_ipython().run_line_magic('load_ext', 'sql')


# ```{note}
# Get the number of playlists we have created since the channel is started.
# ```

# In[ ]:


get_ipython().run_cell_magic('sql', '', '\nSELECT count(1) FROM playlists')


# ```{note}
# Get the number of playlists by privacy status.
# ```

# In[ ]:


get_ipython().run_cell_magic('sql', '', '\nSELECT playlist_privacy_status, count(1) FROM playlists\nGROUP BY playlist_privacy_status')


# ```{note}
# Get number of playlists where there is no description.
# ```

# In[ ]:


get_ipython().run_cell_magic('sql', '', '\nSELECT count(1) FROM playlists\nWHERE length(playlist_description) = 0')


# ```{note}
# Get top 10 playlists by video count.
# ```

# In[ ]:


get_ipython().run_cell_magic('sql', '', '\nSELECT playlist_id, playlist_title, playlist_video_count, playlist_privacy_status FROM playlists\nORDER BY playlist_video_count DESC\nLIMIT 10')


# In[ ]:




