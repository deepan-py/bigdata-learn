#!/usr/bin/env python
# coding: utf-8

# ## Get Videos Data
# 
# Let us understand how to get the videos data using YouTube APIs with Python as programming language.
# 
# * We can use `search` to get the video details. But it is expensive. You will end up burning 100 units for each iteration of 50 videos.
# 
# ```python
# videos = youtube.search().list(
#     part='snippet',
#     channelId='UCakdSIPsJqiOLqylgoYmwQg',
#     maxResults=50
# ).execute()
# ```
# 
# * This is how you can iterate through all the videos using search API.
# 
# ```python
# nextPageToken = None
# video_ids = []
# while True:
#     videos = youtube.search().list(
#         part = 'snippet',
#         channelId='UCakdSIPsJqiOLqylgoYmwQg',
#         pageToken = nextPageToken,
#         maxResults = 50
#     ).execute()
# 
#     for item in videos['items']:
#         if item['id']['kind'] == 'youtube#video':
#             video_ids.append(
#                 (
#                     item['id']['videoId']
#                 )
#             )
# 
#     nextPageToken = videos.get('nextPageToken')
#     if not nextPageToken:
#         break
# ```
# 
# * If we know video ids, then we can pass comma separated video ids to `videos` to get all th details related to videos.
# * Here are the steps we can follow to get video details for a playlist.
#   * Get all the playlist items using `playlistItems`.
#   * Build a list of video ids.
#   * Get the details of the videos using `videos` by passing comma separated video ids up to 50 in each iteration.

# In[ ]:


get_ipython().run_line_magic('run', '04_function_get_database_connection.ipynb')


# ```{note}
# I have export of my YouTube channel metadata in the form of csv. I am using it to load videos data to the **videos** table.
# ```

# In[ ]:


import pandas as pd

yt_video_data = pd.read_csv('Backup_UCakdSIPsJqiOLqylgoYmwQg_1_of_1.csv')


# In[ ]:


yt_video_data


# In[ ]:


query = ("""
INSERT INTO videos (
    video_id, video_title, video_description, 
    video_category_id, video_file_name,
    video_privacy_status, video_published_dt
)
VALUES
    (%s, %s, %s, %s, %s, %s, %s)
""")


# In[ ]:


def load_data(connection, cursor, query, data):
    cursor.executemany(query, data)
    connection.commit()


# In[ ]:


yt_video_data.columns


# In[ ]:


yt_video_data = yt_video_data[[
    'Video Id', ' Title', ' Description', ' Category Id',
    ' FileName', ' Privacy', ' Date Published'
]]


# In[ ]:


load_data(
    yt_connection, yt_connection.cursor(), 
    query, yt_video_data.values.tolist()
)


# In[ ]:


yt_connection.commit()


# In[ ]:


yt_video_data.dtypes


# ```{note}
# Let us validate data in **videos** table.
# ```

# In[1]:


get_ipython().run_line_magic('load_ext', 'sql')


# In[2]:


get_ipython().run_line_magic('run', '01_setup_database.ipynb')


# ```{note}
# Let us preview first 10 records from the table.
# ```

# In[ ]:


get_ipython().run_cell_magic('sql', '', '\nSELECT * FROM videos LIMIT 10')


# ```{note}
# Get the count by video_category_id and video_category_name.
# ```

# In[7]:


get_ipython().run_cell_magic('sql', '', '\nSELECT v.video_category_id, c.category_name, count(1)\nFROM videos v JOIN categories c\n    ON v.video_category_id = c.category_id\nGROUP BY v.video_category_id, c.category_name')


# ```{note}
# Get the video count by video privacy status.
# ```

# In[8]:


get_ipython().run_cell_magic('sql', '', '\nSELECT video_privacy_status, count(1)\nFROM videos\nGROUP BY video_privacy_status')

