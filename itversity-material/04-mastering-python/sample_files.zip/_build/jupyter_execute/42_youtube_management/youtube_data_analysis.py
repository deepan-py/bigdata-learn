#!/usr/bin/env python
# coding: utf-8

# Create the New project by going to https://console.developers.google.com/apis/
# * Give Unique Project Name.
# * Give location as No Organization.
# * Click on create.

# Add Youtube API from API library
# * Search for Youtube Data API v3.
# * And Select the API we need. In this case we are selecting (Youtube Data API v3) from
# the libraries present.
# * Enable the API and select the options as shown as below.
# * We are calling this API from python. So select Other non-UI (e. g cron job, daemon)
# * Select Public Data as we are using public YouTube data.

# One can access YouTube data API documentation from [here](https://developers.google.com/youtube/v3/docs)

# In[ ]:


get_ipython().system('pip install google-api-python-client')


# In[ ]:


from googleapiclient.discovery import build


# In[ ]:


import json
config = json.load(open('conf.json'))


# In[ ]:


api_key = config['YT_API_KEY']


# In[ ]:


youtube = build('youtube', 'v3', developerKey=api_key)


# In[ ]:


channel_id = config['CHANNEL_ID']


# In[ ]:


request = youtube.channels().list(
    part = 'statistics',
    id =channel_id
)


# In[ ]:


response = request.execute()


# In[ ]:


print(response)


# In[ ]:


print(response['items'])


# In[ ]:


print(response['items'][0]['statistics'])


# In[ ]:


playlist_list = youtube.playlists().list(
    part = 'status',
    channelId = channel_id
).execute()


# In[ ]:


playlist_list


# In[ ]:


playlist_id = 'PLf0swTFhTI8rkH4yIfoyTAheEGjWIRtPG'


# In[ ]:


playlistItems = youtube.playlistItems().list(
    part = 'contentDetails',
    playlistId = playlist_id,
    maxResults = 100
).execute()


# In[ ]:


playlistItems


# In[ ]:


playlistItems['nextPageToken']


# In[ ]:


playlistItems['items'][0]


# In[ ]:


videoDetails = youtube.videos().list(
    part = 'snippet',
    id = playlistItems['items'][0]['contentDetails']['videoId']
).execute()


# In[ ]:


videoDetails


# In[ ]:


videoDetails['items'][0]['snippet']['title']


# In[ ]:


videoDetails['items'][0]['id']


# In[ ]:


len(playlistItems['items'])


# In[40]:


playlist_id = 'PLf0swTFhTI8rkH4yIfoyTAheEGjWIRtPG'


# In[41]:


playlistItems = youtube.playlistItems().list(
    part = 'contentDetails',
    playlistId = playlist_id,
    maxResults = 100
).execute()


# In[42]:


while True:
    for video in playlistItems['items']:
        videoDetails = youtube.videos().list(
            part = 'snippet',
            id = video['contentDetails']['videoId']
        ).execute()
#         print(f"https://www.YouTube.com/watch?v={videoDetails['items'][0]['id']} : {videoDetails['items'][0]['id']} : {videoDetails['items'][0]['snippet']['title'].split(' - ')[-1]}")
        print(f"https://www.YouTube.com/watch?v={videoDetails['items'][0]['id']} : {videoDetails['items'][0]['id']} : {videoDetails['items'][0]['snippet']['title']}")
    if playlistItems.get('nextPageToken'):
        playlistItems = youtube.playlistItems().list(
            part = 'contentDetails',
            playlistId = playlist_id,
            pageToken = playlistItems['nextPageToken'],
            maxResults = 50
        ).execute()
    else: break


# In[ ]:




