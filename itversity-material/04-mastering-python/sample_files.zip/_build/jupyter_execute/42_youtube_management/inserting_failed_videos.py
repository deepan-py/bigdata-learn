#!/usr/bin/env python
# coding: utf-8

# ```{note}
# Insertion of missing videos to populate in playlist_videos.
# ```

# In[13]:


get_ipython().run_cell_magic('sql', '', "\nSELECT * FROM videos WHERE video_id = '_wthxkHZFMo'")


# In[ ]:


get_ipython().run_cell_magic('sql', '', "\nSELECT * FROM playlists WHERE playlist_id = 'PLf0swTFhTI8rkH4yIfoyTAheEGjWIRtPG'")


# In[49]:


s = '''
Insertion of PLf0swTFhTI8rkH4yIfoyTAheEGjWIRtPG:_wthxkHZFMo is failed
'''


# In[50]:


videos = []

for rec in s.splitlines():
    if len(rec.split(' ')) > 1:
        videos.append(rec.split(' ')[2].split(':')[1]) 


# In[51]:


len(videos)


# In[52]:


playlists = []

for rec in s.splitlines():
    if len(rec.split(' ')) > 1:
        playlists.append(rec.split(' ')[2].split(':')[0]) 


# In[53]:


for playlist_id in set(playlists):
    print(playlist_id)


# In[54]:


def get_video_details(youtube, video_list, maxResults=50):
    video_details = youtube.videos().list(
        part='snippet',
        id=','.join(video_list),
        maxResults=maxResults
    ).execute()
    itv_videos = []
    for item in video_details['items']:
        if item['snippet']['channelId'] == 'UCakdSIPsJqiOLqylgoYmwQg':
            itv_videos.append(item['id'])
    itv_video_details = youtube.videos().list(
        part='snippet,contentDetails,fileDetails,status',
        id=','.join(itv_videos),
        maxResults=maxResults
    ).execute()
    return itv_video_details


# In[55]:


video_details = get_video_details(youtube, videos)


# In[56]:


len(video_details['items'])


# In[57]:


video_details['items'][0]


# In[58]:


itv_video_details = []
for item in video_details['items']:
    itv_video_details.append((
        item['id'], 
        item['snippet']['title'],
        item['snippet']['description'],
        item['snippet']['categoryId'],
        item['fileDetails']['fileName'],
        item['status']['privacyStatus'],
        item['snippet']['publishedAt']
    ))


# In[59]:


itv_video_details


# In[60]:


query = ("""
INSERT INTO videos (
    video_id, video_title, video_description, 
    video_category_id, video_file_name,
    video_privacy_status, video_published_dt
)
VALUES
    (%s, %s, %s, %s, %s, %s, %s)
""")


# In[61]:


def load_data(connection, cursor, query, data):
    for rec in data:
        try:
            cursor.execute(query, rec)
            connection.commit()
        except Exception as e:
            print(e)
            connection.commit()


# In[62]:


load_data(
    yt_connection, yt_connection.cursor(), 
    query, itv_video_details
)


# ```{note}
# Inserting missing records in playlist_videos
# ```

# In[66]:


query = ("""
INSERT INTO playlist_videos (
    playlist_id, video_id, video_position, video_added_dt
)
VALUES
    (%s, %s, %s, %s)
""")


# In[67]:


def load_data(connection, cursor, query, data):
    for rec in data:
        try:
            cursor.execute(query, rec)
            connection.commit()
        except Exception as e:
            print(f'Insertion of {rec[0]}:{rec[1]} is failed')
            connection.commit()


# In[68]:


yt_connection.commit()


# In[69]:


playlist_videos_failed = []

for video_details in playlist_videos:
    if video_details[1] in videos:
        playlist_videos_failed.append(video_details)


# In[70]:


load_data(
    yt_connection, yt_connection.cursor(), 
    query, playlist_videos_failed
)


# ```{note}
# Validation queries
# ```

# In[72]:


get_ipython().run_cell_magic('sql', '', '\nSELECT count(1) FROM playlists')


# In[71]:


get_ipython().run_cell_magic('sql', '', '\nSELECT count(1) FROM videos')


# In[73]:


get_ipython().run_cell_magic('sql', '', '\nSELECT count(1) FROM playlist_videos')


# In[ ]:




