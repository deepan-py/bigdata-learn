#!/usr/bin/env python
# coding: utf-8

# In[ ]:


get_ipython().system('pip install --upgrade google-api-python-client')
get_ipython().system('pip install --upgrade google-auth-oauthlib google-auth-httplib2')


# In[1]:


auth_code = None


# In[2]:


#OAuth2 for YouTube Data v3 API

def get_auth_code(credentials_path, auth_code):
    if not auth_code:
        from google_auth_oauthlib.flow import InstalledAppFlow

        CLIENT_SECRET_FILE = credentials_path
        SCOPES = ['https://www.googleapis.com/auth/youtube']

        Flow = InstalledAppFlow.from_client_secrets_file(CLIENT_SECRET_FILE, SCOPES)

        auth_code = Flow.run_console()
    
    return auth_code


# In[3]:


def build_youtube(auth_code):
    from apiclient.discovery import build
    return build('youtube','v3', credentials=auth_code)


# In[4]:


if not auth_code:
    auth_code = get_auth_code('client_secret_da.json', auth_code)


# In[5]:


youtube = build_youtube(auth_code)


# In[ ]:




