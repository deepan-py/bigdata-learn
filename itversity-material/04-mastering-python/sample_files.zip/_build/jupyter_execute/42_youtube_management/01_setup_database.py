#!/usr/bin/env python
# coding: utf-8

# ## Setup Database
# 
# Let us setup the database to store video metadata in normalized form.
# 
# * Database Name: yt_db
# * User Name: yt_user
# * Here is the script to create database and required tables.
# 
# ```
# sudo -u postgres psql
# CREATE DATABASE yt_db;
# CREATE USER yt_user WITH ENCRYPTED PASSWORD 'yt_password';
# GRANT ALL ON DATABASE yt_db TO yt_user;
# ```

# In[ ]:


import json


# In[ ]:


conf_path = 'conf.json'


# In[ ]:


conf_file = open(conf_path)


# In[ ]:


config = json.load(conf_file)


# In[ ]:


db_host = config['DEV']['DB_HOST']
db_port = config['DEV']['DB_PORT']
db_name = config['DEV']['DB_NAME']
db_user = config['DEV']['DB_USER']
db_pass = config['DEV']['DB_PASS']


# In[ ]:


import os

os.environ.setdefault('DATABASE_URL', f'postgresql://{db_user}:{db_pass}@{db_host}:{db_port}/{db_name}')

