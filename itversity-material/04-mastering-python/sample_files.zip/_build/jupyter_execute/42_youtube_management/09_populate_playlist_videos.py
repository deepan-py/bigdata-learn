#!/usr/bin/env python
# coding: utf-8

# ## Populate Playlist Videos
# 
# Let us populate playlist videos into a new table called as **playlist_videos**.
# * **playlist_videos** is a bridge table between playlists and videos.
# * We will use the functions defined as part of getting playlists to get both playlist details as well playlist items details.
# * We will build a list of playlist items with below fields.
#   * playlist_id
#   * video_id
#   * video_position (with in the playlist)
#   * video_published_dt (date on which video is added to the playlist).

# In[1]:


get_ipython().run_line_magic('run', '04_function_get_database_connection.ipynb')


# In[2]:


get_ipython().run_line_magic('run', '06_get_playlists_data.ipynb')


# In[38]:


playlist_details = youtube.playlistItems().list(
    part='snippet',
    playlistId='PLf0swTFhTI8pdq_MKvQL9aXQyWNudc6ZY'
).execute()


# In[39]:


playlist_details['items'][0]


# ```{note}
# Getting all the playlists from the channel.
# ```

# In[40]:


playlists_details = get_playlists(youtube, channel='UCakdSIPsJqiOLqylgoYmwQg')


# In[ ]:


playlists_details[0][0]


# In[ ]:


playlist_items = get_playlist_items(playlists_details[0][0], 'UCakdSIPsJqiOLqylgoYmwQg')


# In[ ]:


playlist_items[:10]


# In[ ]:


for playlist in playlists_details[:10]:
    print(playlist[0])


# ```{note}
# Getting all the playlist items into a list. It will fetch all the items for a one playlist at a time.
# ```

# In[1]:


l1 = [1, 2, 3, 4]
l2 = [4, 5, 6]

l1 + l2


# In[41]:


playlist_videos= []

for playlist in playlists_details:
    playlist_videos += get_playlist_items(playlist[0], 'UCakdSIPsJqiOLqylgoYmwQg')


# In[42]:


len(playlist_videos)


# In[43]:


playlist_videos[0]


# In[44]:


len(playlist_videos)


# ```{note}
# Loading playlists data into the table. We are inserting one at a time and printing the message if insert fails.
# ```

# In[45]:


query = ("""
INSERT INTO playlist_videos (
    playlist_id, video_id, video_position, video_added_dt
)
VALUES
    (%s, %s, %s, %s)
""")


# In[46]:


def load_data(connection, cursor, query, data):
    for rec in data:
        try:
            cursor.execute(query, rec)
            connection.commit()
        except Exception as e:
            print(f'Insertion of {rec[0]}:{rec[1]} is failed')
            connection.commit()


# In[47]:


yt_connection.commit()


# In[48]:


load_data(
    yt_connection, yt_connection.cursor(), 
    query, playlist_videos
)


# ```{note}
# Validating data in playlist_videos table.
# ```

# In[3]:


get_ipython().run_line_magic('load_ext', 'sql')


# In[4]:


get_ipython().run_line_magic('run', '01_setup_database.ipynb')


# In[5]:


get_ipython().run_cell_magic('sql', '', '\nSELECT * FROM playlist_videos LIMIT 10')


# In[8]:


get_ipython().run_cell_magic('sql', '', '\nSELECT p.playlist_id, p.playlist_title, count(1) \nFROM playlists p JOIN playlist_videos pv\n    ON p.playlist_id = pv.playlist_id\nGROUP BY p.playlist_id, p.playlist_title\nORDER BY 3 DESC\nLIMIT 10')


# In[ ]:




