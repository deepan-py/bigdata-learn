#!/usr/bin/env python
# coding: utf-8

# ## Populate Categories Data
# 
# Let us understand how to get YouTube Categories Data using Python as programming language using REST APIs.
# 
# Here are the steps involved in getting the data.
# * Make sure to get the token and build **youtube** object.
# * We can get list of categories using `youtube.videoCategories().list` with appropriate arguments.
# * As per the table structure below we want category id and category name.
#   * Category Name comes from snippet part.
# * We need to pass `snippet` to part argument for `youtube.videoCategories().list` along with region code.
# 
# ```python
# video_categories = youtube.videoCategories().list(
#     part='snippet',
#     regionCode='US'
# ).execute()
# ```

# In[1]:


get_ipython().run_line_magic('run', '03_configure_youtube_apis.ipynb')


# In[ ]:


youtube


# In[2]:


video_categories = youtube.videoCategories().list(
    part='snippet',
    regionCode='US'
).execute()


# In[3]:


video_categories['items'][0]


# In[4]:


video_category_details = []
for item in video_categories['items']:
    video_category_details.append((item['id'], item['snippet']['title']))


# In[5]:


query = ("""
INSERT INTO categories (
    category_id, category_name
)
VALUES
    (%s, %s)
""")


# In[6]:


get_ipython().run_line_magic('run', '04_function_get_database_connection.ipynb')


# In[8]:


def load_data(connection, cursor, query, data):
    cursor.executemany(query, data)
    connection.commit()


# In[9]:


load_data(
    yt_connection, yt_connection.cursor(), 
    query, video_category_details
)


# ```{note}
# We can build dict for categories data, in case we have to do a reverse lookup for category ids by passing category name.
# ```

# In[17]:


categories_query = 'SELECT category_name, category_id FROM categories'


# In[18]:


categories_cursor = yt_connection.cursor()
categories_cursor.execute(categories_query)
categories = categories_cursor.fetchall()


# In[20]:


dict(categories)

