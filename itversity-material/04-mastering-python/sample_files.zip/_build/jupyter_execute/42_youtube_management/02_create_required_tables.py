#!/usr/bin/env python
# coding: utf-8

# ## Create Tables
# 
# Let us create required tables to store YouTube metadata for the analysis
# * videos
# * playlists
# * playlist_videos
# * video_tags

# In[1]:


get_ipython().run_line_magic('run', '01_setup_database.ipynb')


# In[2]:


get_ipython().run_line_magic('load_ext', 'sql')


# In[3]:


get_ipython().run_line_magic('sql', 'DROP TABLE IF EXISTS categories')


# In[4]:


get_ipython().run_cell_magic('sql', '', '\nCREATE TABLE categories (\n    category_id INT PRIMARY KEY,\n    category_name VARCHAR(200) NOT NULL,\n    last_updated DATE DEFAULT CURRENT_DATE\n)')


# In[16]:


get_ipython().run_line_magic('sql', 'DROP TABLE IF EXISTS videos CASCADE')


# In[17]:


get_ipython().run_cell_magic('sql', '', '\nCREATE TABLE videos (\n    video_id VARCHAR(30) PRIMARY KEY,\n    video_title VARCHAR(200) NOT NULL,\n    video_description VARCHAR(5000),\n    video_category_id INT,\n    video_file_name VARCHAR(200),\n    video_privacy_status VARCHAR(30),\n    video_published_dt DATE,\n    last_updated DATE DEFAULT CURRENT_DATE\n)')


# In[5]:


get_ipython().run_line_magic('sql', 'DROP TABLE IF EXISTS playlists')


# In[6]:


get_ipython().run_cell_magic('sql', '', '\nCREATE TABLE playlists (\n    playlist_id VARCHAR(50) PRIMARY KEY,\n    playlist_title VARCHAR(200) NOT NULL,\n    playlist_description VARCHAR(5000),\n    playlist_video_count INT,\n    playlist_privacy_status VARCHAR(30),\n    playlist_published_dt DATE,\n    last_updated DATE DEFAULT CURRENT_DATE\n)')


# In[58]:


get_ipython().run_cell_magic('sql', '', '\nDROP TABLE IF EXISTS playlist_videos')


# In[59]:


get_ipython().run_cell_magic('sql', '', '\nCREATE TABLE playlist_videos (\n    playlist_video_id SERIAL PRIMARY KEY,\n    playlist_id VARCHAR(50),\n    video_id VARCHAR(50),\n    video_position INT,\n    video_added_dt DATE,\n    last_updated DATE DEFAULT CURRENT_DATE\n)')


# In[60]:


get_ipython().run_cell_magic('sql', '', '\nALTER TABLE playlist_videos\n    ADD UNIQUE (playlist_id, video_id, video_position)')


# In[61]:


get_ipython().run_cell_magic('sql', '', '\nALTER TABLE playlist_videos\n    ADD FOREIGN KEY (playlist_id)\n    REFERENCES playlists (playlist_id)')


# In[62]:


get_ipython().run_cell_magic('sql', '', '\nALTER TABLE playlist_videos\n    ADD FOREIGN KEY (video_id)\n    REFERENCES videos (video_id)')


# In[ ]:




