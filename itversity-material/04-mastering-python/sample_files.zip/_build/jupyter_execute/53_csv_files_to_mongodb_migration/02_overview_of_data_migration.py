#!/usr/bin/env python
# coding: utf-8

# ## Data Conversion with Attribute Names
# 
# At times we might have to convert the data in files into JSON with different names for the attributes.
# * Let us go through the details about the actual usage.
#   * An eCommerce platform will be a mobile app or web app. Using eCommerce platform we typically sell products to the customers. The data will be typically in RDBMS database such as Postgres, MySQL, Oracle, SQL Server etc.
#   * However, the eCommerce company who runs the platform want to run the loyalty program. For that they build an application using MongoDB database.
#   * Now we need to integrate the customer data in RDBMS database into the MongoDB database built for loyalty program application.
#   * We can either integrate data between the eCommerce Platform and loyalty program in batch mode or real time.
#   * Batch mode means the data from the eCommerce Platform database will be sent once every day in the form of files and we should have a scheduled job which will load this data into the target MongoDB database built for loyalty program.
# * Let us assume that data is sent every day into the location **/data/ecomm/customers** for previous day.
# * Here is the file naming convention - **part-00000**. The name of the file will be incremented for each of the new file added with incremental data.
# * For now, we have customer data available under **/data/ecomm/customers/part-00000**.
# * Make sure to understand characteristics of the data.
# * Use appropriate Pandas API to read the data.
# * Convert the data into the dataframe and perform required transformations.
#   * 
