#!/usr/bin/env python
# coding: utf-8

# ## Read data into Dataframe
# 
# Let us read the data into the Dataframe using appropriate arguments.
# * We can use `pd.read_csv` to read the data.
# * First argument is the file name. As we are processing only one file, we can specify the fully qualified path of the file.
# * As delimiter is comma, it is optional to use keyword arguments `sep` or `delimiter`. If the delimter or separator is not comma, then we can sepcify that either using `sep` or `delimiter`.
# * The file have a header with column names. The default `infer`, which means it considers the fields names in the first line to define column names in the created Pandas DataFrame.
# * If you want to specify different column names to match the target, then we need to pass `header=0` and then pass list of column names to `names` keyword argument. You can use this approach in some cases.
# 
# However, at this time just read the data from CSV into Data Frame using names from the header. I would suggest to go through the keyword arguments of `pd.read_csv` by running below cell.

# In[ ]:


import pandas as pd
get_ipython().run_line_magic('pinfo', 'pd.read_csv')


# * As our data is having the default delimiter and also header, we just need to pass the file name while invoking `read_csv`.

# In[6]:


customers = pd.read_csv('/data/ecomm/customers/part-00000')


# In[13]:


customers

