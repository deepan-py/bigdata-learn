#!/usr/bin/env python
# coding: utf-8

# ## Recap of MongoDB
# 
# Let us recap MongoDB, especially using Python as Programming Language.
# * As in any database we need to create client object using following information.
#   * Host on which MongoDB is running.
#   * Port on which MongoDB is running on the server.
#   * Application Database Name in which MongoDB collections for the application are supposed to be created.
#   * Username with appropriate permissions to manage data in MongoDB collections.
#   * Password for the user we are going to use to connect to MongoDB database to manage data in MongoDB collections.
# * Here are the connection details.
#   * Host: **pylabsmd.itversity.com**
#   * Port: **27017** (default port)
#   * Database Name: **{username}_scratch_db**
#   * Username: **{username}_scratch_user**
#   * Password: The password will be part of **/home/${USER}/.jupyterenv** with key **MONGO_SCRATCH_PASS** under **DEFAULT**

# In[3]:


get_ipython().system('ls -ltr /home/${USER}/.jupyterenv')


# In[5]:


import pymongo, getpass, configparser

username = getpass.getuser()
config = configparser.ConfigParser()
config.read(f'/home/{username}/.jupyterenv')

client = pymongo.MongoClient(
    host='pylabsmd.itversity.com', 
    username=f'{username}_scratch_user', 
    password=config['DEFAULT']['MONGO_SCRATCH_PASS'], 
    authSource='admin'
)


# In[6]:


client.itversity_scratch_db.list_collection_names()


# In[ ]:




