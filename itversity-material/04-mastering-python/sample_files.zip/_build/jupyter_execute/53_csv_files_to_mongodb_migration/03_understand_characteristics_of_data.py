#!/usr/bin/env python
# coding: utf-8

# ### Step 1: Understand Characteristics of Data
# 
# Let us first understand characteristics of the data.
# * We can use Linux commands to understand the characteristics of the data.

# In[ ]:


get_ipython().system('ls -ltr /data/ecomm/customers/part-00000')


# In[3]:


get_ipython().system('head -5 /data/ecomm/customers/part-00000')


# * Here are the characteristics of the data.
#   * The file is in CSV format. Text file with comma as delimiter between attributes in each record.
#   * Records are delimited by new line character.
