#!/usr/bin/env python
# coding: utf-8

# ## Rename Columns in Dataframe
# 
# Let us understand how to rename the columns using column mapping between source field names and target field names.
# 
# * We can use rename to rename the columns. It has keyword argument called as `columns`. You can pass a dict or function to it. We will pass a dict.
#   * The dict should contain key and value pairs of source and target column names.
#   * We need to get the relevant column names from **column_mapping** in desired format.

# In[ ]:


import pandas as pd
customers = pd.read_csv('/data/ecomm/customers/part-00000')


# In[ ]:


column_mapping_str = '''{
    "customer_first_name": {"target_field_name": "FirstName", "is_required": true},
    "customer_last_name": {"target_field_name": "LastName", "is_required": true},
    "customer_email": {"target_field_name": "Email", "is_required": true},
    "product_name": {"is_required": false},
    "product_subscription": {"is_required": false}
}'''


# In[ ]:


import json
column_mapping = json.loads(column_mapping_str)


# In[ ]:


column_mapping


# In[ ]:


list(filter(lambda col: col[1]['is_required'], column_mapping.items()))


# In[ ]:


# We got the required columns list here
required_columns_list = list(filter(lambda col: col[1]['is_required'], column_mapping.items()))


# In[ ]:


required_columns_list


# In[ ]:


col = required_columns_list[0]


# In[ ]:


col


# In[ ]:


type(col)


# In[ ]:


col[1]


# In[ ]:


col[1]['target_field_name']


# In[ ]:


(col[0], col[1]['target_field_name'])


# In[ ]:


dict(map(lambda col: (col[0], col[1]['target_field_name']), required_columns_list))


# In[ ]:


# Get the dict with source and target field names
required_columns_mapping = dict(map(lambda col: (col[0], col[1]['target_field_name']), required_columns_list))


# In[ ]:


get_ipython().run_line_magic('pinfo', 'customers.rename')


# In[ ]:


# It will rename the columns that are present in the dict passed.
# Other columns will have the names from the original dataframe
# This will return all the columns with new names for the 3 columns that are part of he dict.
customers.rename(columns=required_columns_mapping)


# In[ ]:


customers.rename(columns=required_columns_mapping).columns


# In[2]:


import pandas as pd
customers = pd.read_csv('/data/ecomm/customers/part-00000')

column_mapping_str = '''{
    "customer_first_name": {"target_field_name": "FirstName", "is_required": true},
    "customer_last_name": {"target_field_name": "LastName", "is_required": true},
    "customer_email": {"target_field_name": "Email", "is_required": true},
    "product_name": {"is_required": false},
    "product_subscription": {"is_required": false}
}'''

import json
column_mapping = json.loads(column_mapping_str)

# Assigning the list of not required fields to a variable
columns_to_be_dropped = dict(list(filter(lambda col: not col[1]['is_required'], column_mapping.items()))).keys()
required_columns_list = list(filter(lambda col: col[1]['is_required'], column_mapping.items()))
required_columns_mapping = dict(map(lambda col: (col[0], col[1]['target_field_name']), required_columns_list))

# This will take care of dropping the not required fields and rename others as per mapping
customers_target = customers.drop(columns=columns_to_be_dropped).rename(columns=required_columns_mapping)


# In[3]:


customers_target


# In[ ]:




