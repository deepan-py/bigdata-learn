#!/usr/bin/env python
# coding: utf-8

# ## Analyze the Dataframe
# 
# Let us do some analysis of the Data Frame.
# * Get columns
# * Get data type of each column
# * Get number of records and columns
# * Get counts
# * Describe Dataframe

# In[2]:


import pandas as pd
customers = pd.read_csv('/data/ecomm/customers/part-00000')


# In[3]:


# List column names
customers.columns


# In[4]:


# List data types
customers.dtypes


# In[5]:


# Get count using shape. It returns tuple.
# First element in the tuple is row count and second element is column count
customers.shape


# In[6]:


row_count = customers.shape[0]


# In[7]:


row_count


# In[8]:


col_count = customers.shape[1]


# In[9]:


col_count


# In[10]:


customers.count()


# In[11]:


customers.describe()


# In[ ]:




