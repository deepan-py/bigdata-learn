#!/usr/bin/env python
# coding: utf-8

# ## Load Data to MongoDB
# 
# Let us see how to load the data to MongoDB.
# * Create connection to MongoDB.
# * Build the required list of dicts.
# * Use `insert_many` to insert the list of dicts at once.

# In[1]:


import pymongo, getpass, configparser

username = getpass.getuser()
config = configparser.ConfigParser()
config.read(f'/home/{username}/.jupyterenv')

client = pymongo.MongoClient(
    host='pylabsmd.itversity.com', 
    username=f'{username}_scratch_user', 
    password=config['DEFAULT']['MONGO_SCRATCH_PASS'], 
    authSource='admin'
)


# In[2]:


client[f'{username}_scratch_db'].list_collection_names()


# In[3]:


client[f'{username}_scratch_db']['customers'].delete_many({})


# In[4]:


for doc in client[f'{username}_scratch_db']['customers'].find({}):
    print(doc)


# In[5]:


customers = [
    {'FirstName': 'Cassaundra', 'LastName':'Collinson', 'Email': 'ccollinson0@alibaba.com'},
    {'FirstName': 'Rozamond', 'LastName':'Oene', 'Email': 'roene1@technorati.com'},
    {'FirstName': 'Gus', 'LastName':'Hawick', 'Email': 'ghawick2@dagondesign.com'}
]


# In[7]:


client[f'{username}_scratch_db']['customers'].insert_many(customers)


# In[8]:


for doc in client[f'{username}_scratch_db']['customers'].find({}):
    print(doc)


# In[9]:


client[f'{username}_scratch_db']['customers'].delete_many({})


# In[ ]:




