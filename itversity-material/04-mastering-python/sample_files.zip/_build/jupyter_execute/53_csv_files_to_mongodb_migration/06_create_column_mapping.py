#!/usr/bin/env python
# coding: utf-8

# ## Create Column Mapping
# 
# Let us define column mapping between source column names and target column names.
# * Let us assume that we would like to load the data that is relevant to contact the customer.
# * We want to get the list of customers with only first name, last name and email.
# * Let us assume that the target column names are FirstName, LastName and Email. Also the column names are case sensitive.
# * We need to drop product_name and product_subscription from the **customers** dataframe.
# * Also we need to take care of renaming the columns as follows:
#   * **customer_first_name** to **FirstName**
#   * **customer_last_name** to **LastName**
#   * **customer_email** to **Email**
# * We can create a mapping in a file using JSON or we can store the mapping the database. In our case let us assume that the mapping is defined in JSON. As part of the simulation, I will start with JSON string rather than reading from file.

# In[1]:


column_mapping_str = '''{
    "customer_first_name": {"target_field_name": "FirstName", "is_required": true},
    "customer_last_name": {"target_field_name": "LastName", "is_required": true},
    "customer_email": {"target_field_name": "Email", "is_required": true},
    "product_name": {"is_required": false},
    "product_subscription": {"is_required": false}
}'''


# In[2]:


import json
column_mapping = json.loads(column_mapping_str)


# In[3]:


type(column_mapping)


# In[4]:


column_mapping


# In[5]:


column_mapping['customer_first_name']


# In[ ]:




