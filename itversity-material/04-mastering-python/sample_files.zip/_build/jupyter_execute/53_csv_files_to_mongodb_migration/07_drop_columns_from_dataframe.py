#!/usr/bin/env python
# coding: utf-8

# ## Drop Columns from Dataframe
# 
# Let us get the list of not required columns from column mapping and drop them from the Dataframe.
# * For each source column we have defined target attribute details.
# * **is_required** is one of the target attribute details. If **is_required** is false, then we would like to discard those fields before writing into the target table.
# * We need to develop the logic to get list of columns where **is_required** is false.
# * We can pass the list to the drop function on top of Dataframe.

# In[5]:


import pandas as pd
customers = pd.read_csv('/data/ecomm/customers/part-00000')


# In[6]:


column_mapping_str = '''{
    "customer_first_name": {"target_field_name": "FirstName", "is_required": true},
    "customer_last_name": {"target_field_name": "LastName", "is_required": true},
    "customer_email": {"target_field_name": "Email", "is_required": true},
    "product_name": {"is_required": false},
    "product_subscription": {"is_required": false}
}'''


# In[7]:


import json
column_mapping = json.loads(column_mapping_str)


# In[8]:


# Converts dict to list of tuples
column_mapping.items()


# In[9]:


# Get first tuple from the list
list(column_mapping.items())[0]


# In[10]:


# Assigning first tuple to a variable
col = list(column_mapping.items())[0]


# In[11]:


# Getting second element from the tuple
# This will return target attribute details
# It is of type dict
col[1]


# In[32]:


# Getting the value of is_required from the dict
col[1]['is_required']


# In[12]:


# Same process for 5th element in the list of tuples
list(column_mapping.items())[4] # Picking 5th element in the list


# In[78]:


col = list(column_mapping.items())[4]


# In[79]:


col[1]


# In[80]:


col[1]['is_required']


# In[42]:


not col[1]['is_required']


# In[13]:


# Returns list of items where is_required is false
list(filter(lambda col: not col[1]['is_required'], column_mapping.items()))


# In[14]:


# Convert to a dict
dict(list(filter(lambda col: not col[1]['is_required'], column_mapping.items())))


# In[15]:


# Get list of not required fields
dict(list(filter(lambda col: not col[1]['is_required'], column_mapping.items()))).keys()


# In[18]:


# Assigning the list of not required fields to a variable
columns_to_be_dropped = dict(list(filter(lambda col: not col[1]['is_required'], column_mapping.items()))).keys()


# * You can use drop on dataframe to drop the columns. You can pass the names using `columns` keyword argument.

# In[19]:


get_ipython().run_line_magic('pinfo', 'customers.drop')


# In[20]:


# Returns dataframe by dropping the not required fields
customers.drop(columns=columns_to_be_dropped)


# In[ ]:




